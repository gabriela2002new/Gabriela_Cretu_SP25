CREATE EXTENSION IF NOT EXISTS dblink;

--connect to new db from inside another
SELECT * FROM dblink(
        'dbname=dwh_src_hw_db 
         user=postgres 
         password=CretuPaul1990. 
         host=localhost',
        'SELECT * FROM s1.s1_channels'
    ) AS src(channel_id VARCHAR(256), channel_name VARCHAR(256), channel_location VARCHAR(256));

--use full outer join
SELECT *
FROM lnd.lnd_s1_channels trg
FULL OUTER JOIN (
    SELECT * FROM dblink(
        'dbname=dwh_src_hw_db 
         user=postgres 
         password=CretuPaul1990. 
         host=localhost',
        'SELECT * FROM s1.s1_channels'
    ) AS src(channel_id VARCHAR(256), channel_name VARCHAR(256), channel_location VARCHAR(256))
) src
ON src.channel_id = trg.channel_id;

--reconciliation for mismatch
WITH reconciliation_results AS (
SELECT     
    's1_channels' AS table_name,
    'channel_id' AS key_column,
    src.channel_id AS src_id,
    trg.channel_id AS trg_id,
    CASE
        WHEN src.channel_id IS NULL THEN 'Only in landing'
        WHEN trg.channel_id IS NULL THEN 'Only in source'
        WHEN src.channel_name <> trg.channel_name THEN 'Mismatch in channel_name'
        WHEN src.channel_location <> trg.channel_location THEN 'Mismatch in channel_location'
        ELSE 'Match'
    END AS reconciliation_status
FROM lnd.lnd_s1_channels trg
FULL OUTER JOIN (
    SELECT * FROM dblink(
        'dbname=dwh_src_hw_db 
         user=postgres 
         password=CretuPaul1990. 
         host=localhost',
        'SELECT * FROM s1.s1_channels'
    ) AS src(channel_id VARCHAR(256), channel_name VARCHAR(256), channel_location VARCHAR(256))
) src
ON src.channel_id = trg.channel_id
)
SELECT * FROM reconciliation_results;


--reconciliation results table to store only problematic rows

truncate table if exists lnd.reconciliation_results;
CREATE TABLE IF NOT EXISTS lnd.reconciliation_results (
    table_name VARCHAR(256),
    key_column VARCHAR(256),
    src_id VARCHAR(256),
    trg_id VARCHAR(256),
    reconciliation_status VARCHAR(256)
);

--reconciliation for mismatch 

-- ==============================================
-- Reconciliation for s1 layer
-- ==============================================

--s1_channels
WITH reconciliation_results AS (
    SELECT     
        's1_channels' AS table_name,
        'channel_id' AS key_column,
        src.channel_id AS src_id,
        trg.channel_id AS trg_id,
        CASE
            WHEN src.channel_id IS NULL THEN 'Only in landing'
            WHEN trg.channel_id IS NULL THEN 'Only in source'
            WHEN src.channel_name <> trg.channel_name THEN 'Mismatch in channel_name'
            WHEN src.channel_location <> trg.channel_location THEN 'Mismatch in channel_location'
            ELSE 'Match'
        END AS reconciliation_status
    FROM lnd.lnd_s1_channels trg
    FULL OUTER JOIN (
        SELECT * FROM dblink(
            'dbname=dwh_src_hw_db user=postgres password=CretuPaul1990. host=localhost',
            'SELECT * FROM s1.s1_channels'
        ) AS src(channel_id VARCHAR(256), channel_name VARCHAR(256), channel_location VARCHAR(256))
    ) src
    ON src.channel_id = trg.channel_id
)
INSERT INTO lnd.reconciliation_results
SELECT *
FROM reconciliation_results
WHERE reconciliation_status <> 'Match';

-- s1_sales
WITH reconciliation_results AS (
    SELECT
        's1_sales' AS table_name,
        'client_id, channel_id, product_id, sale_date' AS key_column,

        -- Build IDs but return NULL if all key fields are NULL
        NULLIF(CONCAT_WS('|', src.client_id, src.channel_id, src.product_id, src.sale_date), '') AS src_id,
        NULLIF(CONCAT_WS('|', trg.client_id, trg.channel_id, trg.product_id, trg.sale_date), '') AS trg_id,

        CASE
            -- Row exists only in landing
            WHEN src.client_id IS NULL 
             AND src.channel_id IS NULL 
             AND src.product_id IS NULL 
             AND src.sale_date IS NULL
                THEN 'Only in landing'

            -- Row exists only in source
            WHEN trg.client_id IS NULL 
             AND trg.channel_id IS NULL 
             AND trg.product_id IS NULL 
             AND trg.sale_date IS NULL
                THEN 'Only in source'

            -- Data mismatches
            WHEN src.units IS DISTINCT FROM trg.units
                THEN 'Mismatch in units'
            WHEN src.purchase_date IS DISTINCT FROM trg.purchase_date
                THEN 'Mismatch in purchase_date'

            -- Otherwise match
            ELSE 'Match'
        END AS reconciliation_status

    FROM lnd.lnd_s1_sales trg
    FULL OUTER JOIN (
        SELECT * FROM dblink(
            'dbname=dwh_src_hw_db user=postgres password=CretuPaul1990. host=localhost',
            'SELECT client_id, channel_id, product_id, sale_date, units, purchase_date FROM s1.s1_sales'
        ) AS src(
            client_id VARCHAR(256),
            channel_id VARCHAR(256),
            product_id VARCHAR(256),
            sale_date VARCHAR(256),
            units VARCHAR(256),
            purchase_date VARCHAR(256)
        )
    ) src
    ON src.client_id = trg.client_id
   AND src.channel_id = trg.channel_id
   AND src.product_id = trg.product_id
   AND src.sale_date = trg.sale_date
)
INSERT INTO lnd.reconciliation_results (table_name, key_column, src_id, trg_id, reconciliation_status)
SELECT *
FROM reconciliation_results
WHERE reconciliation_status <>'Match';




-- s1_products
WITH reconciliation_results_cte AS (
    SELECT
        's1_products' AS table_name,
        'product_id' AS key_column,
        src.product_id AS src_id,
        trg.product_id AS trg_id,
        CASE
            WHEN src.product_id IS NULL THEN 'Only in landing'
            WHEN trg.product_id IS NULL THEN 'Only in source'
            WHEN src.product_name <> trg.product_name THEN 'Mismatch in product_name'
            WHEN src.cost <> trg.cost THEN 'Mismatch in cost'
            ELSE 'Match'
        END AS reconciliation_status
    FROM lnd.lnd_s1_products trg
    FULL OUTER JOIN (
        SELECT * FROM dblink(
            'dbname=dwh_src_hw_db user=postgres password=CretuPaul1990. host=localhost',
            'SELECT product_id, cost, product_name FROM s1.s1_products'
        ) AS src(
            product_id VARCHAR(256),
            cost VARCHAR(256),
            product_name VARCHAR(256)
        )
    ) src
    ON src.product_id = trg.product_id
)
INSERT INTO lnd.reconciliation_results (table_name, key_column, src_id, trg_id, reconciliation_status)
SELECT *
FROM reconciliation_results_cte
WHERE reconciliation_status <> 'Match';



-- s1_clients
WITH reconciliation_results_cte AS (
    SELECT
        's1_clients' AS table_name,
        'client_id' AS key_column,
        src.client_id AS src_id,
        trg.client_id AS trg_id,
        CASE
            WHEN src.client_id IS NULL THEN 'Only in landing'
            WHEN trg.client_id IS NULL THEN 'Only in source'
            WHEN src.first_name <> trg.first_name THEN 'Mismatch in client first_name'
            WHEN src.middle_name <> trg.middle_name THEN 'Mismatch in client middle_name'
            WHEN src.last_name <> trg.last_name THEN 'Mismatch in client last_name'
            WHEN src.email <> trg.email THEN 'Mismatch in client email'
            WHEN src.phone <> trg.phone THEN 'Mismatch in clien phone'
            WHEN src.first_purchase <> trg.first_purchase THEN 'Mismatch in client first_purchase'
            ELSE 'Match'
        END AS reconciliation_status
    FROM lnd.lnd_s1_clients trg
    FULL OUTER JOIN (
        SELECT * FROM dblink(
            'dbname=dwh_src_hw_db user=postgres password=CretuPaul1990.  host=localhost',
            'SELECT * FROM s1.s1_clients'
        ) AS src(client_id VARCHAR(256), first_name VARCHAR(256), middle_name VARCHAR(256), last_name VARCHAR(256), email VARCHAR(256), phone VARCHAR(256), first_purchase VARCHAR(256))
    ) src
    ON src.client_id = trg.client_id
)
INSERT INTO lnd.reconciliation_results
SELECT *
FROM reconciliation_results_cte
WHERE reconciliation_status <> 'Match';


-- ==============================================
-- Reconciliation for s2 layer
-- ==============================================

-- s2_channels
WITH reconciliation_results_cte AS (
    SELECT
        's2_channels' AS table_name,
        'channel_id' AS key_column,
        src.channel_id AS src_id,
        trg.channel_id AS trg_id,
        CASE
            WHEN src.channel_id IS NULL THEN 'Only in landing'
            WHEN trg.channel_id IS NULL THEN 'Only in source'
            WHEN src.channel_name <> trg.channel_name THEN 'Mismatch in channel_name'
            WHEN src.location_id <> trg.location_id THEN 'Mismatch in channel_location'
            ELSE 'Match'
        END AS reconciliation_status
    FROM lnd.lnd_s2_channels trg
    FULL OUTER JOIN (
        SELECT * FROM dblink(
            'dbname=dwh_src_hw_db user=postgres password=CretuPaul1990.  host=localhost',
            'SELECT * FROM s2.s2_channels'
        ) AS src(channel_id VARCHAR(256), channel_name VARCHAR(256), location_id VARCHAR(256))
    ) src
    ON src.channel_id = trg.channel_id
)
INSERT INTO lnd.reconciliation_results
SELECT *
FROM reconciliation_results_cte
WHERE reconciliation_status <> 'Match';


-- s2_locations
WITH reconciliation_results_cte AS (
    SELECT
        's2_locations' AS table_name,
        'location_id' AS key_column,
        src.location_id AS src_id,
        trg.location_id AS trg_id,
        CASE
            WHEN src.location_id IS NULL THEN 'Only in landing'
            WHEN trg.location_id IS NULL THEN 'Only in source'
            WHEN src.location_name <> trg.location_name THEN 'Mismatch in location_name'
            ELSE 'Match'
        END AS reconciliation_status
    FROM lnd.lnd_s2_locations trg
    FULL OUTER JOIN (
        SELECT * FROM dblink(
            'dbname=dwh_src_hw_db user=postgres password=CretuPaul1990.  host=localhost',
            'SELECT * FROM s2.s2_locations'
        ) AS src(location_id VARCHAR(256), location_name VARCHAR(256))
    ) src
    ON src.location_id = trg.location_id
)
INSERT INTO lnd.reconciliation_results
SELECT *
FROM reconciliation_results_cte
WHERE reconciliation_status <> 'Match';


-- s2_client_sales
WITH reconciliation_results AS (
    SELECT
        's2_client_sales' AS table_name,
        'client_id, channel_id, product_id, saled_at' AS key_column,

        -- Build IDs but make them NULL if all key fields are NULL
        NULLIF(CONCAT_WS('|', src.client_id, src.channel_id, src.product_id, src.saled_at), '') AS src_id,
        NULLIF(CONCAT_WS('|', trg.client_id, trg.channel_id, trg.product_id, trg.saled_at), '') AS trg_id,

        CASE
            -- Row exists only in landing
            WHEN src.client_id IS NULL 
             AND src.channel_id IS NULL 
             AND src.product_id IS NULL 
             AND src.saled_at IS NULL
                THEN 'Only in landing'

            -- Row exists only in source
            WHEN trg.client_id IS NULL 
             AND trg.channel_id IS NULL 
             AND trg.product_id IS NULL 
             AND trg.saled_at IS NULL
                THEN 'Only in source'

            -- Data mismatches
            WHEN src.product_name IS DISTINCT FROM trg.product_name
                THEN 'Mismatch in product_name'
            WHEN src.product_price IS DISTINCT FROM trg.product_price
                THEN 'Mismatch in product_price'
            WHEN src.product_amount IS DISTINCT FROM trg.product_amount
                THEN 'Mismatch in product_amount'
            WHEN src.sold_date IS DISTINCT FROM trg.sold_date
                THEN 'Mismatch in sold_date'

            -- Otherwise match
            ELSE 'Match'
        END AS reconciliation_status

    FROM lnd.lnd_s2_client_sales trg
    FULL OUTER JOIN (
        SELECT * FROM dblink(
            'dbname=dwh_src_hw_db user=postgres password=CretuPaul1990. host=localhost',
            'SELECT client_id, channel_id, saled_at, product_id, product_name, product_price, product_amount, sold_date FROM s2.s2_client_sales'
        ) AS src(
            client_id VARCHAR(256),
            channel_id VARCHAR(256),
            saled_at VARCHAR(256),
            product_id VARCHAR(256),
            product_name VARCHAR(256),
            product_price VARCHAR(256),
            product_amount VARCHAR(256),
            sold_date VARCHAR(256)
        )
    ) src
      ON src.client_id = trg.client_id
     AND src.channel_id = trg.channel_id
     AND src.product_id = trg.product_id
     AND src.saled_at = trg.saled_at
)
INSERT INTO lnd.reconciliation_results
SELECT *
FROM reconciliation_results
WHERE reconciliation_status <> 'Match';


-- s2_clients
WITH reconciliation_results_cte AS (
    SELECT
        's2_clients' AS table_name,
        'client_id' AS key_column,
        src.client_id AS src_id,
        trg.client_id AS trg_id,
        CASE
            WHEN src.client_id IS NULL THEN 'Only in landing'
            WHEN trg.client_id IS NULL THEN 'Only in source'
            WHEN src.first_name <> trg.first_name THEN 'Mismatch in client first_name'
            WHEN src.last_name <> trg.last_name THEN 'Mismatch in client last_name'
            WHEN src.email <> trg.email THEN 'Mismatch in client email'
            WHEN src.phone_code <> trg.phone_code THEN 'Mismatch in client phone_code'
            WHEN src.phone_number <> trg.phone_number THEN 'Mismatch in client phone_number'
            WHEN src.first_purchase <> trg.first_purchase THEN 'Mismatch in client first_purchase'
            WHEN src.valid_from <> trg.valid_from THEN 'Mismatch in client valid_from'
            WHEN src.valid_to <> trg.valid_to THEN 'Mismatch in client valid_to'
            ELSE 'Match'
        END AS reconciliation_status
    FROM lnd.lnd_s2_clients trg
    FULL OUTER JOIN (
        SELECT * FROM dblink(
            'dbname=dwh_src_hw_db user=postgres password=CretuPaul1990. host=localhost',
            'SELECT client_id, first_name, last_name, email, phone_code, phone_number, first_purchase, valid_from, valid_to FROM s2.s2_clients'
        ) AS src(
            client_id VARCHAR(256),
            first_name VARCHAR(256),
            last_name VARCHAR(256),
            email VARCHAR(256),
            phone_code VARCHAR(256),
            phone_number VARCHAR(256),
            first_purchase VARCHAR(256),
            valid_from VARCHAR(256),
            valid_to VARCHAR(256)
        )
    ) src
    ON src.client_id = trg.client_id
)
INSERT INTO lnd.reconciliation_results (table_name, key_column, src_id, trg_id, reconciliation_status)
SELECT *
FROM reconciliation_results_cte
WHERE reconciliation_status <> 'Match';


-- ==============================================
-- Reconciliation for landing layer
-- ==============================================

---reconciliation for channels 

WITH reconciliation_results AS (
    SELECT     
        'dwh_channels' AS table_name,
        'channel_id' AS key_column,
        src.channel_id AS src_id,
        trg.channel_id AS trg_id,
        CASE
            WHEN src.channel_id IS NULL THEN 'Only in DWH'
            WHEN trg.channel_src_id IS NULL THEN 'Only in Landing'
            WHEN src.channel_name <> trg.channel_name THEN 'Mismatch in channel_name'
            WHEN src.norm_location_id <> trg.location_id THEN 'Mismatch in location_id'
            ELSE 'Match'
        END AS reconciliation_status
    FROM dwh.dwh_channels trg
    FULL OUTER JOIN (
        -- S1: map channel_location (name) to DWH location_id
        SELECT s1.channel_id,
               s1.channel_name,
               dl.location_id AS norm_location_id
        FROM lnd.lnd_s1_channels s1
        LEFT JOIN dwh.dwh_locations dl
          ON dl.location_name = s1.channel_location

        UNION ALL

        -- S2: map landing location_id (source ID) to DWH location_src_id
        SELECT s2.channel_id,
               s2.channel_name,
               dl.location_id AS norm_location_id
        FROM lnd.lnd_s2_channels s2
        LEFT JOIN dwh.dwh_locations dl
          ON dl.location_src_id = s2.location_id
    ) src
    ON src.channel_id = trg.channel_src_id
)
INSERT INTO lnd.reconciliation_results
SELECT *
FROM reconciliation_results
WHERE reconciliation_status <> 'Match';


---reconciliation of locations

WITH reconciliation_results AS (
    SELECT
        'dwh_locations' AS table_name,
        'location_id' AS key_column,
        
        -- src_id: actual landing ID from S2, NULL if coming from S1 (name only)
        src.s2_location_id AS src_id,
        
        -- trg_id: DWH surrogate
        trg.location_id AS trg_id,
        
        CASE
            WHEN src.norm_location_id IS NULL THEN 'Only in DWH'
            WHEN trg.location_id IS NULL THEN 'Only in Landing'
            WHEN src.s1_location_name IS NOT NULL AND src.s1_location_name <> trg.location_name THEN 'Mismatch in location_name from S1'
            WHEN src.s2_location_id IS NOT NULL AND src.s2_location_id <> trg.location_src_id THEN 'Mismatch in location_src_id from S2'
            ELSE 'Match'
        END AS reconciliation_status
    FROM dwh.dwh_locations trg
    FULL OUTER JOIN (
        -- S1: get location names from channels, no landing ID available
        SELECT DISTINCT
            s1.channel_location AS s1_location_name,
            NULL::VARCHAR AS s2_location_id,
            dl.location_id AS norm_location_id
        FROM lnd.lnd_s1_channels s1
        LEFT JOIN dwh.dwh_locations dl
          ON dl.location_name = s1.channel_location

        UNION ALL

        -- S2: get source IDs
        SELECT DISTINCT
            NULL::VARCHAR AS s1_location_name,
            s2.location_id AS s2_location_id,
            dl.location_id AS norm_location_id
        FROM lnd.lnd_s2_locations s2
        LEFT JOIN dwh.dwh_locations dl
          ON dl.location_src_id = s2.location_id
    ) src
    ON src.norm_location_id = trg.location_id
)
INSERT INTO lnd.reconciliation_results
SELECT *
FROM reconciliation_results
WHERE reconciliation_status <> 'Match';

--reconciliation of products

WITH reconciliation_results AS (
    SELECT
        'dwh_products' AS table_name,
        'product_id' AS key_column,
        src.product_id AS src_id,
        trg.product_id AS trg_id,
        CASE
            WHEN src.product_id IS NULL THEN 'Only in DWH'
            WHEN trg.product_src_id IS NULL THEN 'Only in Landing'
            WHEN src.product_name <> trg.product_name THEN 'Mismatch in product_name'
           WHEN ROUND(src.product_cost::NUMERIC, 2) <> ROUND(trg.product_cost, 2) 
           THEN 'Mismatch in product_cost'
            ELSE 'Match'
        END AS reconciliation_status
    FROM dwh.dwh_products trg
    FULL OUTER JOIN (
        -- S1 landing
        SELECT product_id,
               product_name,
               cost AS product_cost
        FROM lnd.lnd_s1_products

        UNION ALL

        -- S2: extract product info from client sales
        SELECT DISTINCT product_id,
               product_name,
               product_price AS product_cost
        FROM lnd.lnd_s2_client_sales
    ) src
    ON src.product_id = trg.product_src_id
)
INSERT INTO lnd.reconciliation_results
SELECT *
FROM reconciliation_results
WHERE reconciliation_status <> 'Match';


--reconciliation clients 

-- Step 1: Merge S1 and S2 clients based on email
WITH merged_clients AS (
    SELECT
        COALESCE(s2.client_id, s1.client_id) AS client_id,
        COALESCE(s2.first_name, s1.first_name) AS first_name,
        s1.middle_name,  -- only from S1
        COALESCE(s2.last_name, s1.last_name) AS last_name,
        COALESCE(s2.email, s1.email) AS email,
        COALESCE(
    CASE 
        WHEN s2.phone_code IS NOT NULL AND s2.phone_number IS NOT NULL 
        THEN s2.phone_code || s2.phone_number
    END,
    s1.phone
) AS phone
,
        COALESCE(s2.first_purchase, s1.first_purchase) AS first_purchase,
        s2.valid_from,
        s2.valid_to
    FROM lnd.lnd_s1_clients s1
    FULL OUTER JOIN lnd.lnd_s2_clients s2
        ON s1.email = s2.email
)
,

-- Step 2: Reconcile merged landing clients vs DWH
reconciliation_results AS (
    SELECT
        'dwh_clients' AS table_name,
        'client_id' AS key_column,
        src.client_id AS src_id,
        trg.client_src_id AS trg_id,
        CASE
            WHEN src.client_id IS NULL THEN 'Only in DWH'
            WHEN trg.client_src_id IS NULL THEN 'Only in Landing'
            WHEN TRIM(src.first_name) <> TRIM(trg.first_name) THEN 'Mismatch in first_name'
            WHEN COALESCE(TRIM(src.middle_name), 'N/A') <> TRIM(trg.middle_name) THEN 'Mismatch in middle_name'
            WHEN TRIM(src.last_name) <> TRIM(trg.last_name) THEN 'Mismatch in last_name'
            WHEN TRIM(src.email) <> TRIM(trg.email) THEN 'Mismatch in email'
            WHEN COALESCE(TRIM(src.phone), '') <> COALESCE(TRIM(trg.phone_number), '') THEN 'Mismatch in phone'
            WHEN src.first_purchase::DATE <> trg.first_purchase_date THEN 'Mismatch in first_purchase'
            WHEN COALESCE(src.valid_from::DATE, '2000-01-01') <> trg.valid_from THEN 'Mismatch in client valid_from'
            WHEN COALESCE(src.valid_to::DATE, '2000-01-01') <> trg.valid_to THEN 'Mismatch in valid_to'
            ELSE 'Match'
        END AS reconciliation_status
    FROM dwh.dwh_clients trg
    FULL OUTER JOIN merged_clients src
        ON src.email = trg.email  -- reconcile by email
)

-- Step 3: Insert only mismatches
INSERT INTO lnd.reconciliation_results
SELECT *
FROM reconciliation_results
WHERE reconciliation_status <> 'Match';



---reconciliation sales
WITH src_sales AS (
    -- S1 sales normalized
    SELECT
        dc.client_src_id      AS norm_client_id,    -- DWH surrogate
        dch.channel_src_id    AS norm_channel_id,
        dp.product_src_id     AS norm_product_id,
        s1.sale_date::date     AS order_created,
        s1.sale_date::date AS order_completed,
        s1.units::numeric      AS quantity,
        s1.client_id,
        s1.channel_id,
        s1.product_id
    FROM lnd.lnd_s1_sales s1
    LEFT JOIN dwh.dwh_clients dc 
        ON dc.client_src_id = s1.client_id
    LEFT JOIN dwh.dwh_channels dch 
        ON dch.channel_src_id = s1.channel_id
    LEFT JOIN dwh.dwh_products dp 
        ON dp.product_src_id = s1.product_id

    UNION ALL

    -- S2 sales normalized
    SELECT
        dc.client_src_id      AS norm_client_id,
        dch.channel_src_id    AS norm_channel_id,
        dp.product_src_id     AS norm_product_id,
        s2.saled_at::date AS order_created,
        s2.sold_date::date AS order_completed,
        s2.product_amount::numeric AS quantity,
        s2.client_id,
        s2.channel_id,
        s2.product_id
    FROM lnd.lnd_s2_client_sales s2
    LEFT JOIN dwh.dwh_clients dc 
        ON dc.client_src_id = s2.client_id
    LEFT JOIN dwh.dwh_channels dch 
        ON dch.channel_src_id = s2.channel_id
    LEFT JOIN dwh.dwh_products dp 
        ON dp.product_src_id = s2.product_id
),
trg_sales AS (
    SELECT
        ds.sale_id,
        dc.client_src_id   AS src_client_id,
        dch.channel_src_id AS src_channel_id,
        dp.product_src_id  AS src_product_id,
        ds.order_created,
        ds.order_completed,
        ds.quantity,
        ds.client_id,
        ds.channel_id,
        ds.product_id
    FROM dwh.dwh_sales ds
    JOIN dwh.dwh_clients dc   ON ds.client_id = dc.client_id
    JOIN dwh.dwh_channels dch ON ds.channel_id = dch.channel_id
    JOIN dwh.dwh_products dp  ON ds.product_id = dp.product_id
),
reconciliation_results AS (
    SELECT
        'dwh_sales' AS table_name,
        'client_id, channel_id, product_id, order_created' AS key_column,

        NULLIF(CONCAT_WS('|', src.client_id, src.channel_id, src.product_id, src.order_created), '') AS src_id,
        NULLIF(CONCAT_WS('|', trg.client_id, trg.channel_id, trg.product_id, trg.order_created), '') AS trg_id,

        CASE
            -- Only in DWH
            WHEN src.norm_client_id IS NULL AND src.norm_channel_id IS NULL 
                 AND src.norm_product_id IS NULL AND src.order_created IS NULL
                THEN 'Only in DWH'

            -- Only in Landing
            WHEN trg.src_client_id IS NULL AND trg.src_channel_id IS NULL 
                 AND trg.src_product_id IS NULL AND trg.order_created IS NULL
                THEN 'Only in Landing'

            -- Data mismatches
            WHEN src.norm_client_id <> trg.src_client_id THEN 'Mismatch in client_id'
            WHEN src.norm_channel_id <> trg.src_channel_id THEN 'Mismatch in channel_id'
            WHEN src.norm_product_id <> trg.src_product_id THEN 'Mismatch in product_id'
            WHEN COALESCE(src.order_created, '2000-01-01') <> trg.order_created THEN 'Mismatch in order_created'
            WHEN COALESCE(src.order_completed, '2000-01-01') <> trg.order_completed THEN 'Mismatch in order_completed'
            WHEN ROUND(src.quantity::numeric,2) <> ROUND(trg.quantity::numeric,2) THEN 'Mismatch in quantity'

            ELSE 'Match'
        END AS reconciliation_status
    FROM trg_sales trg
    FULL OUTER JOIN src_sales src
  ON src.norm_client_id  = trg.src_client_id
 AND src.norm_channel_id = trg.src_channel_id
 AND src.norm_product_id= trg.src_product_id
 AND src.order_created         = trg.order_created
)
INSERT INTO lnd.reconciliation_results
SELECT *
FROM reconciliation_results
WHERE reconciliation_status <> 'Match';





-- ==============================================
-- Reconciliation for DWH
-- ==============================================

-- Dashboard reconciliation
WITH source_data AS (
    -- Source: DWH tables
    SELECT
        ds.sale_id,
        dc.first_name AS client_first_name,
        dc.last_name AS client_last_name,
        dc.middle_name AS client_middle_name,
        dc.email,
        dc.phone_number AS phone_number,
        ch.channel_name,
        loc.location_name,
        p.product_name,
        ROUND(ds.quantity * p.product_cost, 2) AS total_cost
    FROM dwh.dwh_sales ds
    JOIN dwh.dwh_clients dc ON ds.client_id = dc.client_id
    JOIN dwh.dwh_channels ch ON ds.channel_id = ch.channel_id
    JOIN dwh.dwh_products p ON ds.product_id = p.product_id
    JOIN dwh.dwh_locations loc ON ch.location_id = loc.location_id
),
dashboard_data AS (
    -- Target: Dashboard
    SELECT *
    FROM dm.dm_main_dashboard dmd
),
reconciliation_results AS (
    SELECT
        'dm_main_dashboard' AS table_name,
        'sale_id' AS key_column,
        sd.sale_id AS src_id,
        dd.id AS trg_id,
        
        CASE
            WHEN sd.sale_id IS NULL THEN 'Only in dashboard'
            WHEN dd.id IS NULL THEN 'Only in source DWH'
            WHEN sd.client_first_name <> dd.client_first_name THEN 'Mismatch in client_first_name'
            WHEN sd.client_last_name <> dd.client_last_name THEN 'Mismatch in client_last_name'
            WHEN COALESCE(sd.client_middle_name,'') <> COALESCE(dd.client_middle_name,'') THEN 'Mismatch in client_middle_name'
            WHEN COALESCE(sd.email,'') <> COALESCE(dd.email,'') THEN 'Mismatch in email'
            WHEN COALESCE(sd.phone_number,'') <> COALESCE(dd.phone_number,'') THEN 'Mismatch in phone_number'
            WHEN sd.channel_name <> dd.channel_name THEN 'Mismatch in channel_name'
            WHEN sd.location_name <> dd.location_name THEN 'Mismatch in location_name'
            WHEN sd.product_name <> dd.product_name THEN 'Mismatch in product_name'
            WHEN ROUND(sd.total_cost,2) <> ROUND(dd.total_cost,2) THEN 'Mismatch in total_cost'
            ELSE 'Match'
        END AS reconciliation_status
    FROM source_data sd
    FULL OUTER JOIN dashboard_data dd
        ON sd.sale_id = dd.id
)
-- Insert only mismatches into the reconciliation table
INSERT INTO lnd.reconciliation_results
SELECT *
FROM reconciliation_results
WHERE reconciliation_status <> 'Match';

select *
from lnd.reconciliation_results
order by reconciliation_status ;
select count(*) from dm.dm_main_dashboard dmd;


SELECT
    table_name,
    key_column,
    reconciliation_status,
    COUNT(*) AS affected_rows,
    STRING_AGG(src_id, ', ' ORDER BY src_id) AS sample_src_ids,
    STRING_AGG(trg_id, ', ' ORDER BY trg_id) AS sample_trg_ids
FROM lnd.reconciliation_results
GROUP BY table_name, key_column, reconciliation_status
ORDER BY table_name, reconciliation_status;


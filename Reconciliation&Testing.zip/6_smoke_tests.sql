-- ==============================================
-- 0. Create Results Table
-- ==============================================
CREATE TABLE IF NOT EXISTS pipeline_test_results (
    table_name VARCHAR(256),
    test_type VARCHAR(256),
    result VARCHAR(10),
    count_value BIGINT,
    issue_description TEXT,
    test_run_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Optional: clear old results
TRUNCATE TABLE pipeline_test_results;

-- ==============================================
-- 1. S1 Layer Tests
-- ==============================================

-- --- S1 Channels
INSERT INTO pipeline_test_results
SELECT 's1_channels','row_count',
       CASE WHEN COUNT(*)>0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN 'Table is empty' ELSE NULL END
FROM lnd.lnd_s1_channels;

INSERT INTO pipeline_test_results
SELECT 's1_channels','duplicate_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Duplicate channel_id found' ELSE NULL END
FROM (
    SELECT channel_id
    FROM lnd.lnd_s1_channels
    GROUP BY channel_id HAVING COUNT(*)>1
) t;

INSERT INTO pipeline_test_results
SELECT 's1_channels','null_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Null channel_id found' ELSE NULL END
FROM lnd.lnd_s1_channels
WHERE channel_id IS NULL;




-- --- S1 Sales
INSERT INTO pipeline_test_results
SELECT 's1_sales','row_count',
       CASE WHEN COUNT(*)>0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN 'Table is empty' ELSE NULL END
FROM lnd.lnd_s1_sales;

INSERT INTO pipeline_test_results
SELECT 's1_sales','duplicate_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Duplicate composite key found' ELSE NULL END
FROM (
    SELECT client_id, channel_id, product_id, sale_date
    FROM lnd.lnd_s1_sales
    GROUP BY client_id, channel_id, product_id, sale_date
    HAVING COUNT(*)>1
) t;

INSERT INTO pipeline_test_results
SELECT 's1_sales','null_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Null key(s) found' ELSE NULL END
FROM lnd.lnd_s1_sales
WHERE client_id IS NULL OR channel_id IS NULL OR product_id IS NULL OR sale_date IS NULL;

-- --- S1 Products
INSERT INTO pipeline_test_results
SELECT 's1_products','row_count',
       CASE WHEN COUNT(*)>0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN 'Table is empty' ELSE NULL END
FROM lnd.lnd_s1_products;

INSERT INTO pipeline_test_results
SELECT 's1_products','duplicate_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Duplicate product_id found' ELSE NULL END
FROM (
    SELECT product_id
    FROM lnd.lnd_s1_products
    GROUP BY product_id HAVING COUNT(*)>1
) t;

INSERT INTO pipeline_test_results
SELECT 's1_products','null_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Null product_id found' ELSE NULL END
FROM lnd.lnd_s1_products
WHERE product_id IS NULL;

-- --- S1 Clients
INSERT INTO pipeline_test_results
SELECT 's1_clients','row_count',
       CASE WHEN COUNT(*)>0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN 'Table is empty' ELSE NULL END
FROM lnd.lnd_s1_clients;

INSERT INTO pipeline_test_results
SELECT 's1_clients','duplicate_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Duplicate client_id found' ELSE NULL END
FROM (
    SELECT client_id
    FROM lnd.lnd_s1_clients
    GROUP BY client_id HAVING COUNT(*)>1
) t;

INSERT INTO pipeline_test_results
SELECT 's1_clients','null_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Null client_id found' ELSE NULL END
FROM lnd.lnd_s1_clients
WHERE client_id IS NULL;

-- ==============================================
-- 2. S2 Layer Tests
-- ==============================================

-- --- S2 Channels
INSERT INTO pipeline_test_results
SELECT 's2_channels','row_count',
       CASE WHEN COUNT(*)>0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN 'Table is empty' ELSE NULL END
FROM lnd.lnd_s2_channels;

INSERT INTO pipeline_test_results
SELECT 's2_channels','duplicate_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Duplicate channel_id found' ELSE NULL END
FROM (
    SELECT channel_id
    FROM lnd.lnd_s2_channels
    GROUP BY channel_id HAVING COUNT(*)>1
) t;

INSERT INTO pipeline_test_results
SELECT 's2_channels','null_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Null channel_id found' ELSE NULL END
FROM lnd.lnd_s2_channels
WHERE channel_id IS NULL;

-- --- S2 Locations
INSERT INTO pipeline_test_results
SELECT 's2_locations','row_count',
       CASE WHEN COUNT(*)>0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN 'Table is empty' ELSE NULL END
FROM lnd.lnd_s2_locations;

INSERT INTO pipeline_test_results
SELECT 's2_locations','duplicate_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Duplicate location_id found' ELSE NULL END
FROM (
    SELECT location_id
    FROM lnd.lnd_s2_locations
    GROUP BY location_id HAVING COUNT(*)>1
) t;

INSERT INTO pipeline_test_results
SELECT 's2_locations','null_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Null location_id found' ELSE NULL END
FROM lnd.lnd_s2_locations
WHERE location_id IS NULL;

-- --- S2 Client Sales
INSERT INTO pipeline_test_results
SELECT 's2_client_sales','row_count',
       CASE WHEN COUNT(*)>0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN 'Table is empty' ELSE NULL END
FROM lnd.lnd_s2_client_sales;

INSERT INTO pipeline_test_results
SELECT 's2_client_sales','duplicate_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Duplicate composite key found' ELSE NULL END
FROM (
    SELECT client_id, channel_id, product_id, saled_at
    FROM lnd.lnd_s2_client_sales
    GROUP BY client_id, channel_id, product_id, saled_at HAVING COUNT(*)>1
) t;

INSERT INTO pipeline_test_results
SELECT 's2_client_sales','null_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Null key(s) found' ELSE NULL END
FROM lnd.lnd_s2_client_sales
WHERE client_id IS NULL OR channel_id IS NULL OR product_id IS NULL OR saled_at IS NULL;

-- --- S2 Clients
INSERT INTO pipeline_test_results
SELECT 's2_clients','row_count',
       CASE WHEN COUNT(*)>0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN 'Table is empty' ELSE NULL END
FROM lnd.lnd_s2_clients;

INSERT INTO pipeline_test_results
SELECT 's2_clients','duplicate_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Duplicate client_id found' ELSE NULL END
FROM (
    SELECT client_id
    FROM lnd.lnd_s2_clients
    GROUP BY client_id HAVING COUNT(*)>1
) t;

INSERT INTO pipeline_test_results
SELECT 's2_clients','null_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Null client_id or email found' ELSE NULL END
FROM lnd.lnd_s2_clients
WHERE client_id IS NULL OR email IS NULL;

-- ==============================================
-- 3. DWH Layer Tests
-- ==============================================
-- Similar pattern for DWH channels, locations, products, clients, sales

-- --- DWH Channels
INSERT INTO pipeline_test_results
SELECT 'dwh_channels','row_count',
       CASE WHEN COUNT(*)>0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN 'Table is empty' ELSE NULL END
FROM dwh.dwh_channels;

INSERT INTO pipeline_test_results
SELECT 'dwh_channels','duplicate_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Duplicate channel_id found' ELSE NULL END
FROM (
    SELECT channel_id FROM dwh.dwh_channels GROUP BY channel_id HAVING COUNT(*)>1
) t;

INSERT INTO pipeline_test_results
SELECT 'dwh_channels','null_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Null channel_id found' ELSE NULL END
FROM dwh.dwh_channels WHERE channel_id IS NULL;

-- --- DWH Locations
INSERT INTO pipeline_test_results
SELECT 'dwh_locations','row_count',
       CASE WHEN COUNT(*)>0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN 'Table is empty' ELSE NULL END
FROM dwh.dwh_locations;

INSERT INTO pipeline_test_results
SELECT 'dwh_locations','duplicate_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Duplicate location_id found' ELSE NULL END
FROM (
    SELECT location_id FROM dwh.dwh_locations GROUP BY location_id HAVING COUNT(*)>1
) t;

INSERT INTO pipeline_test_results
SELECT 'dwh_locations','null_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Null location_id found' ELSE NULL END
FROM dwh.dwh_locations WHERE location_id IS NULL;

-- --- DWH Products
INSERT INTO pipeline_test_results
SELECT 'dwh_products','row_count',
       CASE WHEN COUNT(*)>0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN 'Table is empty' ELSE NULL END
FROM dwh.dwh_products;

INSERT INTO pipeline_test_results
SELECT 'dwh_products','duplicate_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Duplicate product_src_id found' ELSE NULL END
FROM (
    SELECT product_src_id FROM dwh.dwh_products GROUP BY product_src_id HAVING COUNT(*)>1
) t;

INSERT INTO pipeline_test_results
SELECT 'dwh_products','null_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Null product_src_id found' ELSE NULL END
FROM dwh.dwh_products WHERE product_src_id IS NULL;

-- --- DWH Clients
INSERT INTO pipeline_test_results
SELECT 'dwh_clients','row_count',
       CASE WHEN COUNT(*)>0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN 'Table is empty' ELSE NULL END
FROM dwh.dwh_clients;

INSERT INTO pipeline_test_results
SELECT 'dwh_clients','duplicate_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Duplicate client_src_id found' ELSE NULL END
FROM (
    SELECT client_src_id FROM dwh.dwh_clients GROUP BY client_src_id HAVING COUNT(*)>1
) t;

INSERT INTO pipeline_test_results
SELECT 'dwh_clients','null_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Null client_src_id found' ELSE NULL END
FROM dwh.dwh_clients WHERE client_src_id IS NULL;

-- --- DWH Sales
INSERT INTO pipeline_test_results
SELECT 'dwh_sales','row_count',
       CASE WHEN COUNT(*)>0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN 'Table is empty' ELSE NULL END
FROM dwh.dwh_sales;

INSERT INTO pipeline_test_results
SELECT 'dwh_sales','duplicate_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Duplicate composite key found' ELSE NULL END
FROM (
    SELECT client_id, channel_id, product_id, order_created
    FROM dwh.dwh_sales
    GROUP BY client_id, channel_id, product_id, order_created
    HAVING COUNT(*)>1
) t;

INSERT INTO pipeline_test_results
SELECT 'dwh_sales','null_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Null key(s) found' ELSE NULL END
FROM dwh.dwh_sales
WHERE client_id IS NULL OR channel_id IS NULL OR product_id IS NULL OR order_created IS NULL;

-- ==============================================
-- 4. Dashboard Layer Tests
-- ==============================================

-- --- DM Main Dashboard
INSERT INTO pipeline_test_results
SELECT 'dm_main_dashboard','row_count',
       CASE WHEN COUNT(*)>0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN 'Table is empty' ELSE NULL END
FROM dm.dm_main_dashboard;

INSERT INTO pipeline_test_results
SELECT 'dm_main_dashboard','duplicate_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Duplicate id found' ELSE NULL END
FROM (
    SELECT id FROM dm.dm_main_dashboard GROUP BY id HAVING COUNT(*)>1
) t;

INSERT INTO pipeline_test_results
SELECT 'dm_main_dashboard','null_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Null id or email found' ELSE NULL END
FROM dm.dm_main_dashboard
WHERE id IS NULL OR email IS NULL;


-- ==============================================
-- Smoke Test: Schema Validation
-- ==============================================

-- --- S1 Channels
INSERT INTO pipeline_test_results
SELECT 's1_channels','schema_validation',
       CASE WHEN COUNT(*) = 3 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) <> 3 THEN 'Missing or extra columns in s1_channels' ELSE NULL END
FROM information_schema.columns
WHERE table_schema = 'lnd' AND table_name = 'lnd_s1_channels'
  AND column_name IN ('channel_id','channel_name','channel_location');

-- --- S1 Sales
INSERT INTO pipeline_test_results
SELECT 's1_sales','schema_validation',
       CASE WHEN COUNT(*) = 6 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) <> 6 THEN 'Missing or extra columns in s1_sales' ELSE NULL END
FROM information_schema.columns
WHERE table_schema = 'lnd' AND table_name = 'lnd_s1_sales'
  AND column_name IN ('client_id','channel_id','product_id','sale_date','units','purchase_date');

-- --- S1 Products
INSERT INTO pipeline_test_results
SELECT 's1_products','schema_validation',
       CASE WHEN COUNT(*) = 3 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) <> 3 THEN 'Missing or extra columns in s1_products' ELSE NULL END
FROM information_schema.columns
WHERE table_schema = 'lnd' AND table_name = 'lnd_s1_products'
  AND column_name IN ('product_id','product_name','cost');

-- --- S1 Clients
INSERT INTO pipeline_test_results
SELECT 's1_clients','schema_validation',
       CASE WHEN COUNT(*) = 7 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) <> 7 THEN 'Missing or extra columns in s1_clients' ELSE NULL END
FROM information_schema.columns
WHERE table_schema = 'lnd' AND table_name = 'lnd_s1_clients'
  AND column_name IN ('client_id','first_name','middle_name','last_name', 'email', 'phone', 'first_purchase');

-- --- S2 Channels
INSERT INTO pipeline_test_results
SELECT 's2_channels','schema_validation',
       CASE WHEN COUNT(*) = 3 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) <> 3 THEN 'Missing or extra columns in s2_channels' ELSE NULL END
FROM information_schema.columns
WHERE table_schema = 'lnd' AND table_name = 'lnd_s2_channels'
  AND column_name IN ('channel_id','channel_name','location_id');

-- --- S2 Locations
INSERT INTO pipeline_test_results
SELECT 's2_locations','schema_validation',
       CASE WHEN COUNT(*) = 2 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) <> 2 THEN 'Missing or extra columns in s2_locations' ELSE NULL END
FROM information_schema.columns
WHERE table_schema = 'lnd' AND table_name = 'lnd_s2_locations'
  AND column_name IN ('location_id','location_name');

-- --- S2 Client Sales
INSERT INTO pipeline_test_results
SELECT 's2_client_sales','schema_validation',
       CASE WHEN COUNT(*) = 8 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) <> 8 THEN 'Missing or extra columns in s2_client_sales' ELSE NULL END
FROM information_schema.columns
WHERE table_schema = 'lnd' AND table_name = 'lnd_s2_client_sales'
  AND column_name IN ('client_id','channel_id','product_id','saled_at','product_name','product_price','product_amount','sold_date');

-- --- S2 Clients
INSERT INTO pipeline_test_results
SELECT 's2_clients','schema_validation',
       CASE WHEN COUNT(*) = 9 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) <> 9 THEN 'Missing or extra columns in s2_clients' ELSE NULL END
FROM information_schema.columns
WHERE table_schema = 'lnd' AND table_name = 'lnd_s2_clients'
  AND column_name IN ('client_id','first_name','last_name', 'email', 'phone_code','phone_number', 'first_purchase','valid_from','valid_to');

-- --- DWH Channels
INSERT INTO pipeline_test_results
SELECT 'dwh_channels','schema_validation',
       CASE WHEN COUNT(*) = 4 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) <> 4 THEN 'Missing or extra columns in dwh_channels' ELSE NULL END
FROM information_schema.columns
WHERE table_schema = 'dwh' AND table_name = 'dwh_channels'
  AND column_name IN ('channel_id','channel_name','location_id','channel_src_id');

-- --- DWH Locations
INSERT INTO pipeline_test_results
SELECT 'dwh_locations','schema_validation',
       CASE WHEN COUNT(*) = 3 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) <> 3 THEN 'Missing or extra columns in dwh_locations' ELSE NULL END
FROM information_schema.columns
WHERE table_schema = 'dwh' AND table_name = 'dwh_locations'
  AND column_name IN ('location_id','location_name','location_src_id');

-- --- DWH Products
INSERT INTO pipeline_test_results
SELECT 'dwh_products','schema_validation',
       CASE WHEN COUNT(*) = 4 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) <> 4 THEN 'Missing or extra columns in dwh_products' ELSE NULL END
FROM information_schema.columns
WHERE table_schema = 'dwh' AND table_name = 'dwh_products'
  AND column_name IN ('product_src_id','product_name','product_id','product_cost');

-- --- DWH Clients
INSERT INTO pipeline_test_results
SELECT 'dwh_clients','schema_validation',
       CASE WHEN COUNT(*) = 11 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) <> 11 THEN 'Missing or extra columns in dwh_clients' ELSE NULL END
FROM information_schema.columns
WHERE table_schema = 'dwh' AND table_name = 'dwh_clients'
  AND column_name IN ('client_src_id','client_name','client_id','first_name','middle_name','last_name','email','phone_number','valid_from','valid_to','is_valid','first_purchase_date');

-- --- DWH Sales
INSERT INTO pipeline_test_results
SELECT 'dwh_sales','schema_validation',
       CASE WHEN COUNT(*) = 7 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) <> 7 THEN 'Missing or extra columns in dwh_sales' ELSE NULL END
FROM information_schema.columns
WHERE table_schema = 'dwh' AND table_name = 'dwh_sales'
  AND column_name IN ('sale_id','client_id','channel_id','product_id','order_created','order_completed','quantity');

-- --- DM Main Dashboard
INSERT INTO pipeline_test_results
SELECT 'dm_main_dashboard','schema_validation',
       CASE WHEN COUNT(*) = 10 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) <> 10 THEN 'Missing or extra columns in dm_main_dashboard' ELSE NULL END
FROM information_schema.columns
WHERE table_schema = 'dm' AND table_name = 'dm_main_dashboard'
  AND column_name IN ('id','client_first_name','client_last_name','client_middle_name','email','phone_number','channel_name','location_name','product_name','total_cost');


 
 
 -- ==============================================
-- 6. Referential Integrity Checks
-- ==============================================

-- --- S1 Sales FKs
INSERT INTO pipeline_test_results
SELECT 's1_sales','fk_channel_check',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       'Invalid channel_id in s1_sales not found in s1_channels'
FROM lnd.lnd_s1_sales s
LEFT JOIN lnd.lnd_s1_channels c ON s.channel_id = c.channel_id
WHERE c.channel_id IS NULL;

INSERT INTO pipeline_test_results
SELECT 's1_sales','fk_product_check',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       'Invalid product_id in s1_sales not found in s1_products'
FROM lnd.lnd_s1_sales s
LEFT JOIN lnd.lnd_s1_products p ON s.product_id = p.product_id
WHERE p.product_id IS NULL;

INSERT INTO pipeline_test_results
SELECT 's1_sales','fk_client_check',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       'Invalid client_id in s1_sales not found in s1_clients'
FROM lnd.lnd_s1_sales s
LEFT JOIN lnd.lnd_s1_clients c ON s.client_id = c.client_id
WHERE c.client_id IS NULL;


-- --- S2 Client Sales FKs
INSERT INTO pipeline_test_results
SELECT 's2_client_sales','fk_channel_check',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       'Invalid channel_id in s2_client_sales not found in s2_channels'
FROM lnd.lnd_s2_client_sales s
LEFT JOIN lnd.lnd_s2_channels c ON s.channel_id = c.channel_id
WHERE c.channel_id IS NULL;

INSERT INTO pipeline_test_results
SELECT 's2_client_sales','fk_product_check',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       'Invalid product_id in s2_client_sales not found in s1_products'
FROM lnd.lnd_s2_client_sales s
LEFT JOIN lnd.lnd_s1_products p ON s.product_id = p.product_id
WHERE p.product_id IS NULL;

INSERT INTO pipeline_test_results
SELECT 's2_client_sales','fk_client_check',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       'Invalid client_id in s2_client_sales not found in s2_clients'
FROM lnd.lnd_s2_client_sales s
LEFT JOIN lnd.lnd_s2_clients c ON s.client_id = c.client_id
WHERE c.client_id IS NULL;


-- --- DWH Sales FKs
INSERT INTO pipeline_test_results
SELECT 'dwh_sales','fk_channel_check',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       'Invalid channel_id in dwh_sales not found in dwh_channels'
FROM dwh.dwh_sales s
LEFT JOIN dwh.dwh_channels c ON s.channel_id = c.channel_id
WHERE c.channel_id IS NULL;

INSERT INTO pipeline_test_results
SELECT 'dwh_sales','fk_product_check',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       'Invalid product_id in dwh_sales not found in dwh_products'
FROM dwh.dwh_sales s
LEFT JOIN dwh.dwh_products p ON s.product_id = p.product_id
WHERE p.product_id IS NULL;

INSERT INTO pipeline_test_results
SELECT 'dwh_sales','fk_client_check',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       'Invalid client_id in dwh_sales not found in dwh_clients'
FROM dwh.dwh_sales s
LEFT JOIN dwh.dwh_clients c ON s.client_id = c.client_id
WHERE c.client_id IS NULL;


-- ==============================================
-- 7. Value Sanity Checks
-- ==============================================

-- --- Units / Quantities should be positive
INSERT INTO pipeline_test_results
SELECT 's1_sales','negative_units',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       'Negative or zero units found'
FROM lnd.lnd_s1_sales
WHERE units::numeric <= 0;

INSERT INTO pipeline_test_results
SELECT 'dwh_sales','negative_quantity',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       'Negative or zero quantity found'
FROM dwh.dwh_sales
WHERE quantity <= 0;

-- --- Product costs should be positive
INSERT INTO pipeline_test_results
SELECT 's1_products','negative_cost',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       'Negative or zero product cost found'
FROM lnd.lnd_s1_products
WHERE cost::numeric <= 0;

INSERT INTO pipeline_test_results
SELECT 'dwh_products','negative_cost',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       'Negative or zero product cost found'
FROM dwh.dwh_products
WHERE product_cost::numeric <= 0;


-- ==============================================
-- 8. Date Validation Checks
-- ==============================================

-- --- Sales dates should not be in the future
INSERT INTO pipeline_test_results
SELECT 's1_sales','future_sale_date',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       'Future sale_date found'
FROM lnd.lnd_s1_sales
WHERE sale_date::date > CURRENT_DATE;

INSERT INTO pipeline_test_results
SELECT 'dwh_sales','future_order_created',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       'Future order_created found'
FROM dwh.dwh_sales
WHERE order_created > CURRENT_DATE;

-- --- Order completed should be >= order created
INSERT INTO pipeline_test_results
SELECT 'dwh_sales','order_date_consistency',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       'order_completed earlier than order_created'
FROM dwh.dwh_sales
WHERE order_completed < order_created;


 -- ==============================================
-- Check for correct data types
-- ==============================================


-- ==============================================
-- Data Type Check for S1 & S2 Tables (VARCHAR)
-- ==============================================

-- Example for S1 Channels
INSERT INTO pipeline_test_results
SELECT 's1_channels','datatype_check',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN NULL 
            ELSE 'Incorrect data type in columns: ' || STRING_AGG(column_name, ', ')
       END
FROM information_schema.columns
WHERE table_schema = 'lnd' AND table_name = 'lnd_s1_channels'
  AND data_type <> 'character varying';

-- --- S1 Sales
INSERT INTO pipeline_test_results
SELECT 's1_sales','datatype_check',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN NULL 
            ELSE 'Incorrect data type in columns: ' || STRING_AGG(column_name, ', ')
       END
FROM information_schema.columns
WHERE table_schema = 'lnd' AND table_name = 'lnd_s1_sales'
  AND data_type <> 'character varying';

-- --- S1 Products
INSERT INTO pipeline_test_results
SELECT 's1_products','datatype_check',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN NULL 
            ELSE 'Incorrect data type in columns: ' || STRING_AGG(column_name, ', ')
       END
FROM information_schema.columns
WHERE table_schema = 'lnd' AND table_name = 'lnd_s1_products'
  AND data_type <> 'character varying';

-- --- S1 Clients
INSERT INTO pipeline_test_results
SELECT 's1_clients','datatype_check',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN NULL 
            ELSE 'Incorrect data type in columns: ' || STRING_AGG(column_name, ', ')
       END
FROM information_schema.columns
WHERE table_schema = 'lnd' AND table_name = 'lnd_s1_clients'
  AND data_type <> 'character varying';

-- --- S2 Channels
INSERT INTO pipeline_test_results
SELECT 's2_channels','datatype_check',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN NULL 
            ELSE 'Incorrect data type in columns: ' || STRING_AGG(column_name, ', ')
       END
FROM information_schema.columns
WHERE table_schema = 'lnd' AND table_name = 'lnd_s2_channels'
  AND data_type <> 'character varying';

-- --- S2 Locations
INSERT INTO pipeline_test_results
SELECT 's2_locations','datatype_check',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN NULL 
            ELSE 'Incorrect data type in columns: ' || STRING_AGG(column_name, ', ')
       END
FROM information_schema.columns
WHERE table_schema = 'lnd' AND table_name = 'lnd_s2_locations'
  AND data_type <> 'character varying';

-- --- S2 Client Sales
INSERT INTO pipeline_test_results
SELECT 's2_client_sales','datatype_check',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN NULL 
            ELSE 'Incorrect data type in columns: ' || STRING_AGG(column_name, ', ')
       END
FROM information_schema.columns
WHERE table_schema = 'lnd' AND table_name = 'lnd_s2_client_sales'
  AND data_type <> 'character varying';

-- --- S2 Clients
INSERT INTO pipeline_test_results
SELECT 's2_clients','datatype_check',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN NULL 
            ELSE 'Incorrect data type in columns: ' || STRING_AGG(column_name, ', ')
       END
FROM information_schema.columns
WHERE table_schema = 'lnd' AND table_name = 'lnd_s2_clients'
  AND data_type <> 'character varying';

 
 
-- ==============================================
-- DM_DASHBOARD & DWH Data Type & Length Check (Enhanced)
-- ==============================================

-- --- DM Main Dashboard
INSERT INTO pipeline_test_results
SELECT 'dm_main_dashboard', 'datatype_check',
       CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) = 0 THEN NULL
            ELSE 'Incorrect data type or length in columns: ' || 
                 STRING_AGG(
                    column_name || ' (actual: ' ||
                    data_type ||
                    COALESCE(
                        CASE 
                            WHEN character_maximum_length IS NOT NULL 
                                THEN '(' || character_maximum_length || ')' 
                            WHEN numeric_precision IS NOT NULL 
                                THEN '(' || numeric_precision || ',' || numeric_scale || ')' 
                        END, '') || ')', 
                    ', '
                 )
       END
FROM information_schema.columns
WHERE table_schema = 'dm' AND table_name = 'dm_main_dashboard'
  AND (
        (column_name = 'id' AND data_type <> 'integer')
     OR (column_name = 'client_first_name' AND (data_type <> 'character varying' OR character_maximum_length <> 100))
     OR (column_name = 'client_last_name' AND (data_type <> 'character varying' OR character_maximum_length <> 100))
     OR (column_name = 'client_middle_name' AND (data_type <> 'character varying' OR character_maximum_length <> 70))
     OR (column_name = 'email' AND (data_type <> 'character varying' OR character_maximum_length <> 50))
     OR (column_name = 'phone_number' AND (data_type <> 'character varying' OR character_maximum_length <> 100))
     OR (column_name = 'channel_name' AND (data_type <> 'character varying' OR character_maximum_length <> 30))
     OR (column_name = 'location_name' AND (data_type <> 'character varying' OR character_maximum_length <> 100))
     OR (column_name = 'product_name' AND (data_type <> 'character varying' OR character_maximum_length <> 150))
     OR (column_name = 'total_cost' AND (data_type <> 'numeric' OR numeric_precision <> 18 OR numeric_scale <> 4))
      );

-- --- DWH Channels
INSERT INTO pipeline_test_results
SELECT 'dwh_channels', 'datatype_check',
       CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) = 0 THEN NULL
            ELSE 'Incorrect data type or length in columns: ' || 
                 STRING_AGG(
                    column_name || ' (actual: ' ||
                    data_type ||
                    COALESCE(
                        CASE 
                            WHEN character_maximum_length IS NOT NULL 
                                THEN '(' || character_maximum_length || ')' 
                            WHEN numeric_precision IS NOT NULL 
                                THEN '(' || numeric_precision || ',' || numeric_scale || ')' 
                        END, '') || ')', 
                    ', '
                 )
       END
FROM information_schema.columns
WHERE table_schema = 'dwh' AND table_name = 'dwh_channels'
  AND (
        (column_name = 'channel_id' AND data_type <> 'integer')
     OR (column_name = 'channel_src_id' AND (data_type <> 'character varying' OR character_maximum_length <> 10))
     OR (column_name = 'channel_name' AND (data_type <> 'character varying' OR character_maximum_length <> 30))
     OR (column_name = 'location_id' AND data_type <> 'integer')
      );

-- --- DWH Locations
INSERT INTO pipeline_test_results
SELECT 'dwh_locations', 'datatype_check',
       CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) = 0 THEN NULL
            ELSE 'Incorrect data type or length in columns: ' || 
                 STRING_AGG(
                    column_name || ' (actual: ' ||
                    data_type ||
                    COALESCE(
                        CASE 
                            WHEN character_maximum_length IS NOT NULL 
                                THEN '(' || character_maximum_length || ')' 
                            WHEN numeric_precision IS NOT NULL 
                                THEN '(' || numeric_precision || ',' || numeric_scale || ')' 
                        END, '') || ')', 
                    ', '
                 )
       END
FROM information_schema.columns
WHERE table_schema = 'dwh' AND table_name = 'dwh_locations'
  AND (
        (column_name = 'location_id' AND data_type <> 'integer')
     OR (column_name = 'location_src_id' AND (data_type <> 'character varying' OR character_maximum_length <> 10))
     OR (column_name = 'location_name' AND (data_type <> 'character varying' OR character_maximum_length <> 100))
      );

-- --- DWH Products
INSERT INTO pipeline_test_results
SELECT 'dwh_products', 'datatype_check',
       CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) = 0 THEN NULL
            ELSE 'Incorrect data type or length in columns: ' || 
                 STRING_AGG(
                    column_name || ' (actual: ' ||
                    data_type ||
                    COALESCE(
                        CASE 
                            WHEN character_maximum_length IS NOT NULL 
                                THEN '(' || character_maximum_length || ')' 
                            WHEN numeric_precision IS NOT NULL 
                                THEN '(' || numeric_precision || ',' || numeric_scale || ')' 
                        END, '') || ')', 
                    ', '
                 )
       END
FROM information_schema.columns
WHERE table_schema = 'dwh' AND table_name = 'dwh_products'
  AND (
        (column_name = 'product_src_id' AND (data_type <> 'character varying' OR character_maximum_length <> 10))
     OR (column_name = 'product_name' AND (data_type <> 'character varying' OR character_maximum_length <> 150))
     OR (column_name = 'product_id' AND data_type <> 'integer')
     OR (column_name = 'product_cost' AND (data_type <> 'numeric' OR numeric_precision <> 18 OR numeric_scale <> 2))
      );

-- --- DWH Clients
INSERT INTO pipeline_test_results
SELECT 'dwh_clients', 'datatype_check',
       CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) = 0 THEN NULL
            ELSE 'Incorrect data type or length in columns: ' || 
                 STRING_AGG(
                    column_name || ' (actual: ' ||
                    data_type ||
                    COALESCE(
                        CASE 
                            WHEN character_maximum_length IS NOT NULL 
                                THEN '(' || character_maximum_length || ')' 
                            WHEN numeric_precision IS NOT NULL 
                                THEN '(' || numeric_precision || ',' || numeric_scale || ')' 
                        END, '') || ')', 
                    ', '
                 )
       END
FROM information_schema.columns
WHERE table_schema = 'dwh' AND table_name = 'dwh_clients'
  AND (
        (column_name = 'client_src_id' AND (data_type <> 'character varying' OR character_maximum_length <> 10))
     OR (column_name = 'product_id' AND data_type <> 'integer')
     OR (column_name IN ('valid_from','valid_to') AND data_type <> 'date')
     OR (column_name = 'first_name' AND (data_type <> 'character varying' OR character_maximum_length <> 100))
     OR (column_name = 'middle_name' AND (data_type <> 'character varying' OR character_maximum_length <> 100))
     OR (column_name = 'last_name' AND (data_type <> 'character varying' OR character_maximum_length <> 100))
     OR (column_name = 'email' AND (data_type <> 'character varying' OR character_maximum_length <> 50))
     OR (column_name = 'phone_number' AND (data_type <> 'character varying' OR character_maximum_length <> 100))
     OR (column_name = 'is_valid' AND (data_type <> 'character varying' OR character_maximum_length <> 1))
     OR (column_name = 'first_purchase_date' AND data_type <> 'date')
      );

-- --- DWH Sales
INSERT INTO pipeline_test_results
SELECT 'dwh_sales', 'datatype_check',
       CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) = 0 THEN NULL
            ELSE 'Incorrect data type or length in columns: ' || 
                 STRING_AGG(
                    column_name || ' (actual: ' ||
                    data_type ||
                    COALESCE(
                        CASE 
                            WHEN character_maximum_length IS NOT NULL 
                                THEN '(' || character_maximum_length || ')' 
                            WHEN numeric_precision IS NOT NULL 
                                THEN '(' || numeric_precision || ',' || numeric_scale || ')' 
                        END, '') || ')', 
                    ', '
                 )
       END
FROM information_schema.columns
WHERE table_schema = 'dwh' AND table_name = 'dwh_sales'
  AND (
        (column_name = 'sale_id' AND data_type <> 'integer')
     OR (column_name IN ('client_id','channel_id','product_id') AND data_type <> 'integer')
     OR (column_name = 'order_created' AND data_type <> 'date')
     OR (column_name = 'order_completed' AND data_type <> 'date')
     OR (column_name = 'quantity' AND data_type <> 'integer')
      );

-- ==============================================
-- 5. View Test Results
-- ==============================================
SELECT *
FROM pipeline_test_results
WHERE result <> 'PASS'
ORDER BY table_name, test_type;



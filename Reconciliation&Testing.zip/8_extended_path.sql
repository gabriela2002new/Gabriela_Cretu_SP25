-- ==============================================
-- Ticket 20 – s1_clients: Null or empty middle_name
-- ==============================================
INSERT INTO lnd.reconciliation_results
SELECT
    's1_clients' AS table_name,
    'client_id' AS key_column,
    client_id AS src_id,
    NULL AS trg_id,
    'Null or empty middle_name' AS reconciliation_status
FROM lnd.lnd_s1_clients
WHERE middle_name IS NULL OR middle_name = '';

-- ==============================================
-- Ticket 21 – s2_clients: valid_from / valid_to consistency
-- ==============================================
INSERT INTO lnd.reconciliation_results
SELECT
    's2_clients' AS table_name,
    'client_id' AS key_column,
    s2.client_id AS src_id,
    dwh.client_src_id AS trg_id,
    'Mismatch in valid_from/valid_to' AS reconciliation_status
FROM lnd.lnd_s2_clients s2
LEFT JOIN dwh.dwh_clients dwh
    ON s2.client_id = dwh.client_src_id
WHERE s2.valid_from::date <> COALESCE(dwh.valid_from, '2000-01-01')
   OR s2.valid_to::date <> COALESCE(dwh.valid_to, '2000-01-01');

-- ==============================================
-- Ticket 22 – s1_sales: Units <= 0
-- ==============================================
INSERT INTO lnd.reconciliation_results
SELECT
    's1_sales' AS table_name,
    'client_id, channel_id, product_id, sale_date' AS key_column,
    CONCAT_WS('|', client_id, channel_id, product_id, sale_date) AS src_id,
    NULL AS trg_id,
    'Units <= 0' AS reconciliation_status
FROM lnd.lnd_s1_sales
WHERE units::numeric <= 0;

-- ==============================================
-- Ticket 23 – s2_client_sales: Null or future saled_at
-- ==============================================
INSERT INTO lnd.reconciliation_results
SELECT
    's2_client_sales' AS table_name,
    'client_id, channel_id, product_id, saled_at' AS key_column,
    CONCAT_WS('|', client_id, channel_id, product_id, saled_at) AS src_id,
    NULL AS trg_id,
    'Null or future saled_at' AS reconciliation_status
FROM lnd.lnd_s2_client_sales
WHERE saled_at IS NULL OR saled_at::date > CURRENT_DATE;

-- ==============================================
-- Ticket 24 – s1_products: Missing product_description / category
-- ==============================================
INSERT INTO lnd.reconciliation_results
SELECT
    's1_products' AS table_name,
    'product_id' AS key_column,
    product_id AS src_id,
    NULL AS trg_id,
    'Missing product_description or category' AS reconciliation_status
FROM lnd.lnd_s1_products
WHERE product_name IS null or cost is null;

-- ==============================================
-- Ticket 28 – Location mapping edge cases
-- ==============================================
INSERT INTO lnd.reconciliation_results
SELECT
    's1_channels' AS table_name,
    'channel_id' AS key_column,
    channel_id AS src_id,
    dwh.location_id::text AS trg_id,
    'Location mapping mismatch' AS reconciliation_status
FROM lnd.lnd_s1_channels s1
LEFT JOIN dwh.dwh_locations dwh
  ON TRIM(s1.channel_location) = TRIM(dwh.location_name)
WHERE dwh.location_id IS NULL;


SELECT
    table_name,
    key_column,
    reconciliation_status,
    COUNT(*) AS affected_rows,
    STRING_AGG(src_id, ', ' ORDER BY src_id) AS sample_src_ids,
    STRING_AGG(trg_id, ', ' ORDER BY trg_id) AS sample_trg_ids
FROM lnd.reconciliation_results
GROUP BY table_name, key_column, reconciliation_status
ORDER BY table_name, reconciliation_status;



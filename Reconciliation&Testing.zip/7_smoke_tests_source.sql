-- ==============================================
-- 0. Create Results Table (if not exists)
-- ==============================================
CREATE TABLE IF NOT EXISTS pipeline_test_results (
    table_name VARCHAR(256),
    test_type VARCHAR(256),
    result VARCHAR(10),
    count_value BIGINT,
    issue_description TEXT,
    test_run_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Optional: clear old results
TRUNCATE TABLE pipeline_test_results;

-- ==============================================
-- 1. DWH_SRC_HW_DB.S1 Layer Tests
-- ==============================================

-- --- S1 Channels
INSERT INTO pipeline_test_results
SELECT 'dwh_src_hw_db.s1_channels','row_count',
       CASE WHEN COUNT(*)>0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN 'Table is empty' ELSE NULL END
FROM s1.s1_channels;

INSERT INTO pipeline_test_results
SELECT 'dwh_src_hw_db.s1_channels','duplicate_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Duplicate channel_id found' ELSE NULL END
FROM (
    SELECT channel_id
    FROM s1.s1_channels
    GROUP BY channel_id HAVING COUNT(*)>1
) t;

INSERT INTO pipeline_test_results
SELECT 'dwh_src_hw_db.s1_channels','null_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Null channel_id found' ELSE NULL END
FROM s1.s1_channels
WHERE channel_id IS NULL;

-- --- S1 Clients
INSERT INTO pipeline_test_results
SELECT 'dwh_src_hw_db.s1_clients','row_count',
       CASE WHEN COUNT(*)>0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN 'Table is empty' ELSE NULL END
FROM s1.s1_clients;

INSERT INTO pipeline_test_results
SELECT 'dwh_src_hw_db.s1_clients','duplicate_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Duplicate client_id found' ELSE NULL END
FROM (
    SELECT client_id
    FROM s1.s1_clients
    GROUP BY client_id HAVING COUNT(*)>1
) t;

INSERT INTO pipeline_test_results
SELECT 'dwh_src_hw_db.s1_clients','null_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Null client_id found' ELSE NULL END
FROM s1.s1_clients
WHERE client_id IS NULL;

-- --- S1 Products
INSERT INTO pipeline_test_results
SELECT 'dwh_src_hw_db.s1_products','row_count',
       CASE WHEN COUNT(*)>0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN 'Table is empty' ELSE NULL END
FROM s1.s1_products;

INSERT INTO pipeline_test_results
SELECT 'dwh_src_hw_db.s1_products','duplicate_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Duplicate product_id found' ELSE NULL END
FROM (
    SELECT product_id
    FROM s1.s1_products
    GROUP BY product_id HAVING COUNT(*)>1
) t;

INSERT INTO pipeline_test_results
SELECT 'dwh_src_hw_db.s1_products','null_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Null product_id found' ELSE NULL END
FROM s1.s1_products
WHERE product_id IS NULL;

-- --- S1 Sales
INSERT INTO pipeline_test_results
SELECT 'dwh_src_hw_db.s1_sales','row_count',
       CASE WHEN COUNT(*)>0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN 'Table is empty' ELSE NULL END
FROM s1.s1_sales;

INSERT INTO pipeline_test_results
SELECT 'dwh_src_hw_db.s1_sales','duplicate_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Duplicate composite key found' ELSE NULL END
FROM (
    SELECT client_id, channel_id, product_id, sale_date
    FROM s1.s1_sales
    GROUP BY client_id, channel_id, product_id, sale_date
    HAVING COUNT(*)>1
) t;

INSERT INTO pipeline_test_results
SELECT 'dwh_src_hw_db.s1_sales','null_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Null key(s) found' ELSE NULL END
FROM s1.s1_sales
WHERE client_id IS NULL OR channel_id IS NULL OR product_id IS NULL OR sale_date IS NULL;

-- ==============================================
-- 2. DWH_SRC_HW_DB.S2 Layer Tests
-- ==============================================

-- --- S2 Channels
INSERT INTO pipeline_test_results
SELECT 'dwh_src_hw_db.s2_channels','row_count',
       CASE WHEN COUNT(*)>0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN 'Table is empty' ELSE NULL END
FROM s2.s2_channels;

INSERT INTO pipeline_test_results
SELECT 'dwh_src_hw_db.s2_channels','duplicate_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Duplicate channel_id found' ELSE NULL END
FROM (
    SELECT channel_id
    FROM s2.s2_channels
    GROUP BY channel_id HAVING COUNT(*)>1
) t;

INSERT INTO pipeline_test_results
SELECT 'dwh_src_hw_db.s2_channels','null_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Null channel_id found' ELSE NULL END
FROM s2.s2_channels
WHERE channel_id IS NULL;

-- --- S2 Clients
INSERT INTO pipeline_test_results
SELECT 'dwh_src_hw_db.s2_clients','row_count',
       CASE WHEN COUNT(*)>0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN 'Table is empty' ELSE NULL END
FROM s2.s2_clients;

INSERT INTO pipeline_test_results
SELECT 'dwh_src_hw_db.s2_clients','duplicate_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Duplicate client_id found' ELSE NULL END
FROM (
    SELECT client_id
    FROM s2.s2_clients
    GROUP BY client_id HAVING COUNT(*)>1
) t;

INSERT INTO pipeline_test_results
SELECT 'dwh_src_hw_db.s2_clients','null_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Null client_id found' ELSE NULL END
FROM s2.s2_clients
WHERE client_id IS NULL;

-- --- S2 Locations
INSERT INTO pipeline_test_results
SELECT 'dwh_src_hw_db.s2_locations','row_count',
       CASE WHEN COUNT(*)>0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN 'Table is empty' ELSE NULL END
FROM s2.s2_locations;

INSERT INTO pipeline_test_results
SELECT 'dwh_src_hw_db.s2_locations','duplicate_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Duplicate location_id found' ELSE NULL END
FROM (
    SELECT location_id
    FROM s2.s2_locations
    GROUP BY location_id HAVING COUNT(*)>1
) t;

INSERT INTO pipeline_test_results
SELECT 'dwh_src_hw_db.s2_locations','null_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Null location_id found' ELSE NULL END
FROM s2.s2_locations
WHERE location_id IS NULL;

-- --- S2 Client Sales
INSERT INTO pipeline_test_results
SELECT 'dwh_src_hw_db.s2_client_sales','row_count',
       CASE WHEN COUNT(*)>0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)=0 THEN 'Table is empty' ELSE NULL END
FROM s2.s2_client_sales;

INSERT INTO pipeline_test_results
SELECT 'dwh_src_hw_db.s2_client_sales','duplicate_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Duplicate composite key found' ELSE NULL END
FROM (
    SELECT client_id, channel_id, product_id, saled_at
    FROM s2.s2_client_sales
    GROUP BY client_id, channel_id, product_id, saled_at
    HAVING COUNT(*)>1
) t;

INSERT INTO pipeline_test_results
SELECT 'dwh_src_hw_db.s2_client_sales','null_keys',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*)>0 THEN 'Null key(s) found' ELSE NULL END
FROM s2.s2_client_sales
WHERE client_id IS NULL OR channel_id IS NULL OR product_id IS NULL OR saled_at IS NULL;




-- ==============================================
-- Smoke Test: Schema Validation (Source Layer)
-- ==============================================

-- --- S1 Channels
INSERT INTO pipeline_test_results
SELECT 's1_channels','schema_validation',
       CASE WHEN COUNT(*) = 3 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) <> 3 THEN 'Missing or extra columns in s1_channels' ELSE NULL END
FROM information_schema.columns
WHERE table_schema = 's1' AND table_name = 's1_channels'
  AND column_name IN ('channel_id','channel_name','channel_location');

-- --- S1 Sales
INSERT INTO pipeline_test_results
SELECT 's1_sales','schema_validation',
       CASE WHEN COUNT(*) = 6 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) <> 6 THEN 'Missing or extra columns in s1_sales' ELSE NULL END
FROM information_schema.columns
WHERE table_schema = 's1' AND table_name = 's1_sales'
  AND column_name IN ('client_id','channel_id','product_id','sale_date','units','purchase_date');

-- --- S1 Products
INSERT INTO pipeline_test_results
SELECT 's1_products','schema_validation',
       CASE WHEN COUNT(*) = 3 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) <> 3 THEN 'Missing or extra columns in s1_products' ELSE NULL END
FROM information_schema.columns
WHERE table_schema = 's1' AND table_name = 's1_products'
  AND column_name IN ('product_id','product_name','cost');

-- --- S1 Clients
INSERT INTO pipeline_test_results
SELECT 's1_clients','schema_validation',
       CASE WHEN COUNT(*) = 7 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) <> 7 THEN 'Missing or extra columns in s1_clients' ELSE NULL END
FROM information_schema.columns
WHERE table_schema = 's1' AND table_name = 's1_clients'
  AND column_name IN ('client_id','first_name','middle_name','last_name', 'email', 'phone', 'first_purchase');

-- --- S2 Channels
INSERT INTO pipeline_test_results
SELECT 's2_channels','schema_validation',
       CASE WHEN COUNT(*) = 3 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) <> 3 THEN 'Missing or extra columns in s2_channels' ELSE NULL END
FROM information_schema.columns
WHERE table_schema = 's2' AND table_name = 's2_channels'
  AND column_name IN ('channel_id','channel_name','location_id');

-- --- S2 Locations
INSERT INTO pipeline_test_results
SELECT 's2_locations','schema_validation',
       CASE WHEN COUNT(*) = 2 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) <> 2 THEN 'Missing or extra columns in s2_locations' ELSE NULL END
FROM information_schema.columns
WHERE table_schema = 's2' AND table_name = 's2_locations'
  AND column_name IN ('location_id','location_name');

-- --- S2 Client Sales
INSERT INTO pipeline_test_results
SELECT 's2_client_sales','schema_validation',
       CASE WHEN COUNT(*) = 8 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) <> 8 THEN 'Missing or extra columns in s2_client_sales' ELSE NULL END
FROM information_schema.columns
WHERE table_schema = 's2' AND table_name = 's2_client_sales'
  AND column_name IN ('client_id','channel_id','product_id','saled_at','product_name','product_price','product_amount','sold_date');

-- --- S2 Clients
INSERT INTO pipeline_test_results
SELECT 's2_clients','schema_validation',
       CASE WHEN COUNT(*) = 9 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       CASE WHEN COUNT(*) <> 9 THEN 'Missing or extra columns in s2_clients' ELSE NULL END
FROM information_schema.columns
WHERE table_schema = 's2' AND table_name = 's2_clients'
  AND column_name IN ('client_id','first_name','last_name', 'email', 'phone_code','phone_number', 'first_purchase','valid_from','valid_to');

 
 
 -- ==============================================
-- Smoke Test: Referential integrity
-- ==============================================
 -- --- S1 Sales FKs
INSERT INTO pipeline_test_results
SELECT 's1_sales','fk_channel_check',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       'Invalid channel_id in s1_sales not found in s1_channels'
FROM s1.s1_sales s
LEFT JOIN s1.s1_channels c ON s.channel_id = c.channel_id
WHERE c.channel_id IS NULL;

INSERT INTO pipeline_test_results
SELECT 's1_sales','fk_product_check',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       'Invalid product_id in s1_sales not found in s1_products'
FROM s1.s1_sales s
LEFT JOIN s1.s1_products p ON s.product_id = p.product_id
WHERE p.product_id IS NULL;

INSERT INTO pipeline_test_results
SELECT 's1_sales','fk_client_check',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       'Invalid client_id in s1_sales not found in s1_clients'
FROM s1.s1_sales s
LEFT JOIN s1.s1_clients c ON s.client_id = c.client_id
WHERE c.client_id IS NULL;

-- --- S2 Client Sales FKs
INSERT INTO pipeline_test_results
SELECT 's2_client_sales','fk_channel_check',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       'Invalid channel_id in s2_client_sales not found in s2_channels'
FROM s2.s2_client_sales s
LEFT JOIN s2.s2_channels c ON s.channel_id = c.channel_id
WHERE c.channel_id IS NULL;

INSERT INTO pipeline_test_results
SELECT 's2_client_sales','fk_product_check',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       'Invalid product_id in s2_client_sales not found in s1_products'
FROM s2.s2_client_sales s
LEFT JOIN s1.s1_products p ON s.product_id = p.product_id
WHERE p.product_id IS NULL;

INSERT INTO pipeline_test_results
SELECT 's2_client_sales','fk_client_check',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       'Invalid client_id in s2_client_sales not found in s2_clients'
FROM s2.s2_client_sales s
LEFT JOIN s2.s2_clients c ON s.client_id = c.client_id
WHERE c.client_id IS NULL;


 -- ==============================================
-- Smoke Test: Value Sanity Checks
-- ==============================================
-- --- Units / Quantities should be positive
INSERT INTO pipeline_test_results
SELECT 's1_sales','negative_units',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       'Negative or zero units found'
FROM s1.s1_sales
WHERE units::numeric <= 0;

-- --- Product costs should be positive
INSERT INTO pipeline_test_results
SELECT 's1_products','negative_cost',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       'Negative or zero product cost found'
FROM s1.s1_products
WHERE cost::numeric <= 0;

 -- ==============================================
-- Smoke Test: Date Validation Checks
-- ==============================================
-- --- Sales dates should not be in the future
INSERT INTO pipeline_test_results
SELECT 's1_sales','future_sale_date',
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END,
       COUNT(*),
       'Future sale_date found'
FROM s1.s1_sales
WHERE sale_date::date > CURRENT_DATE;


-- ==============================================
-- 3. View Test Results
-- ==============================================
SELECT *
FROM pipeline_test_results
where result<> 'PASS'
ORDER BY table_name, test_type;

--before starting please download the zip file csv (or make a  document called csv on your \:C disk and give permission to everyone to read)
--also create a connection to pgadmin and create the database lottery

CREATE EXTENSION IF NOT EXISTS file_fdw;

CREATE SCHEMA IF NOT EXISTS sa_final_draw;
CREATE SCHEMA IF NOT EXISTS sa_final_scratch;


CREATE SCHEMA IF NOT EXISTS bl_3nf;
CREATE SCHEMA IF NOT EXISTS bl_cl;
CREATE SCHEMA IF NOT EXISTS bl_dm;




DROP FOREIGN TABLE IF EXISTS sa_final_draw.ext_final_draw;
DROP TABLE IF EXISTS sa_final_draw.src_final_draw;
DROP SERVER IF EXISTS file_server CASCADE;

-- Create server
CREATE server if not exists file_server FOREIGN DATA WRAPPER file_fdw;

-- Create external foreign table for Final_Draw aligned to FCT_SALES and dimensions
create FOREIGN table if not exists sa_final_draw.ext_final_draw (
    -- Sales Information
    transaction_dt VARCHAR(255),                 -- mapped from date_id
    retailer_license_number VARCHAR(255),
    customer_id VARCHAR(255),
    employee_id VARCHAR(255),
    game_number VARCHAR(255),                      -- mapped from GAME_NUMBER
    payment_method_id VARCHAR(255),                -- mapped from PAYMENT_METHOD_ID
    sales VARCHAR(255),
    tickets_bought VARCHAR(255),
    payout VARCHAR(255),

    -- Customer Information
    customer_email VARCHAR(255),
    customer_phone VARCHAR(255),
    customer_registration_dt VARCHAR(255),
    customer_state VARCHAR(255),
    customer_city VARCHAR(255),
    customer_zip_code VARCHAR(255),                -- mapped from customer_zip

    -- Employee Information
    employee_email VARCHAR(255),
    employee_phone VARCHAR(255),
    employee_hire_dt VARCHAR(255),
    employee_salary VARCHAR(255),

    -- Retailer Information
    retailer_location_name VARCHAR(255),
    retailer_location_zip_code VARCHAR(255),
    retailer_location_state VARCHAR(255),

    -- Game Information
    game_category VARCHAR(255),
    game_type VARCHAR(255),
    ticket_price VARCHAR(255),
    winning_chance VARCHAR(255),
    winning_jackpot VARCHAR(255),
    draw_dt VARCHAR(255),

    -- Payment Information
    payment_method_name VARCHAR(255)   -- mapped from PAYMENT_METHOD_NAME
   
)
SERVER file_server
OPTIONS (
    filename 'C:\csv\Final_Draw_with_dates.csv',
    format 'csv',
    header 'true'
);



CREATE TABLE IF NOT EXISTS sa_final_draw.src_final_draw (
    -- Sales Information
    transaction_dt VARCHAR(255),
    retailer_license_number VARCHAR(255),
    customer_id VARCHAR(255),
    employee_id VARCHAR(255),
    game_number VARCHAR(255),
    payment_method_id VARCHAR(255),
    sales VARCHAR(255),
    tickets_bought VARCHAR(255),
    payout VARCHAR(255),

    -- Customer Information
    customer_email VARCHAR(255),
    customer_phone VARCHAR(255),
    customer_registration_dt VARCHAR(255),
    customer_state VARCHAR(255),
    customer_city VARCHAR(255),
    customer_zip_code VARCHAR(255),

    -- Employee Information
    employee_email VARCHAR(255),
    employee_phone VARCHAR(255),
    employee_hire_dt VARCHAR(255),
    employee_salary VARCHAR(255),

    -- Retailer Information
    retailer_location_name VARCHAR(255),
    retailer_location_zip_code VARCHAR(255),
    retailer_location_state VARCHAR(255),

    -- Game Information
    game_category VARCHAR(255),
    game_type VARCHAR(255),
    ticket_price VARCHAR(255),
    winning_chance VARCHAR(255),
    winning_jackpot VARCHAR(255),
    draw_dt VARCHAR(255),

    -- Payment Information
    payment_method_name VARCHAR(255)
);

ALTER TABLE sa_final_draw.src_final_draw
ADD CONSTRAINT src_final_draw_unique UNIQUE (
    transaction_dt,
    retailer_license_number,
    customer_id,
    employee_id,
    game_number,
    payment_method_id
);


CREATE OR REPLACE PROCEDURE sa_final_draw.load_up_to_percentage_full_dates(pct FLOAT)
LANGUAGE plpgsql
AS $$
DECLARE
    total_rows INT;
    cutoff_count INT;
    cutoff_date DATE;
BEGIN
    IF pct <= 0 OR pct >= 100 THEN
        RAISE EXCEPTION 'Percentage must be between 0 and 100 (exclusive)';
    END IF;

    -- Total rows in the source
    SELECT COUNT(*) INTO total_rows FROM sa_final_draw.ext_final_draw;

    -- Calculate how many rows correspond to pct%
    cutoff_count := FLOOR(total_rows * (pct / 100.0));

    WITH ordered_dates AS (
        SELECT
            transaction_dt::date AS dt,
            COUNT(*) AS cnt
        FROM sa_final_draw.ext_final_draw
        GROUP BY dt
        ORDER BY dt
    ),
    cumulative AS (
        SELECT
            dt,
            cnt,
            SUM(cnt) OVER (ORDER BY dt ROWS UNBOUNDED PRECEDING) AS running_total
        FROM ordered_dates
    )
    SELECT dt INTO cutoff_date
    FROM cumulative
    WHERE running_total <= cutoff_count
    ORDER BY dt desc
    LIMIT 1;

    IF cutoff_date IS NULL THEN
        RAISE EXCEPTION 'Could not determine cutoff date.';
    END IF;

    -- Clear existing data before loading
    DELETE FROM sa_final_draw.src_final_draw;

    -- Insert all rows up to and including cutoff_date
    INSERT INTO sa_final_draw.src_final_draw (
        transaction_dt,
        retailer_license_number,
        customer_id,
        employee_id,
        game_number,
        payment_method_id,
        sales,
        tickets_bought,
        payout,
        customer_email,
        customer_phone,
        customer_registration_dt,
        customer_state,
        customer_city,
        customer_zip_code,
        employee_email,
        employee_phone,
        employee_hire_dt,
        employee_salary,
        retailer_location_name,
        retailer_location_zip_code,
        retailer_location_state,
        game_category,
        game_type,
        ticket_price,
        winning_chance,
        winning_jackpot,
        draw_dt,
        payment_method_name
    )
    SELECT
        transaction_dt,
        retailer_license_number,
        customer_id,
        employee_id,
        game_number,
        payment_method_id,
        sales,
        tickets_bought,
        payout,
        customer_email,
        customer_phone,
        customer_registration_dt,
        customer_state,
        customer_city,
        customer_zip_code,
        employee_email,
        employee_phone,
        employee_hire_dt,
        employee_salary,
        retailer_location_name,
        retailer_location_zip_code,
        retailer_location_state,
        game_category,
        game_type,
        ticket_price,
        winning_chance,
        winning_jackpot,
        draw_dt,
        payment_method_name
    FROM sa_final_draw.ext_final_draw
    WHERE transaction_dt::date <= cutoff_date
    ON CONFLICT (transaction_dt, retailer_license_number, customer_id, employee_id, game_number, payment_method_id) DO NOTHING;

END;
$$;

SELECT * FROM sa_final_draw.ext_final_draw efd 
WHERE transaction_dt::date BETWEEN '2022-01-01' AND '2022-01-31'
LIMIT 10;

select count(*) FROM sa_final_draw.ext_final_draw efd ;

call sa_final_draw.load_up_to_percentage_full_dates(10);
select count(*) from sa_final_draw.src_final_draw;
select max(transaction_dt::date) from sa_final_draw.src_final_draw;

CREATE OR REPLACE PROCEDURE sa_final_draw.load_remaining_skip_duplicates()
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO sa_final_draw.src_final_draw (
        transaction_dt,
        retailer_license_number,
        customer_id,
        employee_id,
        game_number,
        payment_method_id,
        sales,
        tickets_bought,
        payout,
        customer_email,
        customer_phone,
        customer_registration_dt,
        customer_state,
        customer_city,
        customer_zip_code,
        employee_email,
        employee_phone,
        employee_hire_dt,
        employee_salary,
        retailer_location_name,
        retailer_location_zip_code,
        retailer_location_state,
        game_category,
        game_type,
        ticket_price,
        winning_chance,
        winning_jackpot,
        draw_dt,
        payment_method_name
    )
    SELECT
        transaction_dt,
        retailer_license_number,
        customer_id,
        employee_id,
        game_number,
        payment_method_id,
        sales,
        tickets_bought,
        payout,
        customer_email,
        customer_phone,
        customer_registration_dt,
        customer_state,
        customer_city,
        customer_zip_code,
        employee_email,
        employee_phone,
        employee_hire_dt,
        employee_salary,
        retailer_location_name,
        retailer_location_zip_code,
        retailer_location_state,
        game_category,
        game_type,
        ticket_price,
        winning_chance,
        winning_jackpot,
        draw_dt,
        payment_method_name
    FROM sa_final_draw.ext_final_draw
    ON CONFLICT (transaction_dt, retailer_license_number, customer_id, employee_id, game_number, payment_method_id) DO NOTHING;
END;
$$;


call sa_final_draw.load_remaining_skip_duplicates();
select count(*) from sa_final_draw.src_final_draw;



select count(*) from sa_final_draw.src_final_draw sfd ; 

DROP FOREIGN TABLE IF EXISTS sa_final_draw.ext_draw;

CREATE FOREIGN TABLE IF NOT EXISTS sa_final_draw.ext_draw (
    -- Exact same structure as the other one
    transaction_dt VARCHAR(255),
    retailer_license_number VARCHAR(255),
    customer_id VARCHAR(255),
    employee_id VARCHAR(255),
    game_number VARCHAR(255),
    payment_method_id VARCHAR(255),
    sales VARCHAR(255),
    tickets_bought VARCHAR(255),
    payout VARCHAR(255),

    customer_email VARCHAR(255),
    customer_phone VARCHAR(255),
    customer_registration_dt VARCHAR(255),
    customer_state VARCHAR(255),
    customer_city VARCHAR(255),
    customer_zip_code VARCHAR(255),

    employee_email VARCHAR(255),
    employee_phone VARCHAR(255),
    employee_hire_dt VARCHAR(255),
    employee_salary VARCHAR(255),

    retailer_location_name VARCHAR(255),
    retailer_location_zip_code VARCHAR(255),
    retailer_location_state VARCHAR(255),

    game_category VARCHAR(255),
    game_type VARCHAR(255),
    ticket_price VARCHAR(255),
    winning_chance VARCHAR(255),
    winning_jackpot VARCHAR(255),
    draw_dt VARCHAR(255),

    payment_method_name VARCHAR(255)
)
SERVER file_server
OPTIONS (
    filename 'C:\\csv\\draw.csv',
    format 'csv',
    header 'true'
);

SELECT COUNT(*) FROM sa_final_draw.src_final_draw;

CREATE OR REPLACE PROCEDURE sa_final_draw.insert_all_ext_draw_data()
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO sa_final_draw.src_final_draw (
        transaction_dt,
        retailer_license_number,
        customer_id,
        employee_id,
        game_number,
        payment_method_id,
        sales,
        tickets_bought,
        payout,
        customer_email,
        customer_phone,
        customer_registration_dt,
        customer_state,
        customer_city,
        customer_zip_code,
        employee_email,
        employee_phone,
        employee_hire_dt,
        employee_salary,
        retailer_location_name,
        retailer_location_zip_code,
        retailer_location_state,
        game_category,
        game_type,
        ticket_price,
        winning_chance,
        winning_jackpot,
        draw_dt,
        payment_method_name
    )
    SELECT
        transaction_dt,
        retailer_license_number,
        customer_id,
        employee_id,
        game_number,
        payment_method_id,
        sales,
        tickets_bought,
        payout,
        customer_email,
        customer_phone,
        customer_registration_dt,
        customer_state,
        customer_city,
        customer_zip_code,
        employee_email,
        employee_phone,
        employee_hire_dt,
        employee_salary,
        retailer_location_name,
        retailer_location_zip_code,
        retailer_location_state,
        game_category,
        game_type,
        ticket_price,
        winning_chance,
        winning_jackpot,
        draw_dt,
        payment_method_name
    FROM sa_final_draw.ext_draw
    WHERE
        transaction_dt IS NOT NULL AND
        retailer_license_number IS NOT NULL AND
        customer_id IS NOT NULL AND
        employee_id IS NOT NULL AND
        game_number IS NOT NULL AND
        payment_method_id IS NOT NULL AND
        sales IS NOT NULL AND
        tickets_bought IS NOT NULL AND
        payout IS NOT NULL AND
        customer_email IS NOT NULL AND
        customer_phone IS NOT NULL AND
        customer_registration_dt IS NOT NULL AND
        customer_state IS NOT NULL AND
        customer_city IS NOT NULL AND
        customer_zip_code IS NOT NULL AND
        employee_email IS NOT NULL AND
        employee_phone IS NOT NULL AND
        employee_hire_dt IS NOT NULL AND
        employee_salary IS NOT NULL AND
        retailer_location_name IS NOT NULL AND
        retailer_location_zip_code IS NOT NULL AND
        retailer_location_state IS NOT NULL AND
        game_category IS NOT NULL AND
        game_type IS NOT NULL AND
        ticket_price IS NOT NULL AND
        winning_chance IS NOT NULL AND
        winning_jackpot IS NOT NULL AND
        draw_dt IS NOT NULL AND
        payment_method_name IS NOT NULL
    ON CONFLICT (
        transaction_dt,
        retailer_license_number,
        customer_id,
        employee_id,
        game_number,
        payment_method_id
    ) DO NOTHING;
END;
$$;





call sa_final_draw.insert_all_ext_draw_data();
select count(*) from  sa_final_draw.src_final_draw;



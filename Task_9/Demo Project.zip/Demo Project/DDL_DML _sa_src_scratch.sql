DROP FOREIGN TABLE IF EXISTS sa_final_scratch.ext_final_scratch;
DROP TABLE IF EXISTS sa_final_scratch.src_final_scratch;
DROP SERVER IF EXISTS file_server CASCADE;
drop foreign table if exists sa_final_scratch.ext_scratch;

-- Create server
CREATE server if not exists file_server FOREIGN DATA WRAPPER file_fdw;

-- Create external foreign table for Final_Draw aligned to FCT_SALES and dimensions

CREATE FOREIGN table if not exists sa_final_scratch.ext_final_scratch (
    -- Sales Information
    transaction_dt VARCHAR(255),
    retailer_license_number VARCHAR(255),
    customer_id VARCHAR(255),
    employee_id VARCHAR(255),
    game_number VARCHAR(255),
    tickets_bought VARCHAR(255),
    payment_method_id VARCHAR(255),
    sales VARCHAR(255),
    payout VARCHAR(255),

    -- Customer Information
    customer_name VARCHAR(255),
    customer_gender VARCHAR(255),
    customer_dob VARCHAR(255),

    -- Employee Information
    employee_name VARCHAR(255),
    employee_department VARCHAR(255),
    employee_status VARCHAR(255),

    -- Retailer Information
    retailer_location_name VARCHAR(255),
    retailer_location_zip_code VARCHAR(255),
    retailer_location_city VARCHAR(255),

    -- Game Information
    ticket_price VARCHAR(255),
    game_category VARCHAR(255),
    game_type VARCHAR(255),
    average_odds VARCHAR(255),
    average_odds_prob VARCHAR(255),
    top_prize VARCHAR(255),
    mid_prize VARCHAR(255),
    small_prize VARCHAR(255),

    -- Payment Information
    payment_method_name VARCHAR(255)
)
SERVER file_server
OPTIONS (
    filename 'C:\csv\Final_Scratch_with_dates.csv',
    format 'csv',
    header 'true'
);



CREATE TABLE IF NOT EXISTS sa_final_scratch.src_final_scratch (
    -- Sales Information
    transaction_dt VARCHAR(255),
    retailer_license_number VARCHAR(255),
    customer_id VARCHAR(255),
    employee_id VARCHAR(255),
    game_number VARCHAR(255),
    tickets_bought VARCHAR(255),
    payment_method_id VARCHAR(255),
    sales VARCHAR(255),
    payout VARCHAR(255),

    -- Customer Information
    customer_name VARCHAR(255),
    customer_gender VARCHAR(255),
    customer_dob VARCHAR(255),

    -- Employee Information
    employee_name VARCHAR(255),
    employee_department VARCHAR(255),
    employee_status VARCHAR(255),

    -- Retailer Information
    retailer_location_name VARCHAR(255),
    retailer_location_zip_code VARCHAR(255),
    retailer_location_city VARCHAR(255),

    -- Game Information
    ticket_price VARCHAR(255),
    game_category VARCHAR(255),
    game_type VARCHAR(255),
    average_odds VARCHAR(255),
    average_odds_prob VARCHAR(255),
    top_prize VARCHAR(255),
    mid_prize VARCHAR(255),
    small_prize VARCHAR(255),

    -- Payment Information
    payment_method_name VARCHAR(255)
);

ALTER TABLE sa_final_scratch.src_final_scratch
ADD CONSTRAINT src_final_scratch_unique UNIQUE (
    transaction_dt,
    retailer_license_number,
    customer_id,
    employee_id,
    game_number,
    payment_method_id
);


select count(*) from sa_final_scratch.src_final_scratch;

CREATE OR REPLACE PROCEDURE sa_final_scratch.load_up_to_percentage_full_dates(pct FLOAT)
LANGUAGE plpgsql
AS $$
DECLARE
    total_rows INT;
    cutoff_count INT;
    cutoff_date DATE;
BEGIN
    IF pct <= 0 OR pct >= 100 THEN
        RAISE EXCEPTION 'Percentage must be between 0 and 100 (exclusive)';
    END IF;

    -- Total rows in the source
    SELECT COUNT(*) INTO total_rows FROM sa_final_scratch.ext_final_scratch;

    -- Calculate how many rows correspond to pct%
    cutoff_count := FLOOR(total_rows * (pct / 100.0));

    -- Find the maximum transaction date that includes at least cutoff_count rows
    -- Here we:
    -- - order all rows by transaction_dt
    -- - count cumulative rows per date (partition by date)
    -- - pick the largest date where cumulative count <= cutoff_count

    WITH ordered_dates AS (
        SELECT
            transaction_dt::date AS dt,
            COUNT(*) AS cnt
        FROM sa_final_scratch.ext_final_scratch
        GROUP BY transaction_dt::date
        ORDER BY dt
    ),
    cumulative AS (
        SELECT
            dt,
            SUM(cnt) OVER (ORDER BY dt ROWS UNBOUNDED PRECEDING) AS running_total
        FROM ordered_dates
    )
    SELECT dt INTO cutoff_date
    FROM cumulative
    WHERE running_total <= cutoff_count
    ORDER BY dt DESC
    LIMIT 1;

    IF cutoff_date IS NULL THEN
        RAISE EXCEPTION 'Could not determine cutoff date.';
    END IF;

    -- Clear existing data before loading
    DELETE FROM sa_final_scratch.src_final_scratch;

    -- Insert all rows up to and including cutoff_date
    INSERT INTO sa_final_scratch.src_final_scratch (
        transaction_dt,
        retailer_license_number,
        customer_id,
        employee_id,
        game_number,
        tickets_bought,
        payment_method_id,
        sales,
        payout,
        customer_name,
        customer_gender,
        customer_dob,
        employee_name,
        employee_department,
        employee_status,
        retailer_location_name,
        retailer_location_zip_code,
        retailer_location_city,
        ticket_price,
        game_category,
        game_type,
        average_odds,
        average_odds_prob,
        top_prize,
        mid_prize,
        small_prize,
        payment_method_name
    )
    SELECT
        transaction_dt,
        retailer_license_number,
        customer_id,
        employee_id,
        game_number,
        tickets_bought,
        payment_method_id,
        sales,
        payout,
        customer_name,
        customer_gender,
        customer_dob,
        employee_name,
        employee_department,
        employee_status,
        retailer_location_name,
        retailer_location_zip_code,
        retailer_location_city,
        ticket_price,
        game_category,
        game_type,
        average_odds,
        average_odds_prob,
        top_prize,
        mid_prize,
        small_prize,
        payment_method_name
    FROM sa_final_scratch.ext_final_scratch
    WHERE transaction_dt::date <= cutoff_date
    ON CONFLICT (transaction_dt, retailer_license_number, customer_id, employee_id, game_number, payment_method_id) DO NOTHING;

END;
$$;


call  sa_final_scratch.load_up_to_percentage_full_dates(7.4);
select count(*) from sa_final_scratch.src_final_scratch;
select max(transaction_dt::date) from sa_final_scratch.src_final_scratch;


select count(*) from sa_final_draw.src_final_draw;

select 49564+36643;


select count(*) from sa_final_scratch.ext_final_scratch efd ;
CREATE OR REPLACE PROCEDURE sa_final_scratch.load_remaining_skip_duplicates()
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO sa_final_scratch.src_final_scratch (
        transaction_dt,
        retailer_license_number,
        customer_id,
        employee_id,
        game_number,
        tickets_bought,
        payment_method_id,
        sales,
        payout,
        customer_name,
        customer_gender,
        customer_dob,
        employee_name,
        employee_department,
        employee_status,
        retailer_location_name,
        retailer_location_zip_code,
        retailer_location_city,
        ticket_price,
        game_category,
        game_type,
        average_odds,
        average_odds_prob,
        top_prize,
        mid_prize,
        small_prize,
        payment_method_name
    )
    SELECT
        transaction_dt,
        retailer_license_number,
        customer_id,
        employee_id,
        game_number,
        tickets_bought,
        payment_method_id,
        sales,
        payout,
        customer_name,
        customer_gender,
        customer_dob,
        employee_name,
        employee_department,
        employee_status,
        retailer_location_name,
        retailer_location_zip_code,
        retailer_location_city,
        ticket_price,
        game_category,
        game_type,
        average_odds,
        average_odds_prob,
        top_prize,
        mid_prize,
        small_prize,
        payment_method_name
    FROM sa_final_scratch.ext_final_scratch
    ON CONFLICT (
        transaction_dt,
        retailer_license_number,
        customer_id,
        employee_id,
        game_number,
        payment_method_id
    ) DO NOTHING;
END;
$$;



call sa_final_scratch.load_remaining_skip_duplicates();
select count(*) from sa_final_scratch.src_final_scratch;

drop foreign table if exists sa_final_scratch.ext_scratch;

CREATE FOREIGN TABLE IF NOT EXISTS sa_final_scratch.ext_scratch (
    -- Exact same structure as the other one
    transaction_dt VARCHAR(255),
    retailer_license_number VARCHAR(255),
    customer_id VARCHAR(255),
    employee_id VARCHAR(255),
    game_number VARCHAR(255),
    tickets_bought VARCHAR(255),
    payment_method_id VARCHAR(255),
    sales VARCHAR(255),
    payout VARCHAR(255),

    -- Customer Information
    customer_name VARCHAR(255),
    customer_gender VARCHAR(255),
    customer_dob VARCHAR(255),

    -- Employee Information
    employee_name VARCHAR(255),
    employee_department VARCHAR(255),
    employee_status VARCHAR(255),

    -- Retailer Information
    retailer_location_name VARCHAR(255),
    retailer_location_zip_code VARCHAR(255),
    retailer_location_city VARCHAR(255),

    -- Game Information
    ticket_price VARCHAR(255),
    game_category VARCHAR(255),
    game_type VARCHAR(255),
    average_odds VARCHAR(255),
    average_odds_prob VARCHAR(255),
    top_prize VARCHAR(255),
    mid_prize VARCHAR(255),
    small_prize VARCHAR(255),

    -- Payment Information
    payment_method_name VARCHAR(255))
SERVER file_server
OPTIONS (
    filename 'C:\\csv\\scratch.csv',
    format 'csv',
    header 'true'
);

SELECT COUNT(*) FROM sa_final_scratch.src_final_scratch;

CREATE OR REPLACE PROCEDURE sa_final_scratch.insert_all_ext_scartch_data()
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO sa_final_scratch.src_final_scratch (
        transaction_dt,
        retailer_license_number,
        customer_id,
        employee_id,
        game_number,
        tickets_bought,
        payment_method_id,
        sales,
        payout,
        customer_name,
        customer_gender,
        customer_dob,
        employee_name,
        employee_department,
        employee_status,
        retailer_location_name,
        retailer_location_zip_code,
        retailer_location_city,
        ticket_price,
        game_category,
        game_type,
        average_odds,
        average_odds_prob,
        top_prize,
        mid_prize,
        small_prize,
        payment_method_name
    )
    SELECT
        transaction_dt,
        retailer_license_number,
        customer_id,
        employee_id,
        game_number,
        tickets_bought,
        payment_method_id,
        sales,
        payout,
        customer_name,
        customer_gender,
        customer_dob,
        employee_name,
        employee_department,
        employee_status,
        retailer_location_name,
        retailer_location_zip_code,
        retailer_location_city,
        ticket_price,
        game_category,
        game_type,
        average_odds,
        average_odds_prob,
        top_prize,
        mid_prize,
        small_prize,
        payment_method_name
    FROM sa_final_scratch.ext_scratch
    WHERE
        transaction_dt IS NOT NULL AND
        retailer_license_number IS NOT NULL AND
        customer_id IS NOT NULL AND
        employee_id IS NOT NULL AND
        game_number IS NOT NULL AND
        tickets_bought IS NOT NULL AND
        payment_method_id IS NOT NULL AND
        sales IS NOT NULL AND
        payout IS NOT NULL AND
        customer_name IS NOT NULL AND
        customer_gender IS NOT NULL AND
        customer_dob IS NOT NULL AND
        employee_name IS NOT NULL AND
        employee_department IS NOT NULL AND
        employee_status IS NOT NULL AND
        retailer_location_name IS NOT NULL AND
        retailer_location_zip_code IS NOT NULL AND
        retailer_location_city IS NOT NULL AND
        ticket_price IS NOT NULL AND
        game_category IS NOT NULL AND
        game_type IS NOT NULL AND
        average_odds IS NOT NULL AND
        average_odds_prob IS NOT NULL AND
        top_prize IS NOT NULL AND
        mid_prize IS NOT NULL AND
        small_prize IS NOT NULL AND
        payment_method_name IS NOT NULL
    ON CONFLICT (
        transaction_dt,
        retailer_license_number,
        customer_id,
        employee_id,
        game_number,
        payment_method_id
    ) DO NOTHING;
END;
$$;

call  sa_final_scratch.insert_all_ext_scartch_data();
select count(*) from  sa_final_scratch.src_final_scratch sfs ;


















































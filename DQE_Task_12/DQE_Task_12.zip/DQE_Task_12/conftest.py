import os
import pytest
import requests
import boto3
import yaml
from botocore import UNSIGNED
from botocore.config import Config
from google.cloud import storage
from selenium import webdriver
from selenium.webdriver.chrome.service import Service

# ---------------- CONFIG FIXTURE ----------------
@pytest.fixture(scope="session")
def config_from_yaml():
    yaml_path = os.path.join(os.path.dirname(__file__), "config.yaml")
    with open(yaml_path, "r") as f:
        cfg = yaml.safe_load(f)
    cfg['s3_anon_client'] = boto3.client('s3', config=Config(signature_version=UNSIGNED))
    cfg['gcp_storage_anon_client'] = storage.Client.create_anonymous_client()
    return cfg

# ---------------- GCP / AWS LIST FIXTURES ----------------
@pytest.fixture
def list_gcs_blobs_for_date(config_from_yaml):
    def _inner(date_prefix):
        blobs = config_from_yaml['gcp_storage_anon_client'].list_blobs(
            config_from_yaml['buckets']['gcp_bucket'], prefix=date_prefix
        )
        return [b.name for b in blobs]
    return _inner

@pytest.fixture
def list_aws_blobs_for_date(config_from_yaml):
    def _inner(date_prefix):
        response = config_from_yaml['s3_anon_client'].list_objects(
            Bucket=config_from_yaml['buckets']['aws_bucket'], Prefix=date_prefix
        )
        return [c['Key'] for c in response.get('Contents', [])]
    return _inner

# ---------------- JSONPLACEHOLDER API FIXTURE ----------------
@pytest.fixture(scope="function")
def provide_posts_data():
    url = "https://jsonplaceholder.typicode.com/posts"
    response = requests.get(url, params={"userId": 3})
    response.raise_for_status()
    return response.json()

# ---------------- SELENIUM DRIVER FIXTURE ----------------
@pytest.fixture(scope="session")
def chrome_driver():
    options = webdriver.ChromeOptions()
    options.headless = True  # Optional: run headless
    driver = webdriver.Chrome(service=Service(), options=options)
    driver.maximize_window()
    yield driver
    driver.quit()

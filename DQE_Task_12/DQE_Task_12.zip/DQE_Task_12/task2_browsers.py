from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.firefox.service import Service as FirefoxService

# -------------------- Chrome (Automatic) --------------------
# Selenium Manager handles ChromeDriver automatically
chrome_driver = webdriver.Chrome(service=ChromeService())
chrome_driver.get("https://www.google.com")
print("Chrome Page Title:", chrome_driver.title)
chrome_driver.quit()

# -------------------- Firefox (Manual Path) --------------------
# Provide the path to geckodriver manually (or via PATH variable)
# Example: geckodriver.exe is in "C:/drivers/geckodriver.exe"

#To specify that i do not have the firefox webserver on my laptop

from selenium import webdriver
from selenium.webdriver.firefox.service import Service as FirefoxService

firefox_path = r"C:\Program Files\Mozilla Firefox\firefox.exe"  # path to firefox.exe
gecko_driver_path = r"C:\Program Files\geckodriver-v0.36.0-win32\geckodriver.exe"                # path to geckodriver.exe

firefox_service = FirefoxService(executable_path=gecko_driver_path)
firefox_options = webdriver.FirefoxOptions()
firefox_options.binary_location = firefox_path  # tell Selenium where Firefox binary is

firefox_driver = webdriver.Firefox(service=firefox_service, options=firefox_options)
firefox_driver.get("https://www.google.com")
print("Firefox Page Title:", firefox_driver.title)
firefox_driver.quit()


from selenium.webdriver.support import expected_conditions as EC
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.support.relative_locator import locate_with
import time

from selenium.webdriver.support.wait import WebDriverWait

# -------------------- Setup Chrome Driver (Automatic) --------------------
driver = webdriver.Chrome(service=ChromeService())
driver.maximize_window()

# -------------------- 1. PHPtravels Demo Page --------------------

demo_url = "https://phptravels.com/demo/"
driver.get(demo_url)
time.sleep(3)  # wait for page load

print(f"\n--- Locators for page: {demo_url} ---")

# Wait for the Request Instant Demo block to be visible
form_block = WebDriverWait(driver, 15).until(
    EC.visibility_of_element_located(
        (By.XPATH, "//h2[contains(text(),'Request Instant Demo')]")
    )
)
print("Demo form is visible.")

# --- Class Name Locators  ---
first_name = driver.find_element(By.CLASS_NAME, "first_name")
print("First Name located by class 'first_name'")
last_name = driver.find_element(By.CLASS_NAME, "last_name")
print("Last Name located by class 'last_name'")
country = driver.find_element(By.CLASS_NAME, "country_id")
print("Country located by class 'country_id'")

# --- ID Locators---
submit_button = driver.find_element(By.ID, "demo")
print("Submit button located by CSS selector")


# --- CSS Selector Locators---
email = driver.find_element(By.CSS_SELECTOR, "input[placeholder='Enter email address']")
print("Email located by CSS selector using placeholder")
business_name = driver.find_element(By.CSS_SELECTOR, ".company_name")
print("Business Name located by CSS selector '.company_name'")

# --- Relative Locators---
submit_button = driver.find_element(By.ID, "demo")
first_name_relative = driver.find_element(locate_with(By.TAG_NAME, "input").above(submit_button))
print("First Name located using relative locator above submit button")
last_name_relative = driver.find_element(locate_with(By.TAG_NAME, "input").below(form_block))
print("Last Name located using relative locator below form header")






# -------------------- 2. PHPtravels Register Page --------------------
register_url = "https://phptravels.org/register.php"
driver.get(register_url)
time.sleep(3)

print(f"\n--- Locators for page: {register_url} ---")

# Wait until the Personal Information card container is visible
personal_info_card = WebDriverWait(driver, 10).until(
    EC.visibility_of_element_located((By.XPATH, "//h3[text()='Personal Information']/.."))
)

# --- ID Locators---
first_name = personal_info_card.find_element(By.ID, "inputFirstName")
print("First name located")
last_name = personal_info_card.find_element(By.ID, "inputLastName")
print("Last name located")
email = personal_info_card.find_element(By.ID, "inputEmail")
print("Email located")
phone = personal_info_card.find_element(By.ID, "inputPhone")
print("Phone located")
print("Personal info fields located by ID")


# Wait until Billing Address card is visible
billing_card = WebDriverWait(driver, 10).until(
    EC.visibility_of_element_located((By.XPATH, "//h3[text()='Billing Address']/.."))
)

# --- ID Locators---
company_name = billing_card.find_element(By.ID, "inputCompanyName")
print("Company Name located")
address1 = billing_card.find_element(By.ID, "inputAddress1")
print("Address1 located")
address2 = billing_card.find_element(By.ID, "inputAddress2")
print("Address2 located")
city = billing_card.find_element(By.ID, "inputCity")
print("City located")
postcode = billing_card.find_element(By.ID, "inputPostcode")
print("Postcode located")
country = billing_card.find_element(By.ID, "inputCountry")
print("Country located")

#---- XPath Locators-------------
state = billing_card.find_element(By.XPATH, ".//input[@placeholder='State']")
print("State located")





print("Billing address fields located by ID/XPath")

time.sleep(1)


# -------------------- 3. PHPtravels Blog Page --------------------
blog_url = "https://phptravels.com/blog/"
driver.get(blog_url)

print(f"\n--- Locators for page: {blog_url} ---")

# Wait for posts container
posts_container = WebDriverWait(driver, 10).until(
    EC.presence_of_element_located((By.CSS_SELECTOR, "div.posts-featured"))
)

# --- Name Locators---
search_input_by_name = driver.find_element(By.NAME, "s")
print("Search input located by name 's'")


# --- CSS Selector Locators---
search_toggle = driver.find_element(By.CSS_SELECTOR, "button.search-trigger")
print("Search toggle found")
search_toggle.click()
time.sleep(1)
search_input = driver.find_element(By.CSS_SELECTOR, "input.search-field")
print("Search input found")
search_button = driver.find_element(By.CSS_SELECTOR, "button.search-submit")
print("Search button found")
search_close = driver.find_element(By.CSS_SELECTOR, "span.header-search-form-close")
print("Search close button found")

# --- Blog Post Elements ---
# --- Blog Post Elements ---
# Get all posts (main + sidebar + recommended + listing)

# Blog posts
posts = driver.find_elements(By.CSS_SELECTOR, "article")
print(f"Found {len(posts)} posts")

for post in posts:  # Just show 2 posts for brevity
    title = post.find_element(By.CSS_SELECTOR, "h2.post-title, h3.post-featured-title").text
    link = post.find_element(By.CSS_SELECTOR, "a").get_attribute("href")
    print(f"Post title: {title}, link: {link}")

time.sleep(2)

# --- Pagination ---
try:
    next_page = driver.find_element(By.CSS_SELECTOR, "a.next.page-numbers")
    print(f"\nNext page link: {next_page.get_attribute('href')}")
except:
    print("\nNo next page found")

time.sleep(2)

# -------------------- Cleanup --------------------
driver.quit()
print("\nAll locators executed successfully!")

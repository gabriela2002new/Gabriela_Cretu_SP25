from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
import time

# -------------------- Setup Chrome Driver --------------------
chrome_options = Options()
chrome_options.add_argument("--start-maximized")

driver = webdriver.Chrome(service=ChromeService(), options=chrome_options)

# -------------------- Implicit Wait --------------------
driver.implicitly_wait(10)  # waits up to 10 seconds for elements to appear

try:
    # -------------------- 1. Open Google --------------------
    driver.get("https://www.google.com")

    # Accept cookies if the popup appears (optional, depending on region)
    try:
        accept_btn = WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable((By.XPATH, "//button[contains(text(),'I agree') or contains(text(),'Accept all')]"))
        )
        accept_btn.click()
    except:
        pass  # no popup

    # -------------------- 2. Search for "Selenium" --------------------
    search_box = WebDriverWait(driver, 20).until(
        EC.presence_of_element_located((By.NAME, "q"))
    )
    search_box.send_keys("Selenium")
    search_box.submit()

    # -------------------- 3. Click the first search result --------------------
    first_result = WebDriverWait(driver, 20).until(
        EC.element_to_be_clickable((By.CSS_SELECTOR, "div#search a"))
    )
    print("First search result link:", first_result.get_attribute("href"))
    first_result.click()

    # -------------------- Optional: Wait for page to load --------------------
    WebDriverWait(driver, 20).until(
        EC.presence_of_element_located((By.TAG_NAME, "body"))
    )

    time.sleep(3)  # wait a bit to visually confirm navigation

finally:
    driver.quit()

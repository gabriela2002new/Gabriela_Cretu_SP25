import pytest
import allure

# ---------------- TEST 1: JSONPlaceholder API ----------------
@allure.feature("Posts API")
@allure.story("Verify posts for userId=3")
@allure.label("type", "smoke")
@pytest.mark.smoke
def test_user_with_posts(provide_posts_data):
    """
    Verify that userId=3 has exactly 10 posts
    """
    posts = provide_posts_data
    assert len(posts) == 10, f"Expected 10 posts for userId=3, got {len(posts)}"

# ---------------- TEST 2: GCP -> AWS DATA SMOKE TEST ----------------
@allure.feature("Data Migration")
@allure.story("Verify GCP and AWS buckets for specific dates")
@allure.label("type", "smoke")
@pytest.mark.smoke
@pytest.mark.parametrize("date_prefix", ["2024/01/01/KTLX/", "2024/01/02/KTLX/", "2024/01/03/KTLX/"])
def test_data_is_present_for_date(date_prefix, list_gcs_blobs_for_date, list_aws_blobs_for_date):
    """
    Verify that data exists in both GCP (source) and AWS (staging) buckets for a given date.
    """
    gcs_blobs = list_gcs_blobs_for_date(date_prefix)
    aws_blobs = list_aws_blobs_for_date(date_prefix)

    assert gcs_blobs, f"No data found in GCP bucket for date {date_prefix}"
    assert aws_blobs, f"No data found in AWS bucket for date {date_prefix}"

# ---------------- TEST 3: SELENIUM EXAMPLE ----------------
@allure.feature("Selenium")
@allure.story("Smoke check example page")
def test_selenium_example(chrome_driver):
    """
    Simple Selenium test to verify the browser opens a page
    """
    url = "https://jsonplaceholder.typicode.com/"
    chrome_driver.get(url)
    assert "JSONPlaceholder" in chrome_driver.title, "Page title mismatch"

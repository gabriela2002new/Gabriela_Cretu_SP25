import pandas as pd

def sample_rows_by_year(
    csv_path: str,
    chunk_size: int,
    columns_to_drop: list,
    target_rows_per_year: int,
    other=False
):
    rows_2021 = 0
    rows_2022 = 0
    data_2021 = []
    data_2022 = []
    total_rows_cleaned = 0
    num_columns = None

    if not other:
        for chunk in pd.read_csv(csv_path, chunksize=chunk_size, dtype=str, low_memory=False):
            # Drop specified columns if they exist
            chunk = chunk[chunk["Game Category"] == "Scratch Tickets"].copy()
            cols_to_drop = [col for col in columns_to_drop if col in chunk.columns]
            if cols_to_drop:
                chunk.drop(columns=cols_to_drop, inplace=True)

            # Drop rows with any NaN values
            chunk.dropna(inplace=True)
            total_rows_cleaned += len(chunk)

            if num_columns is None:
                num_columns = chunk.shape[1]

            for year, collector, counter_name in [
                ("2021", data_2021, "rows_2021"),
                ("2022", data_2022, "rows_2022")
            ]:
                subset = chunk[chunk["Fiscal Year"] == year]
                current_rows = rows_2021 if year == "2021" else rows_2022
                available = target_rows_per_year- current_rows

                if available > 0 and not subset.empty:
                    sampled = subset.iloc[:available]
                    collector.append(sampled)

                    if year == "2021":
                        rows_2021 += len(sampled)
                    else:
                        rows_2022 += len(sampled)

            # Stop early if we've met our target for both years
            if rows_2021 >= target_rows_per_year and rows_2022 >= target_rows_per_year:
                break

    else:
        for chunk in pd.read_csv(csv_path, chunksize=chunk_size, dtype=str, low_memory=False):
            # Drop specified columns if they exist
            chunk = chunk[chunk["Game Category"] != "Scratch Tickets"].copy()
            cols_to_drop = [col for col in columns_to_drop if col in chunk.columns]
            if cols_to_drop:
                chunk.drop(columns=cols_to_drop, inplace=True)

            # Drop rows with any NaN values
            chunk.dropna(inplace=True)
            total_rows_cleaned += len(chunk)

            if num_columns is None:
                num_columns = chunk.shape[1]

            for year, collector, counter_name in [
                ("2021", data_2021, "rows_2021"),
                ("2022", data_2022, "rows_2022")
            ]:
                subset = chunk[chunk["Fiscal Year"] == year]
                current_rows = rows_2021 if year == "2021" else rows_2022
                available = target_rows_per_year - current_rows

                if available > 0 and not subset.empty:
                    sampled = subset.iloc[:available]
                    collector.append(sampled)

                    if year == "2021":
                        rows_2021 += len(sampled)
                    else:
                        rows_2022 += len(sampled)

            # Stop early if we've met our target for both years
            if rows_2021 >= target_rows_per_year  and rows_2022 >= target_rows_per_year :
                break

    # Concatenate collected chunks into DataFrames
    data_2021_df = pd.concat(data_2021) if data_2021 else pd.DataFrame()
    data_2022_df = pd.concat(data_2022) if data_2022 else pd.DataFrame()

    return data_2021_df, data_2022_df, total_rows_cleaned, num_columns

def exclude_zero_columns(df):
    """
    Returns a list of column names from the DataFrame where all values are zero.

    Parameters:
    - df (pd.DataFrame): The input DataFrame.

    Returns:
    - list: List of column names to exclude (all-zero columns).
    """
    return [col for col in df.columns if (df[col] == 0).all()]
def exclude_columns_by_index(df, column_indices):
    """
    Returns column names at the specified column indices.

    Parameters:
    - df (pd.DataFrame): The input DataFrame.
    - column_indices (list of int): Column indices to exclude.

    Returns:
    - list: Column names at the given indices.
    """
    columns = df.columns.tolist()
    return [columns[i] for i in column_indices if i < len(columns)]

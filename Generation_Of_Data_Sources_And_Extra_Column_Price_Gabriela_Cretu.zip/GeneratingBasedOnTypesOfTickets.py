import pandas as pd
import random
import Functions

random.seed(42)

# Configuration
csv_path = r"C:\Users\acer\PycharmProjects\Topic_01. Introduction to Data Warehousing\Texas_Lottery_Sales.csv"
chunk_size = 100_000
target_rows_per_year = 250_000
NUM_RANDOM_COLUMNS = 10
PRICE_OPTIONS = [1, 2, 5, 10, 20, 50]

# Columns to drop
columns_to_drop = ["Retailer Location Address 2", "Retailer Location Zip Code +4"]
scratch_specific_cols = columns_to_drop + ['Scratch Game Number', 'Ticket Price']

# Load data
data_scratch_2021_df, data_scratch_2022_df, _, _ = Functions.sample_rows_by_year(
    csv_path, chunk_size, columns_to_drop, target_rows_per_year, other=False)
data_other_2021_df, data_other_2022_df, _, _ = Functions.sample_rows_by_year(
    csv_path, chunk_size, scratch_specific_cols, target_rows_per_year, other=True)

# Combine
data_scratch = pd.concat([data_scratch_2021_df, data_scratch_2022_df], ignore_index=True)
data_other = pd.concat([data_other_2021_df, data_other_2022_df], ignore_index=True)

print("Initial Shapes:")
print("Scratch:", data_scratch.shape)
print("Other:", data_other.shape)

# Exclude columns
data_scratch_excluded = Functions.exclude_zero_columns(data_scratch) + Functions.exclude_columns_by_index(data_scratch, [4, 5, 6, 7])
data_other_excluded = Functions.exclude_zero_columns(data_other) + Functions.exclude_columns_by_index(data_other, [4, 5, 6, 7])

data_scratch = data_scratch.drop(data_scratch_excluded, axis=1)
data_other = data_other.drop(data_other_excluded, axis=1)

print("After Exclusions:")
print("Scratch:", data_scratch.shape)
print("Other:", data_other.shape)

# Define fixed columns (first 4 and last)
fixed_columns_scratch = [0, 1, 2, 3, -1]
fixed_cols_scratch = [i if i != -1 else data_scratch.shape[1] - 1 for i in fixed_columns_scratch]
fixed_columns_other = [0, 1, 2, 3,4, -1]

fixed_cols_other = [i if i != -1 else data_other.shape[1] - 1 for i in fixed_columns_other]

# Random columns for scratch
eligible_columns_scratch = list(set(range(data_scratch.shape[1])) - set(fixed_cols_scratch))
rand_cols_scratch = random.sample(eligible_columns_scratch, min(NUM_RANDOM_COLUMNS, len(eligible_columns_scratch)))
rand_cols_scratch = sorted(set(rand_cols_scratch + fixed_cols_scratch))

# Random columns for other (with overlap from scratch)
eligible_columns_other = list(set(range(data_other.shape[1])) - set(fixed_cols_other))
overlap = random.sample(rand_cols_scratch, random.randint(1, min(3, len(rand_cols_scratch))))
remaining_cols_other = list(set(eligible_columns_other) - set(rand_cols_scratch))
num_needed = NUM_RANDOM_COLUMNS - len(overlap)
num_sample = min(num_needed, len(remaining_cols_other))
rand_cols_other = sorted(set(overlap + random.sample(remaining_cols_other, num_sample) + fixed_cols_other))

# Slice columns
data_scratch = data_scratch.iloc[:, rand_cols_scratch]
data_other = data_other.iloc[:, rand_cols_other]

# Add random price column to data_other
# Assign shuffled Ticket Prices from scratch to other
if 'Ticket Price' in data_scratch.columns:
    ticket_prices = data_scratch['Ticket Price'].dropna().sample(frac=1, random_state=42).reset_index(drop=True)
    prices_to_assign = ticket_prices[:len(data_other)].copy()
    prices_to_assign.reset_index(drop=True, inplace=True)
    data_other['Price'] = prices_to_assign
else:
    raise ValueError("Ticket Price column not found in scratch data for shuffling.")

print("After Random Sampling and Price Addition:")
print("Scratch:", data_scratch.shape)
print("Other:", data_other.shape)

# Save to CSV
data_scratch.to_csv("data_scratch.csv", index=False)
data_other.to_csv("data_other.csv", index=False)

# Save to TXT
with open('scratch_2021_2022.txt', 'w') as f:
    f.write(data_scratch.to_string(index=False))

with open('other_2021_2022.txt', 'w') as f:
    f.write(data_other.to_string(index=False))

import pytest
import allure


@pytest.mark.usefixtures("db_cursor")
def test_yaml_queries(yaml_test, db_cursor):
    sql = yaml_test["sql"]
    expected = yaml_test["expected"]
    name = yaml_test["name"]

    with allure.step(f"Running test: {name}"):
        db_cursor.execute(sql)
        result = db_cursor.fetchone()
        cnt = result[0] if result else None

        assert cnt == expected, f"{name} failed: expected {expected}, got {cnt}"

import pytest
import psycopg2
import yaml
import allure
import subprocess
import pytest
import os



# ============================
# DB connection
# ============================
def connect_to_db_postgre():
    conn = psycopg2.connect(
        database="dwh_hw_db",
        user="postgres",
        password="CretuPaul1990.",
        host="localhost",
        port=5432,
    )
    try:
        cursor = conn.cursor()
        yield cursor
    finally:
        cursor.close()
        conn.close()


@pytest.fixture(scope="module")
def db_cursor():
    yield from connect_to_db_postgre()


# ============================
# Load tests from YAML
# ============================
def pytest_generate_tests(metafunc):
    if "yaml_test" in metafunc.fixturenames:
        with open("tests.yaml") as f:
            data = yaml.safe_load(f)["tests"]

        # Attach pytest markers dynamically
        test_ids = []
        marked_data = []
        for t in data:
            mark = getattr(pytest.mark, t.get("marker", "smoke"))
            marked_data.append(pytest.param(t, marks=mark))
            test_ids.append(t["name"])

        metafunc.parametrize("yaml_test", marked_data, ids=test_ids)


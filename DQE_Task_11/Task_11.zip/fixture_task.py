import time
import pytest


# Suite-level fixture (runs once, before and after the full test suite)
@pytest.fixture(scope="session", autouse=True)
def track_suite_time():
    start = time.time()
    print("\n[SUITE START]")
    yield
    end = time.time()
    print(f"[SUITE END] Total suite time: {end - start:.4f} seconds")


# Test-level fixture (runs before and after each test)
@pytest.fixture()
def track_test_time():
    start = time.time()
    print("[TEST START]")
    yield
    end = time.time()
    print(f"[TEST END] Test duration: {end - start:.4f} seconds")


def add_numbers(a, b):
    return a + b


def test_add_two_positive_numbers(track_test_time):
    a, b = 3, 5
    result = add_numbers(a, b)
    time.sleep(2)
    assert result == 8


def test_add_two_negative_numbers(track_test_time):
    a, b = -3, -5
    result = add_numbers(a, b)
    time.sleep(3)
    assert result == -8


def test_add_negative_and_positive_numbers():  # last test, no fixture
    a, b = -3, 5
    result = add_numbers(a, b)
    time.sleep(10)
    assert result == 2

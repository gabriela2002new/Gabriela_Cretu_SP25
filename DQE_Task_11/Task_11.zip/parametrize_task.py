import pytest
import yaml

def get_numbers_data(config_name="config.yaml"):
    with open(config_name, 'r') as stream:
        config = yaml.safe_load(stream)
    return config['cases']

def add_numbers(a, b, c):
    if not all(isinstance(x, (int, float)) for x in [a, b, c]):
        raise TypeError("Please check the parameters. All of them must be numeric")
    return a + b + c

# Parametrized test with case names from YAML
@pytest.mark.parametrize("case", get_numbers_data(), ids=lambda x: x['case_name'])
@pytest.mark.smoke
def test_add_numbers(case):
    a, b, c = case['input']
    expected = case['expected']
    assert add_numbers(a, b, c) == expected

# Test to verify exception for invalid types
@pytest.mark.critical
def test_add_invalid_types():
    with pytest.raises(TypeError) as exc:
        add_numbers('a', 2, 1)
    assert str(exc.value) == "Please check the parameters. All of them must be numeric"

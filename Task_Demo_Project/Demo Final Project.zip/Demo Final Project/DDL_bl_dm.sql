CREATE OR REPLACE PROCEDURE bl_cl.create_bl_dm_sequences()
LANGUAGE plpgsql
AS $$
BEGIN
    -- Create all surrogate key sequences
    CREATE SEQUENCE IF NOT EXISTS game_number_surr_seq START 1 INCREMENT 1;
    CREATE SEQUENCE IF NOT EXISTS customer_surr_seq START 1 INCREMENT 1;
    CREATE SEQUENCE IF NOT EXISTS retailer_license_number_surr_seq START 1 INCREMENT 1;
    CREATE SEQUENCE IF NOT EXISTS employee_surr_seq START 1 INCREMENT 1;
    CREATE SEQUENCE IF NOT EXISTS payment_method_surr_seq START 1 INCREMENT 1;
END;
$$;

CREATE OR REPLACE PROCEDURE bl_cl.create_bl_dm_objects()
LANGUAGE plpgsql
AS $$
BEGIN
    -- Create schema
    CREATE SCHEMA IF NOT EXISTS bl_dm;

    -- Create tables
    CREATE TABLE IF NOT EXISTS bl_dm.dim_game_numbers (
        game_number_surr_id BIGINT PRIMARY KEY,
        game_number_src_id VARCHAR(255) UNIQUE,
        game_number_name VARCHAR(100),
        game_category_id BIGINT,
        game_category_name VARCHAR(100),
        game_type_id BIGINT,
        game_type_name VARCHAR(100),
        draw_dt DATE,
        average_odds VARCHAR(30),
        average_odds_prob FLOAT,
        mid_tier_prize FLOAT,
        top_tier_prize FLOAT,
        small_prize FLOAT,
        winning_chance FLOAT,
        winning_jackpot FLOAT,
        source_system VARCHAR(30),
        source_entity VARCHAR(30),
        insert_dt DATE,
        update_dt DATE
    );

    CREATE TABLE IF NOT EXISTS bl_dm.dim_retailer_license_numbers (
        retailer_license_number_surr_id BIGINT PRIMARY KEY,
        retailer_license_number_src_id VARCHAR(255) UNIQUE,
        retailer_license_number_name VARCHAR(100),
        retailer_location_name_id BIGINT,
        retailer_location_name VARCHAR(100),
        zip_id BIGINT,
        zip_name VARCHAR(100),
        city_id BIGINT,
        city_name VARCHAR(100),
        state_id BIGINT,
        state_name VARCHAR(100),
        source_system VARCHAR(30),
        source_entity VARCHAR(30),
        insert_dt DATE,
        update_dt DATE
    );

    CREATE TABLE IF NOT EXISTS bl_dm.dim_customers_scd (
        customer_surr_id BIGINT PRIMARY KEY,
        customer_src_id VARCHAR(255),
        customer_name VARCHAR(100),
        customer_registration_dt DATE,
        zip_id BIGINT,
        zip_name VARCHAR(100),
        city_id BIGINT,
        city_name VARCHAR(100),
        state_id BIGINT,
        state_name VARCHAR(100),
        customer_gender VARCHAR(20),
        customer_dob DATE,
        customer_email VARCHAR(100),
        customer_phone VARCHAR(50),
        source_system VARCHAR(30),
        source_entity VARCHAR(30),
        insert_dt DATE,
        start_dt DATE,
        end_dt DATE,
        is_active BOOLEAN,
        CONSTRAINT uq_customer_src_start UNIQUE (customer_src_id, start_dt)

    );

    CREATE TABLE IF NOT EXISTS bl_dm.dim_employees (
        employee_surr_id BIGINT PRIMARY KEY,
        employee_src_id VARCHAR(255) UNIQUE,
        employee_name VARCHAR(100),
        employee_hire_dt DATE,
        employee_status_id BIGINT,
        employee_status_name VARCHAR(100),
        employee_department_id BIGINT,
        employee_department_name VARCHAR(100),
        employee_email VARCHAR(100),
        employee_phone VARCHAR(50),
        employee_salary FLOAT,
        source_system VARCHAR(30),
        source_entity VARCHAR(30),
        insert_dt DATE,
        update_dt DATE
    );

    CREATE TABLE IF NOT EXISTS bl_dm.dim_payment_methods (
        payment_method_surr_id BIGINT PRIMARY KEY,
        payment_method_src_id VARCHAR(255) UNIQUE,
        payment_method_name VARCHAR(100),
        source_system VARCHAR(30),
        source_entity VARCHAR(30),
        insert_dt DATE,
        update_dt DATE
    );

    CREATE TABLE IF NOT EXISTS bl_dm.fct_sales (
    game_number_surr_id BIGINT REFERENCES bl_dm.dim_game_numbers(game_number_surr_id) ON DELETE CASCADE,
    customer_surr_id BIGINT REFERENCES bl_dm.dim_customers_scd(customer_surr_id) ON DELETE CASCADE,
    employee_surr_id BIGINT REFERENCES bl_dm.dim_employees(employee_surr_id) ON DELETE CASCADE,
    retailer_license_number_surr_id BIGINT REFERENCES bl_dm.dim_retailer_license_numbers(retailer_license_number_surr_id) ON DELETE CASCADE,
    payment_method_surr_id BIGINT REFERENCES bl_dm.dim_payment_methods(payment_method_surr_id) ON DELETE CASCADE,
    event_dt DATE REFERENCES bl_dm.dim_date(event_dt) ON DELETE CASCADE,
    ticket_price FLOAT,
    tickets_bought INT,
    payout FLOAT,
    sales FLOAT,
    insert_dt DATE,
    update_dt DATE,

    CONSTRAINT fct_sales_grain_unique UNIQUE (
        game_number_surr_id,
        customer_surr_id,
        employee_surr_id,
        retailer_license_number_surr_id,
        payment_method_surr_id,
        event_dt
    )
);


    RAISE NOTICE 'DM objects created successfully.';
END;
$$;


CREATE OR REPLACE PROCEDURE bl_cl.create_bl_dm_default_records()
LANGUAGE plpgsql
AS $$
BEGIN
-- Insert default rows
    INSERT INTO bl_dm.dim_game_numbers VALUES 
        (-1, 'n. a.', 'n. a.', -1, 'n. a.', -1, 'n. a.', DATE '1900-01-01', 'n. a.', -1, -1, -1, -1, -1, -1, 'MANUAL', 'MANUAL', DATE '1900-01-01', DATE '1900-01-01') 
        ON CONFLICT DO NOTHING;

    INSERT INTO bl_dm.dim_retailer_license_numbers VALUES 
        (-1, 'n. a.', 'n. a.', -1, 'n. a.', -1, 'n. a.', -1, 'n. a.', -1, 'n. a.', 'MANUAL', 'MANUAL', DATE '1900-01-01', DATE '1900-01-01') 
        ON CONFLICT DO NOTHING;

    INSERT INTO bl_dm.dim_customers_scd VALUES 
        (-1, 'n. a.', 'n. a.', DATE '1900-01-01', -1, 'n. a.', -1, 'n. a.', -1, 'n. a.', 'n. a.', DATE '1900-01-01', 'n. a.', 'n. a.', 'MANUAL', 'MANUAL', DATE '1900-01-01', DATE '1900-01-01', DATE '9999-12-31', TRUE) 
        ON CONFLICT DO NOTHING;

    INSERT INTO bl_dm.dim_employees VALUES 
        (-1, 'n. a.', 'n. a.', DATE '1900-01-01', -1, 'n. a.', -1, 'n. a.', 'n. a.', 'n. a.', -1, 'MANUAL', 'MANUAL', DATE '1900-01-01', DATE '1900-01-01') 
        ON CONFLICT DO NOTHING;

    INSERT INTO bl_dm.dim_payment_methods VALUES 
        (-1, 'n. a.', 'n. a.', 'MANUAL', 'MANUAL', DATE '1900-01-01', DATE '1900-01-01') 
        ON CONFLICT DO NOTHING;
END;
$$;

CREATE OR REPLACE PROCEDURE bl_cl.create_bl_dm_all_objects()
LANGUAGE plpgsql
AS $$
BEGIN
    CALL bl_cl.create_bl_dm_sequences();
    CALL bl_cl.create_bl_dm_objects();
    CALL bl_cl.create_bl_dm_default_records();
END;
$$;





call bl_cl.create_bl_dm_default_records();

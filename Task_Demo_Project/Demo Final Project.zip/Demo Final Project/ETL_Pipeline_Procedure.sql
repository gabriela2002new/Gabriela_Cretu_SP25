CREATE OR REPLACE FUNCTION bl_cl.fn_get_batch_from_source(
    p_schema TEXT,
    p_table TEXT,
    p_start_date DATE,
    p_end_date DATE
)
RETURNS SETOF RECORD
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY EXECUTE FORMAT(
        'SELECT * FROM %I.%I WHERE transaction_dt BETWEEN %L AND %L',
        p_schema, p_table, p_start_date, p_end_date
    );
END;
$$;

CREATE OR REPLACE PROCEDURE  bl_cl.p_load_all_ce_data(v_date date)
LANGUAGE plpgsql
AS $$
BEGIN
    -- Load all CE data in dependency-respecting order
    CALL bl_cl.p_load_ce_game_types(v_date);
    CALL bl_cl.p_load_ce_game_categories(v_date);
    CALL bl_cl.p_load_ce_game_numbers(v_date);
    
    CALL bl_cl.p_load_ce_payment_methods(v_date);
    
    CALL bl_cl.p_load_ce_states(v_date);
    CALL bl_cl.p_load_ce_cities(v_date);
    CALL bl_cl.p_load_ce_zip(v_date);
   CALL bl_cl.p_load_ce_location_names(v_date);
    CALL bl_cl.p_load_retailer_license_numbers(v_date);

    CALL bl_cl.p_load_ce_statuses(v_date);
    CALL bl_cl.p_load_ce_departments(v_date);
    CALL bl_cl.p_load_ce_employees(v_date);

    CALL bl_cl.p_load_ce_customers_scd(v_date);
    call bl_cl.p_load_ce_sales(v_date);

    RAISE NOTICE 'All CE data loaded successfully.';
END;
$$;

CREATE OR REPLACE PROCEDURE bl_cl.p_load_all_bl_dm_data(v_date date)
LANGUAGE plpgsql
AS $$
BEGIN
    -- Load dimensions first in dependency order
    CALL bl_cl.sp_upsert_dim_game_numbers(v_date);
    CALL bl_cl.sp_upsert_dim_payment_methods(v_date);
    CALL bl_cl.sp_upsert_dim_retailer_license_numbers(v_date);
    CALL bl_cl.sp_upsert_dim_employees(v_date);
    CALL bl_cl.sp_upsert_dim_customers_scd(v_date);

    -- Load fact table after dims are ready
    call bl_cl.sp_insert_fct_sales(v_date);


    RAISE NOTICE 'All BL_DM data loaded successfully.';
END;
$$;



CREATE OR REPLACE PROCEDURE bl_cl.sp_full_etl_process(
    p_start_date DATE,
    p_end_date DATE
)
LANGUAGE plpgsql
AS $$
BEGIN
    -- Create temp tables if not exist (using CREATE TEMP TABLE ON COMMIT PRESERVE ROWS)
    -- We'll use ON COMMIT PRESERVE ROWS so they survive across transactions in the session

    
        CREATE TEMP TABLE tmp_scratch_batch (
            transaction_dt VARCHAR,
            retailer_license_number VARCHAR,
            customer_id VARCHAR,
            employee_id VARCHAR,
            game_number VARCHAR,
            tickets_bought VARCHAR,
            payment_method_id VARCHAR,
            sales VARCHAR,
            payout VARCHAR,
            customer_name VARCHAR,
            customer_gender VARCHAR,
            customer_dob VARCHAR,
            employee_name VARCHAR,
            employee_department VARCHAR,
            employee_status VARCHAR,
            retailer_location_name VARCHAR,
            retailer_location_zip_code VARCHAR,
            retailer_location_city VARCHAR,
            ticket_price VARCHAR,
            game_category VARCHAR,
            game_type VARCHAR,
            average_odds VARCHAR,
            average_odds_prob VARCHAR,
            top_prize VARCHAR,
            mid_prize VARCHAR,
            small_prize VARCHAR,
            payment_method_name VARCHAR
        ) ;

    -- Load data into tmp_scratch_batch
    INSERT INTO tmp_scratch_batch
    SELECT * FROM bl_cl.fn_get_batch_from_source(
        'sa_final_scratch',
        'src_final_scratch',
        p_start_date,
        p_end_date
    ) AS t (
        transaction_dt VARCHAR,
        retailer_license_number VARCHAR,
        customer_id VARCHAR,
        employee_id VARCHAR,
        game_number VARCHAR,
        tickets_bought VARCHAR,
        payment_method_id VARCHAR,
        sales VARCHAR,
        payout VARCHAR,
        customer_name VARCHAR,
        customer_gender VARCHAR,
        customer_dob VARCHAR,
        employee_name VARCHAR,
        employee_department VARCHAR,
        employee_status VARCHAR,
        retailer_location_name VARCHAR,
        retailer_location_zip_code VARCHAR,
        retailer_location_city VARCHAR,
        ticket_price VARCHAR,
        game_category VARCHAR,
        game_type VARCHAR,
        average_odds VARCHAR,
        average_odds_prob VARCHAR,
        top_prize VARCHAR,
        mid_prize VARCHAR,
        small_prize VARCHAR,
        payment_method_name VARCHAR
    );

    -- Temp table for draw batch
 
        CREATE TEMP TABLE tmp_draw_batch (
            transaction_dt VARCHAR,
            retailer_license_number VARCHAR,
            customer_id VARCHAR,
            employee_id VARCHAR,
            game_number VARCHAR,
            payment_method_id VARCHAR,
            sales VARCHAR,
            tickets_bought VARCHAR,
            payout VARCHAR,
            customer_email VARCHAR,
            customer_phone VARCHAR,
            customer_registration_dt VARCHAR,
            customer_state VARCHAR,
            customer_city VARCHAR,
            customer_zip_code VARCHAR,
            employee_email VARCHAR,
            employee_phone VARCHAR,
            employee_hire_dt VARCHAR,
            employee_salary VARCHAR,
            retailer_location_name VARCHAR,
            retailer_location_zip_code VARCHAR,
            retailer_location_state VARCHAR,
            game_category VARCHAR,
            game_type VARCHAR,
            ticket_price VARCHAR, 
            winning_chance VARCHAR,
            winning_jackpot VARCHAR,
            draw_dt VARCHAR,
            payment_method_name VARCHAR
        ) ;

    -- Load data into tmp_draw_batch
    INSERT INTO tmp_draw_batch
    SELECT * FROM bl_cl.fn_get_batch_from_source(
        'sa_final_draw',
        'src_final_draw',
        p_start_date,
        p_end_date
    ) AS t (
        transaction_dt VARCHAR,
        retailer_license_number VARCHAR,
        customer_id VARCHAR,
        employee_id VARCHAR,
        game_number VARCHAR,
        payment_method_id VARCHAR,
        sales VARCHAR,
        tickets_bought VARCHAR,
        payout VARCHAR,
        customer_email VARCHAR,
        customer_phone VARCHAR,
        customer_registration_dt VARCHAR,
        customer_state VARCHAR,
        customer_city VARCHAR,
        customer_zip_code VARCHAR,
        employee_email VARCHAR,
        employee_phone VARCHAR,
        employee_hire_dt VARCHAR,
        employee_salary VARCHAR,
        retailer_location_name VARCHAR,
        retailer_location_zip_code VARCHAR,
        retailer_location_state VARCHAR,
        game_category VARCHAR,
        game_type VARCHAR,
        ticket_price VARCHAR, 
        winning_chance VARCHAR,
        winning_jackpot VARCHAR,
        draw_dt VARCHAR,
        payment_method_name VARCHAR
    );

    -- Now call all ETL procedures in sequence

    CALL bl_cl.sp_insert_meta_game_types(); 
    CALL bl_cl.sp_load_wrk_game_types();
    CALL bl_cl.sp_upsert_lkp_game_types();

    CALL bl_cl.sp_insert_meta_game_categories();
    CALL bl_cl.sp_load_wrk_game_categories();
    CALL bl_cl.sp_upsert_lkp_game_categories();

     CALL bl_cl.sp_insert_meta_game_numbers();
    CALL bl_cl.sp_load_wrk_game_numbers();
    CALL bl_cl.sp_upsert_lkp_game_numbers();

    CALL bl_cl.sp_insert_meta_payment_methods();
    CALL bl_cl.sp_load_wrk_payment_methods();
    CALL bl_cl.sp_upsert_lkp_payment_methods();
    
    CALL bl_cl.sp_insert_meta_states();
    CALL bl_cl.sp_load_wrk_states();
    CALL bl_cl.sp_upsert_lkp_states();

    CALL bl_cl.sp_insert_meta_cities();
    CALL bl_cl.sp_load_wrk_cities();
    CALL bl_cl.sp_upsert_lkp_cities();

    CALL bl_cl.sp_insert_meta_zips();
    CALL bl_cl.sp_load_wrk_zips();
    CALL bl_cl.sp_upsert_lkp_zips();

    CALL bl_cl.sp_insert_meta_location_names();
    CALL bl_cl.sp_load_wrk_location_names();
    CALL bl_cl.sp_upsert_lkp_location_names();

    CALL bl_cl.sp_insert_meta_retailers();
    CALL bl_cl.sp_load_wrk_retailers();
    CALL bl_cl.sp_upsert_lkp_retailers();

    CALL bl_cl.sp_insert_meta_statuses();
    CALL bl_cl.sp_load_wrk_statuses();
    CALL bl_cl.sp_upsert_lkp_statuses();

    CALL bl_cl.sp_insert_meta_departments();
    CALL bl_cl.sp_load_wrk_departments();
    CALL bl_cl.sp_upsert_lkp_departments();

    CALL bl_cl.sp_insert_meta_employees();
    CALL bl_cl.sp_load_wrk_employees();
    CALL bl_cl.sp_upsert_lkp_employees();

    CALL bl_cl.sp_insert_meta_customers();
    CALL bl_cl.sp_load_wrk_customers();
    CALL bl_cl.sp_upsert_lkp_customers();

    CALL bl_cl.sp_insert_meta_sales();
    CALL bl_cl.sp_load_wrk_sales();
    CALL bl_cl.sp_upsert_lkp_sales();
   
    DROP TABLE IF EXISTS tmp_scratch_batch;
    DROP TABLE IF EXISTS tmp_draw_batch;



END;
$$;









                
CREATE OR REPLACE PROCEDURE bl_cl.sp_run_transaction_etl_batch()
LANGUAGE plpgsql
AS $$
DECLARE
    v_date DATE;
    v_last_processed_scratch DATE;
    v_last_processed_draw DATE;
BEGIN
    SELECT COALESCE(last_processed_date, '1900-01-01')
INTO v_last_processed_scratch
FROM bl_cl.etl_tracker WHERE source_name = 'sa_final_scratch';

SELECT COALESCE(last_processed_date, '1900-01-01')
INTO v_last_processed_draw
FROM bl_cl.etl_tracker WHERE source_name = 'sa_final_draw';

    -- Loop over all distinct transaction dates after last processed dates
    FOR v_date IN
        SELECT DISTINCT transaction_dt::DATE
        FROM (
            SELECT transaction_dt FROM sa_final_scratch.src_final_scratch
            WHERE transaction_dt::DATE > COALESCE(v_last_processed_scratch, '1900-01-01')
            UNION
            SELECT transaction_dt FROM sa_final_draw.src_final_draw
            WHERE transaction_dt::DATE > COALESCE(v_last_processed_draw, '1900-01-01')
        ) combined_dates
        ORDER BY 1
    LOOP
        BEGIN
            RAISE NOTICE 'Processing ETL for transaction date: %', v_date;

            CALL bl_cl.sp_full_etl_process(v_date, v_date);
            CALL bl_cl.p_load_all_ce_data(v_date);
            CALL bl_cl.p_load_all_bl_dm_data(v_date);

            -- Process and update tracker for scratch source
            IF EXISTS (
                SELECT 1 FROM sa_final_scratch.src_final_scratch
                WHERE transaction_dt::DATE = v_date
            ) THEN
                INSERT INTO bl_cl.etl_tracker (source_name, last_processed_date)
                VALUES ('sa_final_scratch', v_date)
                ON CONFLICT (source_name) DO UPDATE
                SET last_processed_date = GREATEST(EXCLUDED.last_processed_date, etl_tracker.last_processed_date);
            END IF;

            -- Process and update tracker for draw source
            IF EXISTS (
                SELECT 1 FROM sa_final_draw.src_final_draw
                WHERE transaction_dt::DATE = v_date
            ) THEN
                INSERT INTO bl_cl.etl_tracker (source_name, last_processed_date)
                VALUES ('sa_final_draw', v_date)
                ON CONFLICT (source_name) DO UPDATE
                SET last_processed_date = GREATEST(EXCLUDED.last_processed_date, etl_tracker.last_processed_date);
            END IF;

            -- 🧠 Refresh last processed values for the next loop
            SELECT last_processed_date INTO v_last_processed_scratch
            FROM bl_cl.etl_tracker WHERE source_name = 'sa_final_scratch';

            SELECT last_processed_date INTO v_last_processed_draw
            FROM bl_cl.etl_tracker WHERE source_name = 'sa_final_draw';

        EXCEPTION WHEN OTHERS THEN
            RAISE WARNING 'ETL failed for transaction date %: %', v_date, SQLERRM;
            CONTINUE;
        END;
    END LOOP;

    RAISE NOTICE 'ETL completed for all new transaction dates.';
END;
$$;


----running the master procedure-----
CALL bl_cl.sp_run_transaction_etl_batch();


--last dates processed
select *
from bl_cl.etl_tracker et ;


----run the procedure
call bl_cl.sp_run_transaction_etl_batch();




-----test counts-----------
select count(*) from bl_cl.lkp_cities;
select count(*) from bl_3nf.ce_cities;

select count(*) from bl_cl.lkp_customers;
select count(*) from bl_3nf.ce_customers_scd;
select count(*) from bl_dm.dim_customers_scd;

select count(*) from bl_cl.lkp_departments;
select count(*) from bl_3nf.ce_departments;

select count(*) from bl_cl.lkp_employees;
select count(*) from bl_dm.dim_employees;
select count(*) from bl_3nf.ce_employees;

select count(*) from bl_cl.lkp_game_categories;
select count(*) from bl_3nf.ce_game_categories;

select count(*) from bl_cl.lkp_game_numbers;
select count(*) from bl_dm.dim_game_numbers;
select count(*) from bl_3nf.ce_game_numbers;

select count(*) from bl_cl.lkp_game_types;
select count(*) from bl_3nf.ce_game_types;

select count(*) from bl_cl.lkp_location_names;
select count(*) from bl_3nf.ce_location_names;

select count(*) from bl_cl.lkp_payment_methods;
select count(*) from bl_dm.dim_payment_methods;
select count(*) from bl_3nf.ce_payment_methods;

select count(*) from bl_cl.lkp_retailers;
select count(*) from bl_dm.dim_retailer_license_numbers;
select count(*) from bl_3nf.ce_retailer_license_numbers;

select count(*) from bl_cl.lkp_sales;
select count(*) from bl_dm.fct_sales;
select count(*) from bl_3nf.ce_sales;

select count(*) from bl_cl.lkp_states;
select count(*) from bl_3nf.ce_states;

select count(*) from bl_cl.lkp_statuses;
select count(*) from bl_3nf.ce_statuses;

select count(*) from bl_cl.lkp_zips;
select count(*) from bl_3nf.ce_zip;

select count(*) from bl_3nf.ce_employees ce;
select count(*) from bl_dm.dim_employees de ;
select count(*) from bl_cl.lkp_employees le;



----fix the etl tracker to the last update dt in the first 90%
 -- Process and update tracker for scratch source
select * from bl_cl.etl_tracker et; 

begin;
INSERT INTO bl_cl.etl_tracker (source_name, last_processed_date)
VALUES ('sa_final_scratch', '2022-02-24'::date)
ON CONFLICT (source_name) DO UPDATE
SET last_processed_date = '2022-02-24'::date;
commit;
-- Process and update tracker for draw source
begin;
INSERT INTO bl_cl.etl_tracker (source_name, last_processed_date)
VALUES ('sa_final_draw', '2022-02-24'::date)
ON CONFLICT (source_name) DO UPDATE
SET last_processed_date = '2022-02-24'::date;
commit;


----rerun the procedure ----
call bl_cl.sp_run_transaction_etl_batch();

----check how many rows affected---
SELECT *
FROM bl_3nf.etl_logs
WHERE 
    (
        
         procedure_name ILIKE '%ce_customers_scd%'
        OR procedure_name ILIKE '%ce_departments%'
        OR procedure_name ILIKE '%ce_statuses%'
        OR procedure_name ILIKE '%ce_retailer_license_numbers%'
        OR procedure_name ILIKE '%ce_location_names%'
        OR procedure_name ILIKE '%ce_zip%'
        OR procedure_name ILIKE '%ce_cities%'
        OR procedure_name ILIKE '%ce_states%'
        OR procedure_name ILIKE '%ce_payment_methods%'
        OR procedure_name ILIKE '%ce_game_numbers%'
        OR procedure_name ILIKE '%ce_game_categories%'
        OR procedure_name ILIKE '%ce_game_types%'
         OR procedure_name ilike '%dim_retailer_license_numbers%'
        OR procedure_name ilike '%dim_game_numbers%'
        OR procedure_name ilike '%dim_payment_method%'
        OR procedure_name ilike '%fct_sales%'
        or procedure_name ilike '%dim_customers_scd%'
        or  procedure_name ilike '%ce_employees%'
        or  procedure_name ilike '%dim_employees%'
         or procedure_name ilike '%ce_sales%'
        
    )
    AND rows_affected >0
ORDER BY log_timestamp DESC;


----check the scd type 2 and type 1---

select count(*) from bl_3nf.ce_customers_scd ccs ;
SELECT * 
FROM bl_3nf.ce_customers_scd ccs
WHERE ccs.customer_src_id IN (
  'VAN HORN_001',
  'VAN HORN_021',
  'VAN HORN_023',
  'VAN HORN_044',
  'VAN HORN_056',
  'VAN HORN_086',
  'VAN HORN_088',
  'VAN HORN_102',
  'VAN HORN_007',
  'VAN HORN_047',
  'VAN HORN_048',
  'VAN HORN_094',
  'VAN HORN_106',
  'VAN HORN_122',
  'VAN HORN_124',
  'VAN HORN_153',
  'VAN HORN_011',
  'VAN HORN_027'
) order by ccs.customer_src_id ;


SELECT * 
FROM bl_3nf.ce_employees ce 
WHERE ce.employee_src_id IN (
  'EMP_100021_1',
  'EMP_100021_2',
  'EMP_100021_3'
);


select *
from bl_dm.dim_employees de 
WHERE de.employee_src_id IN (
  '28', '44','48'
);


select * from bl_dm.dim_customers_scd dcs 
where dcs.customer_src_id in ('799', '803','806')
order by dcs.customer_src_id ;


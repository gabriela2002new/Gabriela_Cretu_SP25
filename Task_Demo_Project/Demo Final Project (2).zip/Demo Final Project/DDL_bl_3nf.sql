CREATE OR REPLACE PROCEDURE bl_cl.create_bl_3nf_sequences()
LANGUAGE plpgsql
AS $$
BEGIN
    CREATE SEQUENCE IF NOT EXISTS bl_cl.t_map_game_types_seq START 1;
    CREATE SEQUENCE IF NOT EXISTS bl_cl.ce_game_categories_seq START 1;
    CREATE SEQUENCE IF NOT EXISTS bl_cl.ce_game_numbers_seq START 1;
    CREATE SEQUENCE IF NOT EXISTS bl_cl.ce_payment_methods_seq START 1;
    CREATE SEQUENCE IF NOT EXISTS bl_cl.ce_states_seq START 1;
    CREATE SEQUENCE IF NOT EXISTS bl_cl.ce_cities_seq START 1;
    CREATE SEQUENCE IF NOT EXISTS bl_cl.ce_zips_seq START 1;
    CREATE SEQUENCE IF NOT EXISTS bl_cl.ce_location_names_seq START 1;
    CREATE SEQUENCE IF NOT EXISTS bl_cl.t_mapping_retailer_license_seq START 1;
    CREATE SEQUENCE IF NOT EXISTS bl_cl.t_mapping_status_seq START 1;
    CREATE SEQUENCE IF NOT EXISTS bl_cl.t_mapping_department_seq START 1;
    CREATE SEQUENCE IF not EXISTS bl_cl.t_mapping_employees_seq start 1;
    CREATE SEQUENCE IF not EXISTS bl_cl.t_mapping_customers_seq start 1;
    RAISE NOTICE 'All sequences created successfully.';
END;
$$;


CREATE OR REPLACE PROCEDURE bl_cl.create_bl_3nf_objects()
LANGUAGE plpgsql
AS $$
BEGIN
    -- Game Types
    CREATE TABLE IF NOT EXISTS bl_3nf.ce_game_types (
        GAME_TYPE_ID     BIGINT PRIMARY KEY,
        GAME_TYPE_SRC_ID VARCHAR(255) UNIQUE,
        GAME_TYPE_NAME   VARCHAR(100),
        SOURCE_SYSTEM    VARCHAR(30),
        SOURCE_ENTITY    VARCHAR(30),
        INSERT_DT        DATE,
        UPDATE_DT        DATE
    );

    -- Game Categories
    CREATE TABLE IF NOT EXISTS bl_3nf.ce_game_categories (
        GAME_CATEGORY_ID BIGINT PRIMARY KEY,
        GAME_CATEGORY_SRC_ID VARCHAR(255) UNIQUE,
        GAME_TYPE_ID BIGINT REFERENCES bl_3nf.ce_game_types(GAME_TYPE_ID) ON DELETE CASCADE,
        GAME_CATEGORY_NAME VARCHAR(100),
        WINNING_CHANCE FLOAT,
        WINNING_JACKPOT FLOAT,
        SOURCE_SYSTEM VARCHAR(30),
        SOURCE_ENTITY VARCHAR(30),
        INSERT_DT DATE,
        UPDATE_DT DATE
    );

    -- Game Numbers
    CREATE TABLE IF NOT EXISTS bl_3nf.ce_game_numbers (
        GAME_NUMBER_ID BIGINT PRIMARY KEY,
        GAME_NUMBER_SRC_ID VARCHAR(255) UNIQUE,
        GAME_CATEGORY_ID BIGINT REFERENCES bl_3nf.ce_game_categories(GAME_CATEGORY_ID) ON DELETE CASCADE,
        DRAW_DT DATE,
        GAME_NUMBER_NAME VARCHAR(100),
        AVERAGE_ODDS VARCHAR(30),
        AVERAGE_ODDS_PROB FLOAT,
        MID_TIER_PRIZE FLOAT,
        TOP_TIER_PRIZE FLOAT,
        SMALL_PRIZE FLOAT,
        SOURCE_SYSTEM VARCHAR(30),
        SOURCE_ENTITY VARCHAR(30),
        INSERT_DT DATE,
        UPDATE_DT DATE
    );

    -- Payment Methods
    CREATE TABLE IF NOT EXISTS bl_3nf.ce_payment_methods (
        PAYMENT_METHOD_ID BIGINT PRIMARY KEY,
        PAYMENT_METHOD_SRC_ID VARCHAR(255) UNIQUE,
        PAYMENT_METHOD_NAME VARCHAR(100),
        SOURCE_SYSTEM VARCHAR(30),
        SOURCE_ENTITY VARCHAR(30),
        INSERT_DT DATE,
        UPDATE_DT DATE
    );

    -- States
    CREATE TABLE IF NOT EXISTS bl_3nf.ce_states (
        STATE_ID BIGINT PRIMARY KEY,
        STATE_SRC_ID VARCHAR(255) UNIQUE,
        STATE_NAME VARCHAR(100),
        SOURCE_SYSTEM VARCHAR(30),
        SOURCE_ENTITY VARCHAR(30),
        INSERT_DT DATE,
        UPDATE_DT DATE
    );

    -- Cities
    CREATE TABLE IF NOT EXISTS bl_3nf.ce_cities (
        CITY_ID BIGINT PRIMARY KEY,
        CITY_SRC_ID VARCHAR(255) UNIQUE,
        STATE_ID BIGINT REFERENCES bl_3nf.ce_states(STATE_ID) ON DELETE CASCADE,
        CITY_NAME VARCHAR(100),
        SOURCE_SYSTEM VARCHAR(30),
        SOURCE_ENTITY VARCHAR(30),
        INSERT_DT DATE,
        UPDATE_DT DATE
    );

    -- Zip Codes
    CREATE TABLE IF NOT EXISTS bl_3nf.ce_zip (
        ZIP_ID BIGINT PRIMARY KEY,
        ZIP_SRC_ID VARCHAR(255) UNIQUE,
        CITY_ID BIGINT REFERENCES bl_3nf.ce_cities(CITY_ID) ON DELETE CASCADE,
        ZIP_NAME VARCHAR(100),
        SOURCE_SYSTEM VARCHAR(30),
        SOURCE_ENTITY VARCHAR(30),
        INSERT_DT DATE,
        UPDATE_DT DATE
    );

    -- Location Names
    CREATE TABLE IF NOT EXISTS bl_3nf.ce_location_names (
        LOCATION_NAME_ID BIGINT PRIMARY KEY,
        LOCATION_NAME_SRC_ID VARCHAR(255) UNIQUE,
        ZIP_ID BIGINT REFERENCES bl_3nf.ce_zip(ZIP_ID) ON DELETE CASCADE,
        LOCATION_NAME VARCHAR(100),
        SOURCE_SYSTEM VARCHAR(30),
        SOURCE_ENTITY VARCHAR(30),
        INSERT_DT DATE,
        UPDATE_DT DATE
    );

    -- Retailer License Numbers
    CREATE TABLE IF NOT EXISTS bl_3nf.ce_retailer_license_numbers (
        RETAILER_LICENSE_NUMBER_ID BIGINT PRIMARY KEY,
        RETAILER_LICENSE_NUMBER_SRC_ID VARCHAR(255) UNIQUE,
        RETAILER_LOCATION_NAME_ID BIGINT REFERENCES bl_3nf.ce_location_names(LOCATION_NAME_ID) ON DELETE CASCADE,
        RETAILER_LICENSE_NUMBER_NAME VARCHAR(100),
        SOURCE_SYSTEM VARCHAR(30),
        SOURCE_ENTITY VARCHAR(30),
        INSERT_DT DATE,
        UPDATE_DT DATE
    );

    -- Statuses
    CREATE TABLE IF NOT EXISTS bl_3nf.ce_statuses (
        STATUS_ID BIGINT PRIMARY KEY,
        STATUS_SRC_ID VARCHAR(255) UNIQUE,
        STATUS_NAME VARCHAR(100),
        SOURCE_SYSTEM VARCHAR(30),
        SOURCE_ENTITY VARCHAR(30),
        INSERT_DT DATE,
        UPDATE_DT DATE
    );

    -- Departments
    CREATE TABLE IF NOT EXISTS bl_3nf.ce_departments (
        DEPARTMENT_ID BIGINT PRIMARY KEY,
        DEPARTMENT_SRC_ID VARCHAR(255) UNIQUE,
        DEPARTMENT_NAME VARCHAR(100),
        SOURCE_SYSTEM VARCHAR(30),
        SOURCE_ENTITY VARCHAR(30),
        INSERT_DT DATE,
        UPDATE_DT DATE
    );

    -- Employees
    CREATE TABLE IF NOT EXISTS bl_3nf.ce_employees (
        EMPLOYEE_ID BIGINT PRIMARY KEY,
        EMPLOYEE_SRC_ID VARCHAR(255) UNIQUE,
        EMPLOYEE_DEPARTMENT_ID BIGINT REFERENCES bl_3nf.ce_departments(DEPARTMENT_ID) ON DELETE CASCADE,
        EMPLOYEE_STATUS_ID BIGINT REFERENCES bl_3nf.ce_statuses(STATUS_ID) ON DELETE CASCADE,
        EMPLOYEE_HIRE_DT DATE,
        EMPLOYEE_NAME VARCHAR(100),
        EMPLOYEE_EMAIL VARCHAR(100),
        EMPLOYEE_PHONE VARCHAR(50),
        EMPLOYEE_SALARY FLOAT,
        SOURCE_SYSTEM VARCHAR(30),
        SOURCE_ENTITY VARCHAR(30),
        INSERT_DT DATE,
        UPDATE_DT DATE
    );

    -- Customers SCD
    CREATE TABLE IF NOT EXISTS bl_3nf.ce_customers_scd (
        CUSTOMER_ID BIGINT,
        CUSTOMER_SRC_ID VARCHAR(255),
        CUSTOMER_ZIP_CODE_ID BIGINT REFERENCES bl_3nf.ce_zip(ZIP_ID) ON DELETE CASCADE,
        CUSTOMER_REGISTRATION_DT DATE,
        CUSTOMER_NAME VARCHAR(100),
        CUSTOMER_GENDER VARCHAR(20),
        CUSTOMER_DOB DATE,
        CUSTOMER_EMAIL VARCHAR(100),
        CUSTOMER_PHONE VARCHAR(50),
        SOURCE_SYSTEM VARCHAR(30),
        SOURCE_ENTITY VARCHAR(30),
        IS_ACTIVE BOOLEAN,
        INSERT_DT DATE,
        START_DT DATE,
        END_DT DATE,
        PRIMARY KEY (CUSTOMER_ID, START_DT)
    );

    -- Sales
    CREATE TABLE IF NOT EXISTS bl_3nf.ce_sales (
        GAME_NUMBER_ID BIGINT NOT NULL REFERENCES bl_3nf.ce_game_numbers(GAME_NUMBER_ID) ON DELETE CASCADE,
        CUSTOMER_ID BIGINT NOT NULL ,
        EMPLOYEE_ID BIGINT NOT NULL REFERENCES bl_3nf.ce_employees(EMPLOYEE_ID) ON DELETE CASCADE,
        RETAILER_LICENSE_NUMBER_ID BIGINT NOT NULL REFERENCES bl_3nf.ce_retailer_license_numbers(RETAILER_LICENSE_NUMBER_ID) ON DELETE CASCADE,
        PAYMENT_ID BIGINT NOT NULL REFERENCES bl_3nf.ce_payment_methods(PAYMENT_METHOD_ID) ON DELETE CASCADE,
        EVENT_DT DATE NOT NULL,
        TICKETS_BOUGHT INT CHECK (TICKETS_BOUGHT >= 0),
        PAYOUT FLOAT CHECK (PAYOUT >= 0),
        SALES FLOAT CHECK (SALES >= 0),
        TICKET_PRICE FLOAT CHECK (TICKET_PRICE >= 0),
        INSERT_DT DATE NOT NULL,
        UPDATE_DT DATE,
        CONSTRAINT pk_ce_sales PRIMARY KEY (
            GAME_NUMBER_ID,
            CUSTOMER_ID,
            EMPLOYEE_ID,
            RETAILER_LICENSE_NUMBER_ID,
            PAYMENT_ID,
            EVENT_DT
        )
    );

END;
$$;



CREATE OR REPLACE PROCEDURE bl_cl.create_bl_3nf_default_records()
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO bl_3nf.ce_game_types VALUES (-1, 'n. a.','n. a.', 'MANUAL', 'MANUAL', DATE '1900-01-01', DATE '1900-01-01') on conflict do nothing;
    INSERT INTO bl_3nf.ce_game_categories VALUES (-1, 'n. a.', -1,'n. a.', -1, -1, 'MANUAL', 'MANUAL', DATE '1900-01-01', DATE '1900-01-01') on conflict do nothing;
    INSERT INTO bl_3nf.ce_game_numbers VALUES (-1, 'n. a.', -1, DATE '1900-01-01','n. a.', 'n. a.', -1, -1, -1, -1, 'MANUAL', 'MANUAL', DATE '1900-01-01', DATE '1900-01-01') on conflict do nothing;
    INSERT INTO bl_3nf.ce_payment_methods VALUES (-1, 'n. a.', 'n. a.', 'MANUAL', 'MANUAL', DATE '1900-01-01', DATE '1900-01-01') on conflict do nothing;
    INSERT INTO bl_3nf.ce_states VALUES (-1, 'n. a.','n. a.', 'MANUAL', 'MANUAL', DATE '1900-01-01', DATE '1900-01-01') on conflict do nothing;
    INSERT INTO bl_3nf.ce_cities VALUES (-1, 'n. a.', -1,'n. a.', 'MANUAL', 'MANUAL', DATE '1900-01-01', DATE '1900-01-01') on conflict do nothing;
    INSERT INTO bl_3nf.ce_zip VALUES (-1, 'n. a.', -1,'n. a.', 'MANUAL', 'MANUAL', DATE '1900-01-01', DATE '1900-01-01') on conflict do nothing;
    INSERT INTO bl_3nf.ce_location_names VALUES (-1, 'n. a.', -1,'n. a.', 'MANUAL', 'MANUAL', DATE '1900-01-01', DATE '1900-01-01') on conflict do nothing;
    INSERT INTO bl_3nf.ce_retailer_license_numbers VALUES (-1, 'n. a.', -1,'n. a.', 'MANUAL', 'MANUAL', DATE '1900-01-01', DATE '1900-01-01') on conflict do nothing;
    INSERT INTO bl_3nf.ce_statuses VALUES (-1, 'n. a.','n. a.', 'MANUAL', 'MANUAL', DATE '1900-01-01', DATE '1900-01-01') on conflict do nothing;
    INSERT INTO bl_3nf.ce_departments VALUES (-1, 'n. a.','n. a.', 'MANUAL', 'MANUAL', DATE '1900-01-01', DATE '1900-01-01') on conflict do nothing;
    INSERT INTO bl_3nf.ce_employees VALUES (-1, 'n. a.', -1, -1, DATE '1900-01-01', 'n. a.', 'n. a.', 'n. a.', -1, 'MANUAL', 'MANUAL', DATE '1900-01-01', DATE '1900-01-01') on conflict do nothing;
    INSERT INTO bl_3nf.ce_customers_scd VALUES (-1, 'n. a.', -1, DATE '1900-01-01', 'n. a.', 'n. a.', DATE '1900-01-01', 'n. a.', 'n. a.', 'MANUAL', 'MANUAL', TRUE, DATE '1900-01-01', DATE '1900-01-01', DATE '9999-12-31') on conflict do nothing;
END;
$$;


CREATE OR REPLACE PROCEDURE bl_cl.create_indexes_3nf()
LANGUAGE plpgsql
AS $$
BEGIN
    -- Indexes on GREATEST of dates
    EXECUTE 'CREATE INDEX idx_ce_sales_greatest_dt ON bl_3nf.ce_sales (GREATEST(insert_dt, update_dt))';
    EXECUTE 'CREATE INDEX idx_ce_customers_scd_greatest_dt ON bl_3nf.ce_customers_scd (GREATEST(start_dt, insert_dt))';
    EXECUTE 'CREATE INDEX idx_ce_employees_greatest_dt ON bl_3nf.ce_employees (GREATEST(insert_dt, update_dt))';
    EXECUTE 'CREATE INDEX idx_ce_departments_greatest_dt ON bl_3nf.ce_departments (GREATEST(insert_dt, update_dt))';
    EXECUTE 'CREATE INDEX idx_ce_statuses_greatest_dt ON bl_3nf.ce_statuses (GREATEST(insert_dt, update_dt))';
    EXECUTE 'CREATE INDEX idx_ce_retailer_license_numbers_greatest_dt ON bl_3nf.ce_retailer_license_numbers (GREATEST(insert_dt, update_dt))';
    EXECUTE 'CREATE INDEX idx_ce_location_names_greatest_dt ON bl_3nf.ce_location_names (GREATEST(insert_dt, update_dt))';
    EXECUTE 'CREATE INDEX idx_ce_zip_greatest_dt ON bl_3nf.ce_zip (GREATEST(insert_dt, update_dt))';
    EXECUTE 'CREATE INDEX idx_ce_cities_greatest_dt ON bl_3nf.ce_cities (GREATEST(insert_dt, update_dt))';
    EXECUTE 'CREATE INDEX idx_ce_states_greatest_dt ON bl_3nf.ce_states (GREATEST(insert_dt, update_dt))';
    EXECUTE 'CREATE INDEX idx_ce_payment_methods_greatest_dt ON bl_3nf.ce_payment_methods (GREATEST(insert_dt, update_dt))';
    EXECUTE 'CREATE INDEX idx_ce_game_numbers_greatest_dt ON bl_3nf.ce_game_numbers (GREATEST(insert_dt, update_dt))';
    EXECUTE 'CREATE INDEX idx_ce_game_categories_greatest_dt ON bl_3nf.ce_game_categories (GREATEST(insert_dt, update_dt))';
    EXECUTE 'CREATE INDEX idx_ce_game_types_greatest_dt ON bl_3nf.ce_game_types (GREATEST(insert_dt, update_dt))';

    -- Indexes on _id columns (not _src_id)
    EXECUTE 'CREATE INDEX idx_ce_customers_scd_id ON bl_3nf.ce_customers_scd (customer_id)';
    EXECUTE 'CREATE INDEX idx_ce_employees_id ON bl_3nf.ce_employees (employee_id)';
    EXECUTE 'CREATE INDEX idx_ce_departments_id ON bl_3nf.ce_departments (department_id)';
    EXECUTE 'CREATE INDEX idx_ce_statuses_id ON bl_3nf.ce_statuses (status_id)';
    EXECUTE 'CREATE INDEX idx_ce_retailer_license_numbers_id ON bl_3nf.ce_retailer_license_numbers (retailer_license_number_id)';
    EXECUTE 'CREATE INDEX idx_ce_location_names_id ON bl_3nf.ce_location_names (location_name_id)';
    EXECUTE 'CREATE INDEX idx_ce_zip_id ON bl_3nf.ce_zip (zip_id)';
    EXECUTE 'CREATE INDEX idx_ce_cities_id ON bl_3nf.ce_cities (city_id)';
    EXECUTE 'CREATE INDEX idx_ce_states_id ON bl_3nf.ce_states (state_id)';
    EXECUTE 'CREATE INDEX idx_ce_payment_methods_id ON bl_3nf.ce_payment_methods (payment_method_id)';
    EXECUTE 'CREATE INDEX idx_ce_game_numbers_id ON bl_3nf.ce_game_numbers (game_number_id)';
    EXECUTE 'CREATE INDEX idx_ce_game_categories_id ON bl_3nf.ce_game_categories (game_category_id)';
    EXECUTE 'CREATE INDEX idx_ce_game_types_id ON bl_3nf.ce_game_types (game_type_id)';
END;
$$;
CREATE OR REPLACE PROCEDURE bl_cl.ensure_customer_scd_type_exists()
LANGUAGE plpgsql
AS $$
DECLARE
    v_schema TEXT := 'bl_cl';
    v_type_name TEXT := 'customer_scd_type';
    v_full_type TEXT := format('%I.%I', v_schema, v_type_name);
BEGIN
    -- Check if the type already exists
    IF NOT EXISTS (
        SELECT 1
        FROM pg_type t
        JOIN pg_namespace n ON n.oid = t.typnamespace
        WHERE t.typname = v_type_name
          AND n.nspname = v_schema
    ) THEN
        EXECUTE format('
            CREATE TYPE %s AS (
                customer_src_id VARCHAR(255),
                customer_name VARCHAR(100),
                customer_registration_dt DATE,
                zip_id BIGINT,
                zip_name VARCHAR(100),
                city_id BIGINT,
                city_name VARCHAR(100),
                state_id BIGINT,
                state_name VARCHAR(100),
                customer_gender VARCHAR(20),
                customer_dob DATE,
                customer_email VARCHAR(100),
                customer_phone VARCHAR(50),
                insert_dt DATE,
                start_dt DATE,
                end_dt DATE,
                is_active BOOLEAN
            )
        ', v_full_type);
    END IF;
END;
$$;



CREATE OR REPLACE PROCEDURE bl_cl.create_bl_3nf_all_objects()
LANGUAGE plpgsql
AS $$
BEGIN
    CALL bl_cl.create_bl_3nf_sequences();
    CALL bl_cl.create_bl_3nf_objects();
    CALL bl_cl.create_bl_3nf_default_records();
    CALL bl_cl.create_indexes_3nf();
    CALL bl_cl.ensure_customer_scd_type_exists();
END;
$$;




call bl_cl.create_bl_3nf_all_objects();




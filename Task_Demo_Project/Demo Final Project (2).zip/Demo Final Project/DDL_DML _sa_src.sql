CREATE EXTENSION IF NOT EXISTS file_fdw;

CREATE SCHEMA IF NOT EXISTS sa_final_draw;
CREATE SCHEMA IF NOT EXISTS sa_final_scratch;


CREATE SCHEMA IF NOT EXISTS bl_3nf;
CREATE SCHEMA IF NOT EXISTS bl_cl;
CREATE SCHEMA IF NOT EXISTS bl_dm;


---add the 90 % of the data----
CREATE OR REPLACE PROCEDURE bl_cl.setup_and_load(pct FLOAT)
LANGUAGE plpgsql
AS $$
BEGIN
    -- 1. Create server if not exists
    PERFORM 1 FROM pg_foreign_server WHERE srvname = 'file_server';
    IF NOT FOUND THEN
        EXECUTE 'CREATE SERVER file_server FOREIGN DATA WRAPPER file_fdw;';
    END IF;

    -- 2. Create foreign tables if not exists
    PERFORM 1 FROM information_schema.tables 
    WHERE table_schema = 'sa_final_scratch' AND table_name = 'ext_final_scratch';
    IF NOT FOUND THEN
        EXECUTE $ft$
            CREATE FOREIGN TABLE if not exists sa_final_scratch.ext_final_scratch (
                transaction_dt VARCHAR(255),
                retailer_license_number VARCHAR(255),
                customer_id VARCHAR(255),
                employee_id VARCHAR(255),
                game_number VARCHAR(255),
                tickets_bought VARCHAR(255),
                payment_method_id VARCHAR(255),
                sales VARCHAR(255),
                payout VARCHAR(255),
                customer_name VARCHAR(255),
                customer_gender VARCHAR(255),
                customer_dob VARCHAR(255),
                employee_name VARCHAR(255),
                employee_department VARCHAR(255),
                employee_status VARCHAR(255),
                retailer_location_name VARCHAR(255),
                retailer_location_zip_code VARCHAR(255),
                retailer_location_city VARCHAR(255),
                ticket_price VARCHAR(255),
                game_category VARCHAR(255),
                game_type VARCHAR(255),
                average_odds VARCHAR(255),
                average_odds_prob VARCHAR(255),
                top_prize VARCHAR(255),
                mid_prize VARCHAR(255),
                small_prize VARCHAR(255),
                payment_method_name VARCHAR(255)
            )
            SERVER file_server
            OPTIONS (
                filename 'C:\\csv\\Final_Scratch_with_dates.csv',
                format 'csv',
                header 'true'
            );
        $ft$;
    END IF;

    PERFORM 1 FROM information_schema.tables 
    WHERE table_schema = 'sa_final_draw' AND table_name = 'ext_final_draw';
    IF NOT FOUND THEN
        EXECUTE $ft$
            CREATE FOREIGN TABLE if not exists sa_final_draw.ext_final_draw (
                transaction_dt VARCHAR(255),
                retailer_license_number VARCHAR(255),
                customer_id VARCHAR(255),
                employee_id VARCHAR(255),
                game_number VARCHAR(255),
                payment_method_id VARCHAR(255),
                sales VARCHAR(255),
                tickets_bought VARCHAR(255),
                payout VARCHAR(255),
                customer_email VARCHAR(255),
                customer_phone VARCHAR(255),
                customer_registration_dt VARCHAR(255),
                customer_state VARCHAR(255),
                customer_city VARCHAR(255),
                customer_zip_code VARCHAR(255),
                employee_email VARCHAR(255),
                employee_phone VARCHAR(255),
                employee_hire_dt VARCHAR(255),
                employee_salary VARCHAR(255),
                retailer_location_name VARCHAR(255),
                retailer_location_zip_code VARCHAR(255),
                retailer_location_state VARCHAR(255),
                game_category VARCHAR(255),
                game_type VARCHAR(255),
                ticket_price VARCHAR(255),
                winning_chance VARCHAR(255),
                winning_jackpot VARCHAR(255),
                draw_dt VARCHAR(255),
                payment_method_name VARCHAR(255)
            )
            SERVER file_server
            OPTIONS (
                filename 'C:\\csv\\Final_Draw_with_dates.csv',
                format 'csv',
                header 'true'
            );
        $ft$;
    END IF;

    -- 3. Create local tables if not exists
    PERFORM 1 FROM information_schema.tables 
    WHERE table_schema = 'sa_final_scratch' AND table_name = 'src_final_scratch';
    IF NOT FOUND THEN
        EXECUTE $lt$
            CREATE TABLE if not exists sa_final_scratch.src_final_scratch (
                transaction_dt VARCHAR(255),
                retailer_license_number VARCHAR(255),
                customer_id VARCHAR(255),
                employee_id VARCHAR(255),
                game_number VARCHAR(255),
                tickets_bought VARCHAR(255),
                payment_method_id VARCHAR(255),
                sales VARCHAR(255),
                payout VARCHAR(255),
                customer_name VARCHAR(255),
                customer_gender VARCHAR(255),
                customer_dob VARCHAR(255),
                employee_name VARCHAR(255),
                employee_department VARCHAR(255),
                employee_status VARCHAR(255),
                retailer_location_name VARCHAR(255),
                retailer_location_zip_code VARCHAR(255),
                retailer_location_city VARCHAR(255),
                ticket_price VARCHAR(255),
                game_category VARCHAR(255),
                game_type VARCHAR(255),
                average_odds VARCHAR(255),
                average_odds_prob VARCHAR(255),
                top_prize VARCHAR(255),
                mid_prize VARCHAR(255),
                small_prize VARCHAR(255),
                payment_method_name VARCHAR(255)
            );
        $lt$;
    END IF;

    PERFORM 1 FROM information_schema.tables 
    WHERE table_schema = 'sa_final_draw' AND table_name = 'src_final_draw';
    IF NOT FOUND THEN
        EXECUTE $lt$
            CREATE TABLE if not exists sa_final_draw.src_final_draw (
                transaction_dt VARCHAR(255),
                retailer_license_number VARCHAR(255),
                customer_id VARCHAR(255),
                employee_id VARCHAR(255),
                game_number VARCHAR(255),
                payment_method_id VARCHAR(255),
                sales VARCHAR(255),
                tickets_bought VARCHAR(255),
                payout VARCHAR(255),
                customer_email VARCHAR(255),
                customer_phone VARCHAR(255),
                customer_registration_dt VARCHAR(255),
                customer_state VARCHAR(255),
                customer_city VARCHAR(255),
                customer_zip_code VARCHAR(255),
                employee_email VARCHAR(255),
                employee_phone VARCHAR(255),
                employee_hire_dt VARCHAR(255),
                employee_salary VARCHAR(255),
                retailer_location_name VARCHAR(255),
                retailer_location_zip_code VARCHAR(255),
                retailer_location_state VARCHAR(255),
                game_category VARCHAR(255),
                game_type VARCHAR(255),
                ticket_price VARCHAR(255),
                winning_chance VARCHAR(255),
                winning_jackpot VARCHAR(255),
                draw_dt VARCHAR(255),
                payment_method_name VARCHAR(255)
            );
        $lt$;
    END IF;

    -- 4. Add unique constraints if not exists
    PERFORM 1 FROM pg_constraint WHERE conname = 'src_final_scratch_unique';
    IF NOT FOUND THEN
        EXECUTE '
            ALTER TABLE sa_final_scratch.src_final_scratch
            ADD CONSTRAINT src_final_scratch_unique UNIQUE (
                transaction_dt,
                retailer_license_number,
                customer_id,
                employee_id,
                game_number,
                payment_method_id
            );';
    END IF;

    PERFORM 1 FROM pg_constraint WHERE conname = 'src_final_draw_unique';
    IF NOT FOUND THEN
        EXECUTE '
            ALTER TABLE sa_final_draw.src_final_draw
            ADD CONSTRAINT src_final_draw_unique UNIQUE (
                transaction_dt,
                retailer_license_number,
                customer_id,
                employee_id,
                game_number,
                payment_method_id
            );';
    END IF;

    -- 5. Validate pct
    IF pct <= 0 OR pct > 1 THEN
        RAISE EXCEPTION 'Percentage must be between 0 and 1 (exclusive)';
    END IF;

    -- 6. Calculate total rows from external tables
    DECLARE
        total_combined_rows INT;
        cutoff_combined_count INT;
        cutoff_date DATE;
    BEGIN
        SELECT
            (SELECT COUNT(*) FROM sa_final_draw.ext_final_draw) +
            (SELECT COUNT(*) FROM sa_final_scratch.ext_final_scratch)
        INTO total_combined_rows;

        IF total_combined_rows = 0 THEN
            RAISE EXCEPTION 'No rows available in external sources.';
        END IF;

        cutoff_combined_count := FLOOR(total_combined_rows * pct);

        WITH all_dates AS (
            SELECT transaction_dt::date AS dt FROM sa_final_draw.ext_final_draw
            UNION ALL
            SELECT transaction_dt::date AS dt FROM sa_final_scratch.ext_final_scratch
        ),
        date_counts AS (
            SELECT dt, COUNT(*) AS cnt FROM all_dates GROUP BY dt ORDER BY dt
        ),
        cumulative AS (
            SELECT dt, SUM(cnt) OVER (ORDER BY dt ROWS UNBOUNDED PRECEDING) AS running_total
            FROM date_counts
        )
        SELECT dt INTO cutoff_date
        FROM cumulative
        WHERE running_total <= cutoff_combined_count
        ORDER BY dt DESC
        LIMIT 1;

        IF cutoff_date IS NULL THEN
            RAISE EXCEPTION 'Could not determine a cutoff date.';
        END IF;

        -- 7. Insert data into local draw table up to cutoff_date
        EXECUTE format('
            INSERT INTO sa_final_draw.src_final_draw (
                transaction_dt, retailer_license_number, customer_id, employee_id, game_number, payment_method_id,
                sales, tickets_bought, payout, customer_email, customer_phone, customer_registration_dt,
                customer_state, customer_city, customer_zip_code, employee_email, employee_phone,
                employee_hire_dt, employee_salary, retailer_location_name, retailer_location_zip_code,
                retailer_location_state, game_category, game_type, ticket_price, winning_chance,
                winning_jackpot, draw_dt, payment_method_name
            )
            SELECT
                transaction_dt, retailer_license_number, customer_id, employee_id, game_number, payment_method_id,
                sales, tickets_bought, payout, customer_email, customer_phone, customer_registration_dt,
                customer_state, customer_city, customer_zip_code, employee_email, employee_phone,
                employee_hire_dt, employee_salary, retailer_location_name, retailer_location_zip_code,
                retailer_location_state, game_category, game_type, ticket_price, winning_chance,
                winning_jackpot, draw_dt, payment_method_name
            FROM sa_final_draw.ext_final_draw
            WHERE transaction_dt::date <= %L
            ON CONFLICT (transaction_dt, retailer_license_number, customer_id, employee_id, game_number, payment_method_id)
            DO NOTHING;
        ', cutoff_date);

        -- 8. Insert data into local scratch table up to cutoff_date
        EXECUTE format('
            INSERT INTO sa_final_scratch.src_final_scratch (
                transaction_dt, retailer_license_number, customer_id, employee_id, game_number, tickets_bought,
                payment_method_id, sales, payout, customer_name, customer_gender, customer_dob,
                employee_name, employee_department, employee_status, retailer_location_name,
                retailer_location_zip_code, retailer_location_city, ticket_price, game_category,
                game_type, average_odds, average_odds_prob, top_prize, mid_prize, small_prize,
                payment_method_name
            )
            SELECT
                transaction_dt, retailer_license_number, customer_id, employee_id, game_number, tickets_bought,
                payment_method_id, sales, payout, customer_name, customer_gender, customer_dob,
                employee_name, employee_department, employee_status, retailer_location_name,
                retailer_location_zip_code, retailer_location_city, ticket_price, game_category,
                game_type, average_odds, average_odds_prob, top_prize, mid_prize, small_prize,
                payment_method_name
            FROM sa_final_scratch.ext_final_scratch
            WHERE transaction_dt::date <= %L
            ON CONFLICT (transaction_dt, retailer_license_number, customer_id, employee_id, game_number, payment_method_id)
            DO NOTHING;
        ', cutoff_date);

        RAISE NOTICE 'Data loaded up to date: % (%.2f%% of total rows)', cutoff_date, pct * 100;
    END;

END;
$$;


call  bl_cl.setup_and_load(0.9);

select count(*) from sa_final_scratch.src_final_scratch;
select max(transaction_dt::date) from sa_final_scratch.src_final_scratch;

select count(*) from sa_final_draw.src_final_draw;
select max(transaction_dt::date) from sa_final_draw.src_final_draw;




---loading remaining data---
CREATE OR REPLACE PROCEDURE bl_cl.load_remaining_from_ext_tables()
LANGUAGE plpgsql
AS $$
BEGIN
    -- Load remaining data from ext_final_draw into src_final_draw
    INSERT INTO sa_final_draw.src_final_draw (
        transaction_dt,
        retailer_license_number,
        customer_id,
        employee_id,
        game_number,
        payment_method_id,
        sales,
        tickets_bought,
        payout,
        customer_email,
        customer_phone,
        customer_registration_dt,
        customer_state,
        customer_city,
        customer_zip_code,
        employee_email,
        employee_phone,
        employee_hire_dt,
        employee_salary,
        retailer_location_name,
        retailer_location_zip_code,
        retailer_location_state,
        game_category,
        game_type,
        ticket_price,
        winning_chance,
        winning_jackpot,
        draw_dt,
        payment_method_name
    )
    SELECT
        transaction_dt,
        retailer_license_number,
        customer_id,
        employee_id,
        game_number,
        payment_method_id,
        sales,
        tickets_bought,
        payout,
        customer_email,
        customer_phone,
        customer_registration_dt,
        customer_state,
        customer_city,
        customer_zip_code,
        employee_email,
        employee_phone,
        employee_hire_dt,
        employee_salary,
        retailer_location_name,
        retailer_location_zip_code,
        retailer_location_state,
        game_category,
        game_type,
        ticket_price,
        winning_chance,
        winning_jackpot,
        draw_dt,
        payment_method_name
    FROM sa_final_draw.ext_final_draw
    ON CONFLICT (transaction_dt, retailer_license_number, customer_id, employee_id, game_number, payment_method_id) DO NOTHING;

    -- Load remaining data from ext_final_scratch into src_final_scratch
    INSERT INTO sa_final_scratch.src_final_scratch (
        transaction_dt,
        retailer_license_number,
        customer_id,
        employee_id,
        game_number,
        tickets_bought,
        payment_method_id,
        sales,
        payout,
        customer_name,
        customer_gender,
        customer_dob,
        employee_name,
        employee_department,
        employee_status,
        retailer_location_name,
        retailer_location_zip_code,
        retailer_location_city,
        ticket_price,
        game_category,
        game_type,
        average_odds,
        average_odds_prob,
        top_prize,
        mid_prize,
        small_prize,
        payment_method_name
    )
    SELECT
        transaction_dt,
        retailer_license_number,
        customer_id,
        employee_id,
        game_number,
        tickets_bought,
        payment_method_id,
        sales,
        payout,
        customer_name,
        customer_gender,
        customer_dob,
        employee_name,
        employee_department,
        employee_status,
        retailer_location_name,
        retailer_location_zip_code,
        retailer_location_city,
        ticket_price,
        game_category,
        game_type,
        average_odds,
        average_odds_prob,
        top_prize,
        mid_prize,
        small_prize,
        payment_method_name
    FROM sa_final_scratch.ext_final_scratch
    ON CONFLICT (
        transaction_dt,
        retailer_license_number,
        customer_id,
        employee_id,
        game_number,
        payment_method_id
    ) DO NOTHING;

    RAISE NOTICE 'Remaining records loaded successfully from both external sources.';
END;
$$;

CALL bl_cl.load_remaining_from_ext_tables();

select count(*) from sa_final_scratch.src_final_scratch;
select max(transaction_dt::date) from sa_final_scratch.src_final_scratch;

select count(*) from sa_final_draw.src_final_draw;
select max(transaction_dt::date) from sa_final_draw.src_final_draw;

--load data for the scd 2---
CREATE OR REPLACE PROCEDURE bl_cl.load_and_insert_all_data()
LANGUAGE plpgsql
AS $$
BEGIN
  

    EXECUTE '
    CREATE FOREIGN TABLE if not exists sa_final_scratch.ext_scratch (
        transaction_dt VARCHAR(255),
        retailer_license_number VARCHAR(255),
        customer_id VARCHAR(255),
        employee_id VARCHAR(255),
        game_number VARCHAR(255),
        tickets_bought VARCHAR(255),
        payment_method_id VARCHAR(255),
        sales VARCHAR(255),
        payout VARCHAR(255),
        customer_name VARCHAR(255),
        customer_gender VARCHAR(255),
        customer_dob VARCHAR(255),
        employee_name VARCHAR(255),
        employee_department VARCHAR(255),
        employee_status VARCHAR(255),
        retailer_location_name VARCHAR(255),
        retailer_location_zip_code VARCHAR(255),
        retailer_location_city VARCHAR(255),
        ticket_price VARCHAR(255),
        game_category VARCHAR(255),
        game_type VARCHAR(255),
        average_odds VARCHAR(255),
        average_odds_prob VARCHAR(255),
        top_prize VARCHAR(255),
        mid_prize VARCHAR(255),
        small_prize VARCHAR(255),
        payment_method_name VARCHAR(255)
    )
    SERVER file_server
    OPTIONS (
        filename ''C:\\csv\\scratch.csv'',
        format ''csv'',
        header ''true''
    )';

    RAISE NOTICE 'Foreign table sa_final_scratch.ext_scratch created.';

    -- Count before insert for scratch
    RAISE NOTICE 'Count before insert in sa_final_scratch.src_final_scratch: %', 
        (SELECT COUNT(*) FROM sa_final_scratch.src_final_scratch);

    -- Insert from ext_scratch to src_final_scratch with conflict skip
    INSERT INTO sa_final_scratch.src_final_scratch (
        transaction_dt,
        retailer_license_number,
        customer_id,
        employee_id,
        game_number,
        tickets_bought,
        payment_method_id,
        sales,
        payout,
        customer_name,
        customer_gender,
        customer_dob,
        employee_name,
        employee_department,
        employee_status,
        retailer_location_name,
        retailer_location_zip_code,
        retailer_location_city,
        ticket_price,
        game_category,
        game_type,
        average_odds,
        average_odds_prob,
        top_prize,
        mid_prize,
        small_prize,
        payment_method_name
    )
    SELECT
        transaction_dt,
        retailer_license_number,
        customer_id,
        employee_id,
        game_number,
        tickets_bought,
        payment_method_id,
        sales,
        payout,
        customer_name,
        customer_gender,
        customer_dob,
        employee_name,
        employee_department,
        employee_status,
        retailer_location_name,
        retailer_location_zip_code,
        retailer_location_city,
        ticket_price,
        game_category,
        game_type,
        average_odds,
        average_odds_prob,
        top_prize,
        mid_prize,
        small_prize,
        payment_method_name
    FROM sa_final_scratch.ext_scratch
    WHERE
        transaction_dt IS NOT NULL AND
        retailer_license_number IS NOT NULL AND
        customer_id IS NOT NULL AND
        employee_id IS NOT NULL AND
        game_number IS NOT NULL AND
        tickets_bought IS NOT NULL AND
        payment_method_id IS NOT NULL AND
        sales IS NOT NULL AND
        payout IS NOT NULL AND
        customer_name IS NOT NULL AND
        customer_gender IS NOT NULL AND
        customer_dob IS NOT NULL AND
        employee_name IS NOT NULL AND
        employee_department IS NOT NULL AND
        employee_status IS NOT NULL AND
        retailer_location_name IS NOT NULL AND
        retailer_location_zip_code IS NOT NULL AND
        retailer_location_city IS NOT NULL AND
        ticket_price IS NOT NULL AND
        game_category IS NOT NULL AND
        game_type IS NOT NULL AND
        average_odds IS NOT NULL AND
        average_odds_prob IS NOT NULL AND
        top_prize IS NOT NULL AND
        mid_prize IS NOT NULL AND
        small_prize IS NOT NULL AND
        payment_method_name IS NOT NULL
    ON CONFLICT (
        transaction_dt,
        retailer_license_number,
        customer_id,
        employee_id,
        game_number,
        payment_method_id
    ) DO NOTHING;

    RAISE NOTICE 'Inserted remaining rows into sa_final_scratch.src_final_scratch.';

    -- Count after insert for scratch
    RAISE NOTICE 'Count after insert in sa_final_scratch.src_final_scratch: %', 
        (SELECT COUNT(*) FROM sa_final_scratch.src_final_scratch);


    EXECUTE '
    CREATE FOREIGN TABLE if not exists sa_final_draw.ext_draw (
        transaction_dt VARCHAR(255),
        retailer_license_number VARCHAR(255),
        customer_id VARCHAR(255),
        employee_id VARCHAR(255),
        game_number VARCHAR(255),
        payment_method_id VARCHAR(255),
        sales VARCHAR(255),
        tickets_bought VARCHAR(255),
        payout VARCHAR(255),
        customer_email VARCHAR(255),
        customer_phone VARCHAR(255),
        customer_registration_dt VARCHAR(255),
        customer_state VARCHAR(255),
        customer_city VARCHAR(255),
        customer_zip_code VARCHAR(255),
        employee_email VARCHAR(255),
        employee_phone VARCHAR(255),
        employee_hire_dt VARCHAR(255),
        employee_salary VARCHAR(255),
        retailer_location_name VARCHAR(255),
        retailer_location_zip_code VARCHAR(255),
        retailer_location_state VARCHAR(255),
        game_category VARCHAR(255),
        game_type VARCHAR(255),
        ticket_price VARCHAR(255),
        winning_chance VARCHAR(255),
        winning_jackpot VARCHAR(255),
        draw_dt VARCHAR(255),
        payment_method_name VARCHAR(255)
    )
    SERVER file_server
    OPTIONS (
        filename ''C:\\csv\\draw.csv'',
        format ''csv'',
        header ''true''
    )';

    RAISE NOTICE 'Foreign table sa_final_draw.ext_draw created.';

    -- Count before insert for draw
    RAISE NOTICE 'Count before insert in sa_final_draw.src_final_draw: %', 
        (SELECT COUNT(*) FROM sa_final_draw.src_final_draw);

    -- Insert from ext_draw to src_final_draw with conflict skip
    INSERT INTO sa_final_draw.src_final_draw (
        transaction_dt,
        retailer_license_number,
        customer_id,
        employee_id,
        game_number,
        payment_method_id,
        sales,
        tickets_bought,
        payout,
        customer_email,
        customer_phone,
        customer_registration_dt,
        customer_state,
        customer_city,
        customer_zip_code,
        employee_email,
        employee_phone,
        employee_hire_dt,
        employee_salary,
        retailer_location_name,
        retailer_location_zip_code,
        retailer_location_state,
        game_category,
        game_type,
        ticket_price,
        winning_chance,
        winning_jackpot,
        draw_dt,
        payment_method_name
    )
    SELECT
        transaction_dt,
        retailer_license_number,
        customer_id,
        employee_id,
        game_number,
        payment_method_id,
        sales,
        tickets_bought,
        payout,
        customer_email,
        customer_phone,
        customer_registration_dt,
        customer_state,
        customer_city,
        customer_zip_code,
        employee_email,
        employee_phone,
        employee_hire_dt,
        employee_salary,
        retailer_location_name,
        retailer_location_zip_code,
        retailer_location_state,
        game_category,
        game_type,
        ticket_price,
        winning_chance,
        winning_jackpot,
        draw_dt,
        payment_method_name
    FROM sa_final_draw.ext_draw
    WHERE
        transaction_dt IS NOT NULL AND
        retailer_license_number IS NOT NULL AND
        customer_id IS NOT NULL AND
        employee_id IS NOT NULL AND
        game_number IS NOT NULL AND
        payment_method_id IS NOT NULL AND
        sales IS NOT NULL AND
        tickets_bought IS NOT NULL AND
        payout IS NOT NULL AND
        customer_email IS NOT NULL AND
        customer_phone IS NOT NULL AND
        customer_registration_dt IS NOT NULL AND
        customer_state IS NOT NULL AND
        customer_city IS NOT NULL AND
        customer_zip_code IS NOT NULL AND
        employee_email IS NOT NULL AND
        employee_phone IS NOT NULL AND
        employee_hire_dt IS NOT NULL AND
        employee_salary IS NOT NULL AND
        retailer_location_name IS NOT NULL AND
        retailer_location_zip_code IS NOT NULL AND
        retailer_location_state IS NOT NULL AND
        game_category IS NOT NULL AND
        game_type IS NOT NULL AND
        ticket_price IS NOT NULL AND
        winning_chance IS NOT NULL AND
        winning_jackpot IS NOT NULL AND
        draw_dt IS NOT NULL AND
        payment_method_name IS NOT NULL
    ON CONFLICT (
        transaction_dt,
        retailer_license_number,
        customer_id,
        employee_id,
        game_number,
        payment_method_id
    ) DO NOTHING;

    RAISE NOTICE 'Inserted remaining rows into sa_final_draw.src_final_draw.';

    -- Count after insert for draw
    RAISE NOTICE 'Count after insert in sa_final_draw.src_final_draw: %', 
        (SELECT COUNT(*) FROM sa_final_draw.src_final_draw);

END;
$$;




call bl_cl.load_and_insert_all_data();







































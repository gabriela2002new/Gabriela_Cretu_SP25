
CREATE OR REPLACE PROCEDURE bl_cl.create_bl_cl_objects()
LANGUAGE plpgsql
AS $$
BEGIN
    -- ======================================
-- Game Types
-- ======================================


CREATE TABLE if not exists bl_cl.mta_game_types (
    column_name            VARCHAR,
    source_column_name     VARCHAR,
    data_type              VARCHAR,
    transformation_rule    TEXT,
    is_nullable            BOOLEAN,
    notes                  TEXT
);



CREATE TABLE if not exists bl_cl.wrk_game_types (
    game_type_src_id   VARCHAR,
    game_type_name     VARCHAR,
    source_system      VARCHAR,
    source_entity      VARCHAR,
    load_dt            DATE
);

CREATE table if not exists bl_cl.lkp_game_types (
    game_type_id       INT ,
    game_type_src_id   VARCHAR,
    game_type_name     VARCHAR,
    source_system      VARCHAR,
    source_entity      VARCHAR,
    insert_dt          DATE,
    update_dt          DATE,
    CONSTRAINT uq_game_type UNIQUE (game_type_src_id, source_system, source_entity)
);

-- ======================================
-- Game Categories
-- ======================================

CREATE TABLE IF NOT EXISTS bl_cl.mta_game_categories (
    column_name            VARCHAR,
    source_column_name     VARCHAR,
    data_type              VARCHAR,
    transformation_rule    TEXT,
    is_nullable            BOOLEAN,
    notes                  TEXT
);



CREATE table if not exists bl_cl.wrk_game_categories (
    game_category_src_id VARCHAR,
    game_type_name       VARCHAR,
    winning_chance       FLOAT,
    winning_jackpot      FLOAT,
    source_system        VARCHAR,
    source_entity        VARCHAR,
    load_dt              DATE
);

CREATE TABLE IF NOT EXISTS bl_cl.lkp_game_categories (
    game_category_id      BIGINT,
    game_category_src_id  VARCHAR,
    game_category_name    VARCHAR,
    game_type_name        VARCHAR,
    winning_chance        FLOAT,
    winning_jackpot       FLOAT,
    source_system         VARCHAR,
    source_entity         VARCHAR,
    insert_dt             DATE,
    update_dt             DATE,
    CONSTRAINT uq_game_category UNIQUE (game_category_src_id, source_system, source_entity)
);


-- ======================================
-- Game Numbers
-- ======================================


CREATE table if not exists bl_cl.mta_game_numbers (
    column_name       VARCHAR(100) NOT NULL,
    source_column_name     VARCHAR(100) NOT NULL,
    data_type         VARCHAR(50) NOT NULL,
    transformation_rule    VARCHAR(255) NOT NULL,
    is_nullable          BOOLEAN NOT NULL,
    notes       VARCHAR(255) NOT NULL
);


-- Working (staging) table to hold source data before mapping
CREATE TABLE if not exists bl_cl.wrk_game_numbers (
    game_number_src_id VARCHAR(255) NOT NULL,
    game_category_name VARCHAR(255),
    draw_dt DATE,
    average_odds VARCHAR(30),
    average_odds_prob FLOAT,
    mid_tier_prize FLOAT,
    top_tier_prize FLOAT,
    small_prize FLOAT,
    source_system VARCHAR(30) NOT NULL,
    source_entity VARCHAR(30) NOT NULL,
    load_dt DATE NOT NULL
);


-- Lookup (final mapping) table with surrogate keys and unique constraint
CREATE table if not exists bl_cl.lkp_game_numbers (
    game_number_id BIGINT PRIMARY KEY,
    game_number_src_id VARCHAR(255) NOT NULL,
    game_number_name VARCHAR(255) NOT NULL,
    game_category_name VARCHAR(255),
    draw_dt DATE,
    average_odds VARCHAR(30),
    average_odds_prob FLOAT,
    mid_tier_prize FLOAT,
    top_tier_prize FLOAT,
    small_prize FLOAT,
    source_system VARCHAR(30) NOT NULL,
    source_entity VARCHAR(30) NOT NULL,
    insert_dt DATE NOT NULL,
    update_dt DATE NOT NULL,
    UNIQUE (game_number_src_id, source_system, source_entity)
);


-- ======================================
-- Payment Methods
-- ======================================


CREATE table if not exists bl_cl.mta_payment_methods (
    column_name      VARCHAR(100) NOT NULL,
    source_column_name    VARCHAR(100) NOT NULL,
    data_type        VARCHAR(50)  NOT NULL,
    transformation_rule   VARCHAR(255) NOT NULL,
    is_nullable         BOOLEAN      NOT NULL,
    notes     VARCHAR(255) NOT NULL
);


CREATE table if not exists bl_cl.wrk_payment_methods (
    payment_method_src_id   VARCHAR(255) NOT NULL,
    payment_method_name     VARCHAR(100),
    source_system           VARCHAR(30) NOT NULL,
    source_entity           VARCHAR(30) NOT NULL,
    load_dt               DATE NOT NULL
);

CREATE TABLE IF NOT EXISTS bl_cl.lkp_payment_methods (
    payment_method_id     BIGINT NOT NULL,
    payment_method_src_id VARCHAR(255) NOT NULL,
    payment_method_name   VARCHAR(100),
    source_system         VARCHAR(30) NOT NULL,
    source_entity         VARCHAR(30) NOT NULL,
    insert_dt             DATE NOT NULL,
    update_dt             DATE NOT NULL,
    CONSTRAINT unq_payment_method_triplet UNIQUE (payment_method_src_id, source_system, source_entity)
);



-- ======================================
-- States
-- ======================================


CREATE TABLE if not exists bl_cl.mta_states (
    column_name      VARCHAR(100) NOT NULL,
    source_column_name    VARCHAR(100) NOT NULL,
    data_type        VARCHAR(50)  NOT NULL,
    transformation_rule   VARCHAR(255) NOT NULL,
    is_nullable         BOOLEAN      NOT NULL,
    notes     VARCHAR(255) NOT NULL
);


CREATE table if not exists bl_cl.wrk_states (
    state_src_id   VARCHAR(255) NOT NULL,
    source_system  VARCHAR(30) NOT NULL,
    source_entity  VARCHAR(30) NOT NULL,
    load_dt      DATE NOT NULL
);

CREATE TABLE IF NOT EXISTS bl_cl.lkp_states (
    state_id        BIGINT NOT NULL,
    state_src_id    VARCHAR(255) NOT NULL,
    state_name      VARCHAR(100),
    source_system   VARCHAR(30) NOT NULL,
    source_entity   VARCHAR(30) NOT NULL,
    insert_dt       DATE NOT NULL,
    update_dt       DATE NOT NULL,
    CONSTRAINT unq_state_triplet UNIQUE (state_src_id, source_system, source_entity)
);




-- ======================================
-- Cities
-- ======================================


CREATE table if not exists bl_cl.mta_cities (
    column_name      VARCHAR(100) NOT NULL,
    source_column_name    VARCHAR(100) NOT NULL,
    data_type        VARCHAR(50)  NOT NULL,
    transformation_rule   VARCHAR(255) NOT NULL,
    is_nullable         BOOLEAN      NOT NULL,
    notes     VARCHAR(255) NOT NULL
);


CREATE table if not exists  bl_cl.wrk_cities (
    city_src_id     VARCHAR(255) NOT NULL,
    state_name      VARCHAR(100),
    source_system   VARCHAR(30) NOT NULL,
    source_entity   VARCHAR(30) NOT NULL,
    load_dt       DATE NOT NULL
);

CREATE TABLE IF NOT EXISTS bl_cl.lkp_cities (
    city_id         BIGINT NOT NULL,
    city_src_id     VARCHAR(255) NOT NULL,
    state_name      VARCHAR(100),
    city_name       VARCHAR(100),
    source_system   VARCHAR(30) NOT NULL,
    source_entity   VARCHAR(30) NOT NULL,
    insert_dt       DATE NOT NULL,
    update_dt       DATE NOT NULL,
    CONSTRAINT unq_city_triplet UNIQUE (city_src_id, source_system, source_entity)
);


-- ======================================
-- Zipcodes
-- ======================================



CREATE table if not exists  bl_cl.mta_zips (
    column_name      VARCHAR(100) NOT NULL,
    source_column_name    VARCHAR(100) NOT NULL,
    data_type        VARCHAR(50)  NOT NULL,
    transformation_rule   VARCHAR(255) NOT NULL,
    is_nullable         BOOLEAN      NOT NULL,
    notes     VARCHAR(255) NOT NULL
);



CREATE table if not exists  bl_cl.wrk_zips (
    zip_src_id     VARCHAR(20) NOT NULL,
    city_name      VARCHAR(100),
    source_system  VARCHAR(30) NOT NULL,
    source_entity  VARCHAR(30) NOT NULL,
    load_dt      DATE NOT NULL
);


CREATE TABLE IF NOT EXISTS bl_cl.lkp_zips (
    zip_id         BIGINT NOT NULL,
    zip_src_id     VARCHAR(20) NOT NULL,
    city_name      VARCHAR(100),
    zip_name       VARCHAR(20) NOT NULL,
    source_system  VARCHAR(30) NOT NULL,
    source_entity  VARCHAR(30) NOT NULL,
    insert_dt      DATE NOT NULL,
    update_dt      DATE NOT NULL,
    
    CONSTRAINT unq_zip_triplet UNIQUE (zip_src_id, source_system, source_entity)
);



-- ======================================
-- Location Names
-- ======================================


CREATE table if not exists bl_cl.mta_location_names (
    column_name      VARCHAR(100) NOT NULL,
    source_column_name    VARCHAR(100) NOT NULL,
    data_type        VARCHAR(50)  NOT NULL,
    transformation_rule   VARCHAR(255) NOT NULL,
    is_nullable         BOOLEAN      NOT NULL,
    notes     VARCHAR(255) NOT NULL
);



CREATE table if not exists bl_cl.wrk_location_names (
    location_name_src_id VARCHAR(255) NOT NULL,
    zip_name           VARCHAR(20)  NOT NULL,
    source_system        VARCHAR(30)  NOT NULL,
    source_entity        VARCHAR(30)  NOT NULL,
    load_dt            DATE         NOT NULL
);


CREATE table if not exists bl_cl.lkp_location_names (
    location_name_id      BIGINT      NOT NULL,
    location_name_src_id  VARCHAR(255) NOT NULL,
    zip_name              VARCHAR(20) NOT NULL,
    location_name         VARCHAR(255) NOT NULL,
    source_system         VARCHAR(30) NOT NULL,
    source_entity         VARCHAR(30) NOT NULL,
    insert_dt             DATE       NOT NULL,
    update_dt             DATE       NOT NULL,
    
    CONSTRAINT unq_location_name_triplet UNIQUE (location_name_src_id, source_system, source_entity)
);


-- ======================================
-- Retailers
-- ======================================


CREATE TABLE if not exists bl_cl.mta_retailers (
    column_name      VARCHAR(100) NOT NULL,
    source_column_name    VARCHAR(100) NOT NULL,
    data_type        VARCHAR(50)  NOT NULL,
    transformation_rule   VARCHAR(255) NOT NULL,
    is_nullable         BOOLEAN      NOT NULL,
    notes     VARCHAR(255) NOT NULL
);


CREATE TABLE if not exists bl_cl.wrk_retailers (
    retailer_license_number_src_id  VARCHAR(100) NOT NULL,
    location_name                   VARCHAR(255),
    source_system                   VARCHAR(30) NOT NULL,
    source_entity                   VARCHAR(30) NOT NULL,
    load_dt                       DATE NOT NULL
);



CREATE table if not exists bl_cl.lkp_retailers (
    retailer_license_number_id      BIGINT NOT NULL,
    retailer_license_number_src_id  VARCHAR(100) NOT NULL,
    location_name                   VARCHAR(255),
    retailer_license_number_name    VARCHAR(100) NOT NULL,
    source_system                   VARCHAR(30) NOT NULL,
    source_entity                   VARCHAR(30) NOT NULL,
    insert_dt                       DATE NOT NULL,
    update_dt                       DATE NOT NULL,

    CONSTRAINT unq_retailer_triplet UNIQUE (retailer_license_number_src_id, source_system, source_entity)
);



-- ======================================
-- Statuses
-- ======================================

CREATE table if not exists bl_cl.mta_statuses (
    column_name      VARCHAR(100) NOT NULL,
    source_column_name    VARCHAR(100) NOT NULL,
    data_type        VARCHAR(50)  NOT NULL,
    transformation_rule   VARCHAR(255) NOT NULL,
    is_nullable         BOOLEAN      NOT NULL,
    notes     VARCHAR(255) NOT NULL
);


CREATE table if not exists bl_cl.wrk_statuses (
    status_src_id VARCHAR(100) NOT NULL,
    source_system VARCHAR(30) NOT NULL,
    source_entity VARCHAR(30) NOT NULL,
    load_dt     DATE NOT NULL
);



CREATE TABLE IF NOT EXISTS bl_cl.lkp_statuses (
    status_id       BIGINT ,
    status_src_id   VARCHAR(100) NOT NULL,
    status_name     VARCHAR(100) NOT NULL,
    source_system   VARCHAR(30) NOT NULL,
    source_entity   VARCHAR(30) NOT NULL,
    insert_dt       DATE NOT NULL,
    update_dt       DATE NOT NULL,

    CONSTRAINT unq_status_triplet UNIQUE (status_src_id, source_system, source_entity)
);



-- ======================================
-- Departments
-- ======================================


CREATE table if not exists bl_cl.mta_departments (
    column_name      VARCHAR(100) NOT NULL,
    source_column_name    VARCHAR(100) NOT NULL,
    data_type        VARCHAR(50)  NOT NULL,
    transformation_rule   VARCHAR(255) NOT NULL,
    is_nullable         BOOLEAN      NOT NULL,
    notes     VARCHAR(255) NOT NULL
);




CREATE TABLE if not exists bl_cl.wrk_departments (
    department_src_id VARCHAR(100) NOT NULL,
    source_system VARCHAR(30) NOT NULL,
    source_entity VARCHAR(30) NOT NULL,
    load_dt DATE NOT NULL
);


CREATE TABLE IF NOT EXISTS bl_cl.lkp_departments (
    department_id BIGINT ,
    department_src_id VARCHAR(100) NOT NULL,
    department_name VARCHAR(100) NOT NULL,
    source_system VARCHAR(30) NOT NULL,
    source_entity VARCHAR(30) NOT NULL,
    insert_dt DATE NOT NULL,
    update_dt DATE NOT NULL,

    CONSTRAINT unq_department_triplet UNIQUE (department_src_id, source_system, source_entity)
);



-- ======================================
-- Employees
-- ======================================

CREATE TABLE IF NOT EXISTS bl_cl.mta_employees (
    column_name      VARCHAR(100) NOT NULL,
    source_column_name    VARCHAR(100) NOT NULL,
    data_type        VARCHAR(50)  NOT NULL,
    transformation_rule   VARCHAR(255) NOT NULL,
    is_nullable         BOOLEAN      NOT NULL,
    notes     VARCHAR(255) NOT NULL
);



CREATE TABLE if not exists bl_cl.wrk_employees (
    employee_src_id VARCHAR(255) NOT NULL,
    employee_name VARCHAR(100),
    employee_department_name VARCHAR(100),
    employee_status_name VARCHAR(100),
    employee_email VARCHAR(255),
    employee_phone VARCHAR(50),
    employee_hire_dt DATE,
    employee_salary FLOAT,
    source_system VARCHAR(50) NOT NULL,
    source_entity VARCHAR(50) NOT NULL,
    load_dt DATE NOT NULL
);

CREATE TABLE IF NOT EXISTS bl_cl.lkp_employees (
    employee_id BIGINT,
    employee_src_id VARCHAR(255) NOT NULL,
    employee_name VARCHAR(100) NOT NULL,
    employee_department_name VARCHAR(100) NOT NULL,
    employee_status_name VARCHAR(100) NOT NULL,
    employee_email VARCHAR(255) NOT NULL,
    employee_phone VARCHAR(50) NOT NULL,
    employee_hire_dt DATE NOT NULL,
    employee_salary FLOAT NOT NULL,
    source_system VARCHAR(50) NOT NULL,
    source_entity VARCHAR(50) NOT NULL,
    insert_dt DATE NOT NULL,
    update_dt DATE NOT NULL,

    CONSTRAINT unq_employee_triplet UNIQUE (employee_src_id, source_system, source_entity)
);


-- ======================================
-- Customers
-- ======================================

CREATE TABLE IF NOT EXISTS bl_cl.mta_customers (
    column_name      VARCHAR(100) NOT NULL,
    source_column_name    VARCHAR(100) NOT NULL,
    data_type        VARCHAR(50)  NOT NULL,
    transformation_rule   VARCHAR(255) NOT NULL,
    is_nullable         BOOLEAN      NOT NULL,
    notes     VARCHAR(255) NOT null
   );


CREATE TABLE IF NOT EXISTS bl_cl.wrk_customers (
    customer_src_id           VARCHAR(100) NOT NULL,
    zip_name                  VARCHAR(20),
    customer_registration_dt  DATE,
    customer_name             VARCHAR(255),
    customer_gender           VARCHAR(10),
    customer_dob              DATE,
    customer_email            VARCHAR(255),
    customer_phone            VARCHAR(50),
    source_system             VARCHAR(100) NOT NULL,
    source_entity             VARCHAR(100) NOT NULL,
    load_dt                   DATE DEFAULT CURRENT_DATE
);

CREATE TABLE IF NOT EXISTS bl_cl.lkp_customers (
    customer_id              BIGINT ,
    customer_src_id          VARCHAR(100) NOT NULL,
    zip_name                 VARCHAR(20) DEFAULT 'n. a.',
    customer_registration_dt DATE NOT NULL DEFAULT '1900-01-01',
    customer_name            VARCHAR(255) DEFAULT 'n. a.',
    customer_gender          VARCHAR(10) DEFAULT 'n. a.',
    customer_dob             DATE NOT NULL DEFAULT '1900-01-01',
    customer_email           VARCHAR(255) DEFAULT 'n. a.',
    customer_phone           VARCHAR(50) DEFAULT 'n. a.',
    source_system            VARCHAR(100) NOT NULL,
    source_entity            VARCHAR(100) NOT NULL,
    is_active                BOOLEAN NOT NULL DEFAULT TRUE,
    insert_dt                DATE NOT NULL ,
    start_dt                 DATE NOT NULL ,
    end_dt                   DATE NOT NULL ,

    CONSTRAINT uq_lkp_customers UNIQUE (
        customer_src_id, source_system, source_entity, start_dt
    )
);


   
   
   

-- ============================================
-- Sales
-- ============================================
 
CREATE TABLE IF NOT EXISTS bl_cl.mta_sales (
    column_name      VARCHAR(100) NOT NULL,
    source_column_name    VARCHAR(100) NOT NULL,
    data_type        VARCHAR(50)  NOT NULL,
    transformation_rule   VARCHAR(255) NOT NULL,
    is_nullable         BOOLEAN      NOT NULL,
    notes     VARCHAR(255) NOT NULL);


CREATE TABLE if not exists bl_cl.wrk_sales (
    game_number_src_id            VARCHAR(100),
    customer_src_id               VARCHAR(100),
    employee_src_id               VARCHAR(100),
    retailer_license_number_src_id VARCHAR(100),
    payment_method_src_id         VARCHAR(100),
    transaction_dt                DATE,
    tickets_bought                INT,
    payout                        FLOAT,
    sales                         FLOAT,
    ticket_price                  FLOAT,
    source_system                 VARCHAR(100),
    source_entity                 VARCHAR(100)
);


CREATE table if not exists bl_cl.lkp_sales (
    game_number_src_id            VARCHAR(100) NOT NULL,
    customer_src_id               VARCHAR(100) NOT NULL,
    employee_src_id               VARCHAR(100) NOT NULL,
    retailer_license_number_src_id VARCHAR(100) NOT NULL,
    payment_method_src_id         VARCHAR(100) NOT NULL,
    event_dt                      DATE NOT NULL,
    tickets_bought                INT DEFAULT -1,
    payout                        FLOAT DEFAULT -1,
    sales                         FLOAT DEFAULT -1,
    ticket_price                  FLOAT DEFAULT -1,
    source_system                 VARCHAR(100) NOT NULL,
    source_entity                 VARCHAR(100) NOT NULL,
    insert_dt                     DATE NOT NULL DEFAULT CURRENT_DATE,
    update_dt                     DATE NOT NULL DEFAULT CURRENT_DATE,
    CONSTRAINT uq_sales UNIQUE (
        game_number_src_id,
        customer_src_id,
        employee_src_id,
        retailer_license_number_src_id,
        payment_method_src_id,
        event_dt,
        source_system,
        source_entity
    )
);



    RAISE NOTICE 'All tables created successfully.';
END;
$$;


CREATE OR REPLACE PROCEDURE bl_cl.p_log_etl(
    p_procedure_name TEXT,
    p_rows_affected INT,
    p_log_message TEXT,
    p_log_level TEXT DEFAULT 'INFO'
)
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO bl_3nf.etl_logs (
        procedure_name,
        rows_affected,
        log_message,
        log_level
    )
    VALUES (
        p_procedure_name,
        p_rows_affected,
        p_log_message,
        UPPER(p_log_level)
    );
EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'Failed to log ETL event: %', SQLERRM;
END;
$$;

CREATE OR REPLACE PROCEDURE bl_cl.create_p_log_etl_table()
LANGUAGE plpgsql
AS $$
BEGIN
   
   CREATE TABLE IF NOT EXISTS bl_3nf.etl_logs (
    log_id BIGSERIAL PRIMARY KEY,
    log_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    procedure_name TEXT NOT NULL,
    rows_affected INT,
    log_message TEXT,
    log_level TEXT CHECK (log_level IN ('INFO', 'ERROR', 'WARN')) DEFAULT 'INFO'
);

END;
$$;

CREATE OR REPLACE PROCEDURE bl_cl.create_etl_tracker_2()
LANGUAGE plpgsql
AS $$
BEGIN
   
   CREATE TABLE IF NOT EXISTS bl_cl.etl_tracker (
    source_name TEXT PRIMARY KEY,
    last_processed_date DATE
);


END;
$$;


CREATE OR REPLACE PROCEDURE bl_cl.sp_run_etl_for_source_by_date(
    p_source_name TEXT,
    p_schema TEXT,
    p_table TEXT,
    p_process_date DATE
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_last_processed_date DATE;
    v_sql TEXT;
BEGIN
    -- Get last processed date for this source
    SELECT last_processed_date
    INTO v_last_processed_date
    FROM bl_cl.etl_tracker
    WHERE source_name = p_source_name;

    IF v_last_processed_date IS NULL OR v_last_processed_date < p_process_date THEN
        RAISE NOTICE 'Processing source % for date %', p_source_name, p_process_date;
        -- Optionally call transformation logic here...

        -- Update tracker table
        INSERT INTO bl_cl.etl_tracker (source_name, last_processed_date)
        VALUES (p_source_name, p_process_date)
        ON CONFLICT (source_name) DO UPDATE
        SET last_processed_date = EXCLUDED.last_processed_date;

    ELSE
        RAISE NOTICE 'Source % already processed for date %, skipping.', p_source_name, p_process_date;
    END IF;
END;
$$;

CREATE OR REPLACE PROCEDURE bl_cl.create_indexes_bl_cl()
LANGUAGE plpgsql  -- Change this depending on your DBMS, e.g. DELIMITER $$ for MySQL
AS $$
BEGIN
    -- Indexes on GREATEST of dates
    EXECUTE 'CREATE INDEX idx_lkp_cities_greatest_dt ON bl_cl.lkp_cities (GREATEST(insert_dt, update_dt))';
    EXECUTE 'CREATE INDEX idx_lkp_customers_greatest_dt ON bl_cl.lkp_customers (GREATEST(start_dt, insert_dt))';
    EXECUTE 'CREATE INDEX idx_lkp_departments_greatest_dt ON bl_cl.lkp_departments (GREATEST(insert_dt, update_dt))';
    EXECUTE 'CREATE INDEX idx_lkp_employees_greatest_dt ON bl_cl.lkp_employees (GREATEST(insert_dt, update_dt))';
    EXECUTE 'CREATE INDEX idx_lkp_game_categories_greatest_dt ON bl_cl.lkp_game_categories (GREATEST(insert_dt, update_dt))';
    EXECUTE 'CREATE INDEX idx_lkp_game_numbers_greatest_dt ON bl_cl.lkp_game_numbers (GREATEST(insert_dt, update_dt))';
    EXECUTE 'CREATE INDEX idx_lkp_game_types_greatest_dt ON bl_cl.lkp_game_types (GREATEST(insert_dt, update_dt))';
    EXECUTE 'CREATE INDEX idx_lkp_location_names_greatest_dt ON bl_cl.lkp_location_names (GREATEST(insert_dt, update_dt))';
    EXECUTE 'CREATE INDEX idx_lkp_payment_methods_greatest_dt ON bl_cl.lkp_payment_methods (GREATEST(insert_dt, update_dt))';
    EXECUTE 'CREATE INDEX idx_lkp_retailers_greatest_dt ON bl_cl.lkp_retailers (GREATEST(insert_dt, update_dt))';
    EXECUTE 'CREATE INDEX idx_lkp_sales_greatest_dt ON bl_cl.lkp_sales (GREATEST(insert_dt, update_dt))';
    EXECUTE 'CREATE INDEX idx_lkp_states_greatest_dt ON bl_cl.lkp_states (GREATEST(insert_dt, update_dt))';
    EXECUTE 'CREATE INDEX idx_lkp_statuses_greatest_dt ON bl_cl.lkp_statuses (GREATEST(insert_dt, update_dt))';
    EXECUTE 'CREATE INDEX idx_lkp_zips_greatest_dt ON bl_cl.lkp_zips (GREATEST(insert_dt, update_dt))';

    -- Indexes on src_id columns
    EXECUTE 'CREATE INDEX idx_lkp_cities_src_id ON bl_cl.lkp_cities (city_src_id)';
    EXECUTE 'CREATE INDEX idx_lkp_customers_src_id ON bl_cl.lkp_customers (customer_src_id)';
    EXECUTE 'CREATE INDEX idx_lkp_departments_src_id ON bl_cl.lkp_departments (department_src_id)';
    EXECUTE 'CREATE INDEX idx_lkp_employees_src_id ON bl_cl.lkp_employees (employee_src_id)';
    EXECUTE 'CREATE INDEX idx_lkp_game_categories_src_id ON bl_cl.lkp_game_categories (game_category_src_id)';
    EXECUTE 'CREATE INDEX idx_lkp_game_numbers_src_id ON bl_cl.lkp_game_numbers (game_number_src_id)';
    EXECUTE 'CREATE INDEX idx_lkp_game_types_src_id ON bl_cl.lkp_game_types (game_type_src_id)';
    EXECUTE 'CREATE INDEX idx_lkp_location_names_src_id ON bl_cl.lkp_location_names (location_name_src_id)';
    EXECUTE 'CREATE INDEX idx_lkp_payment_methods_src_id ON bl_cl.lkp_payment_methods (payment_method_src_id)';
    EXECUTE 'CREATE INDEX idx_lkp_retailers_src_id ON bl_cl.lkp_retailers (retailer_license_number_src_id)';
    EXECUTE 'CREATE INDEX idx_lkp_states_src_id ON bl_cl.lkp_states (state_src_id)';
    EXECUTE 'CREATE INDEX idx_lkp_statuses_src_id ON bl_cl.lkp_statuses (status_src_id)';
    EXECUTE 'CREATE INDEX idx_lkp_zips_src_id ON bl_cl.lkp_zips (zip_src_id)';
END;
$$;


CREATE OR REPLACE PROCEDURE bl_cl.create_bl_cl_all_objects()
LANGUAGE plpgsql
AS $$
BEGIN
    CALL bl_cl.create_bl_cl_objects();
    CALL bl_cl.create_indexes_bl_cl();
    CALL bl_cl.create_p_log_etl_table();
    CALL bl_cl.create_etl_tracker_2();
END;
$$;





call bl_cl.create_bl_cl_all_objects();
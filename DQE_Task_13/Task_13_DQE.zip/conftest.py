import psycopg2
import sys
import os
import yaml
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
import pytest
from Pages.incomeStatementsReportPage import IncomeStatementsReportPage
from selenium.webdriver.chrome.service import Service

# SQL fixture
@pytest.fixture(scope="session")
def db_connection():
    conn = psycopg2.connect(
        database="dwh_hw_db",
        user="postgres",
        password="CretuPaul1990.",
        host="localhost",
        port=5432
    )
    yield conn
    conn.close()






def get_selenium_config(config_name):
    # Use current working directory as project root
    project_root = os.getcwd()
    config_path = os.path.join(project_root, 'Configs', config_name)

    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Cannot find config file at: {config_path}")

    with open(config_path, 'r') as stream:
        config = yaml.safe_load(stream)
    return config['global']


@pytest.fixture(scope="function")
def open_income_statements_report_webpage():
    config = get_selenium_config('config_selenium.yaml')
    report_uri = config['report_uri']
    delay = config['delay']  # use the value from your YAML

    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
    driver.set_window_size(1024, 600)
    driver.maximize_window()
    driver.get(report_uri)

    income_report = IncomeStatementsReportPage(driver, delay)

    # Don't switch iframe here — wait until it's actually loaded in the page object
    # income_report.switch_to_dashboard_iframe()

    yield income_report

    driver.quit()

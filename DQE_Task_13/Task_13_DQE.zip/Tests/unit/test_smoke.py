import pytest

# =========================
# SMOKE TESTS (Unit-level)
# =========================

@pytest.mark.smoke
def test_dwh_clients_table_exists(db_connection):
    cursor = db_connection.cursor()
    cursor.execute(
        "SELECT COUNT(*) FROM information_schema.tables "
        "WHERE table_schema='dwh' AND table_name='dwh_clients';"
    )
    assert cursor.fetchone()[0] == 1

@pytest.mark.smoke
def test_dwh_sales_table_exists(db_connection):
    cursor = db_connection.cursor()
    cursor.execute(
        "SELECT COUNT(*) FROM information_schema.tables "
        "WHERE table_schema='dwh' AND table_name='dwh_sales';"
    )
    assert cursor.fetchone()[0] == 1

@pytest.mark.smoke
def test_landing_clients_table_exists(db_connection):
    cursor = db_connection.cursor()
    cursor.execute(
        "SELECT COUNT(*) FROM information_schema.tables "
        "WHERE table_schema='lnd' AND table_name='lnd_s1_clients';"
    )
    assert cursor.fetchone()[0] == 1

@pytest.mark.smoke
def test_landing_sales_table_exists(db_connection):
    cursor = db_connection.cursor()
    cursor.execute(
        "SELECT COUNT(*) FROM information_schema.tables "
        "WHERE table_schema='lnd' AND table_name='lnd_s1_sales' LIMIT 1;"
    )
    assert cursor.fetchone()[0] == 1

@pytest.mark.smoke
def test_dwh_clients_table_has_rows(db_connection):
    cursor = db_connection.cursor()
    cursor.execute(
        "SELECT CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END AS has_data FROM dwh.dwh_clients LIMIT 1;"
    )
    assert cursor.fetchone()[0] == 1

@pytest.mark.smoke
def test_dwh_sales_table_has_rows(db_connection):
    cursor = db_connection.cursor()
    cursor.execute(
        "SELECT CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END AS has_data FROM dwh.dwh_sales;"
    )
    assert cursor.fetchone()[0] == 1




import pytest
import allure

# =========================
# INTEGRATION TESTS (ETL)
# =========================

@pytest.mark.integration
def test_channel_reconciliation(db_connection):
    cursor = db_connection.cursor()
    query = """
    WITH src AS (
        SELECT s1.channel_id, s1.channel_name, dl.location_id AS norm_location_id
        FROM lnd.lnd_s1_channels s1
        LEFT JOIN dwh.dwh_locations dl ON dl.location_name = s1.channel_location
        UNION ALL
        SELECT s2.channel_id, s2.channel_name, dl.location_id AS norm_location_id
        FROM lnd.lnd_s2_channels s2
        LEFT JOIN dwh.dwh_locations dl ON dl.location_src_id = s2.location_id
    ),
    trg AS (
        SELECT channel_src_id, channel_name, location_id
        FROM dwh.dwh_channels
    ),
    reconciliation AS (
        SELECT
            src.channel_id AS src_id,
            trg.channel_src_id AS trg_id,
            CASE
                WHEN src.channel_id IS NULL THEN 'Only in DWH'
                WHEN trg.channel_src_id IS NULL THEN 'Only in Landing'
                WHEN src.channel_name <> trg.channel_name THEN 'Mismatch in channel_name'
                WHEN src.norm_location_id <> trg.location_id THEN 'Mismatch in location_id'
                ELSE 'Match'
            END AS status
        FROM trg
        FULL OUTER JOIN src ON src.channel_id = trg.channel_src_id
    )
    SELECT COUNT(*) AS cnt FROM reconciliation WHERE status <> 'Match';
    """
    cursor.execute(query)
    assert cursor.fetchone()[0] == 0


@pytest.mark.integration
def test_product_reconciliation(db_connection):
    cursor = db_connection.cursor()
    query = """
    WITH src AS (
        SELECT product_id, product_name, cost AS product_cost FROM lnd.lnd_s1_products
        UNION ALL
        SELECT DISTINCT product_id, product_name, product_price AS product_cost FROM lnd.lnd_s2_client_sales
    ),
    trg AS (
        SELECT product_src_id, product_name, product_cost FROM dwh.dwh_products
    ),
    reconciliation AS (
        SELECT
            src.product_id AS src_id,
            trg.product_src_id AS trg_id,
            CASE
                WHEN src.product_id IS NULL THEN 'Only in DWH'
                WHEN trg.product_src_id IS NULL THEN 'Only in Landing'
                WHEN src.product_name <> trg.product_name THEN 'Mismatch in product_name'
                WHEN ROUND(src.product_cost::numeric, 2) <> ROUND(trg.product_cost, 2) THEN 'Mismatch in product_cost'
                ELSE 'Match'
            END AS status
        FROM trg
        FULL OUTER JOIN src ON src.product_id = trg.product_src_id
    )
    SELECT COUNT(*) AS cnt FROM reconciliation WHERE status <> 'Match';
    """
    cursor.execute(query)
    assert cursor.fetchone()[0] == 0


@pytest.mark.integration
def test_sales_reconciliation(db_connection):
    cursor = db_connection.cursor()
    query = """
    WITH src_sales AS (
        SELECT dc.client_src_id AS norm_client_id,
               dch.channel_src_id AS norm_channel_id,
               dp.product_src_id AS norm_product_id,
               s1.sale_date::date AS order_created,
               s1.sale_date::date AS order_completed,
               s1.units::numeric AS quantity
        FROM lnd.lnd_s1_sales s1
        LEFT JOIN dwh.dwh_clients dc ON dc.client_src_id = s1.client_id
        LEFT JOIN dwh.dwh_channels dch ON dch.channel_src_id = s1.channel_id
        LEFT JOIN dwh.dwh_products dp ON dp.product_src_id = s1.product_id
        UNION ALL
        SELECT dc.client_src_id, dch.channel_src_id, dp.product_src_id,
               s2.saled_at::date, s2.sold_date::date, s2.product_amount::numeric
        FROM lnd.lnd_s2_client_sales s2
        LEFT JOIN dwh.dwh_clients dc ON dc.client_src_id = s2.client_id
        LEFT JOIN dwh.dwh_channels dch ON dch.channel_src_id = s2.channel_id
        LEFT JOIN dwh.dwh_products dp ON dp.product_src_id = s2.product_id
    ),
    trg_sales AS (
        SELECT ds.sale_id, dc.client_src_id AS src_client_id,
               dch.channel_src_id AS src_channel_id,
               dp.product_src_id AS src_product_id,
               ds.order_created, ds.order_completed, ds.quantity
        FROM dwh.dwh_sales ds
        JOIN dwh.dwh_clients dc ON ds.client_id = dc.client_id
        JOIN dwh.dwh_channels dch ON ds.channel_id = dch.channel_id
        JOIN dwh.dwh_products dp ON ds.product_id = dp.product_id
    ),
    reconciliation AS (
        SELECT
            src.norm_client_id, src.norm_channel_id, src.norm_product_id, src.order_created,
            trg.src_client_id, trg.src_channel_id, trg.src_product_id, trg.order_created AS trg_order_created,
            CASE
                WHEN src.norm_client_id IS NULL AND src.norm_channel_id IS NULL AND src.norm_product_id IS NULL AND src.order_created IS NULL THEN 'Only in DWH'
                WHEN trg.src_client_id IS NULL AND trg.src_channel_id IS NULL AND trg.src_product_id IS NULL AND trg.order_created IS NULL THEN 'Only in Landing'
                WHEN src.norm_client_id <> trg.src_client_id THEN 'Mismatch in client_id'
                WHEN src.norm_channel_id <> trg.src_channel_id THEN 'Mismatch in channel_id'
                WHEN src.norm_product_id <> trg.src_product_id THEN 'Mismatch in product_id'
                WHEN COALESCE(src.order_created, '2000-01-01') <> COALESCE(trg.order_created, '2000-01-01') THEN 'Mismatch in order_created'
                WHEN COALESCE(src.order_completed, '2000-01-01') <> COALESCE(trg.order_completed, '2000-01-01') THEN 'Mismatch in order_completed'
                WHEN ROUND(src.quantity::numeric,2) <> ROUND(trg.quantity::numeric,2) THEN 'Mismatch in quantity'
                ELSE 'Match'
            END AS status
        FROM trg_sales trg
        FULL OUTER JOIN src_sales src
        ON src.norm_client_id  = trg.src_client_id
        AND src.norm_channel_id = trg.src_channel_id
        AND src.norm_product_id= trg.src_product_id
        AND src.order_created   = trg.order_created
    )
    SELECT COUNT(*) AS cnt FROM reconciliation WHERE status <> 'Match';
    """
    cursor.execute(query)
    assert cursor.fetchone()[0] == 0
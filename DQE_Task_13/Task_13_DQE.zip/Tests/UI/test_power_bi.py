import pytest
from selenium.webdriver.support.ui import WebDriverWait as WDW
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.action_chains import ActionChains

from selenium.webdriver.support.ui import WebDriverWait as WDW
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException

def test_market_share_tab_exists(open_income_statements_report_webpage):
    page = open_income_statements_report_webpage
    page.switch_to_dashboard_iframe()

    el = WDW(page.driver, page.delay).until(
        EC.presence_of_element_located((By.XPATH, "//*[text()='Market Share']"))
    )
    assert el is not None, "❌ Market Share tab not found in the iframe"


def test_qa_button_exists(open_income_statements_report_webpage):
    page = open_income_statements_report_webpage
    page.switch_to_dashboard_iframe()

    el = WDW(page.driver, page.delay).until(
        EC.presence_of_element_located((By.XPATH, "//*[text()='Q&A']"))
    )
    assert el is not None, "❌ Q&A button not found in the iframe"

def test_region_filter_exists(open_income_statements_report_webpage):
    page = open_income_statements_report_webpage
    page.switch_to_dashboard_iframe()
    region = WDW(page.driver, page.delay).until(
        EC.presence_of_element_located((By.XPATH, "//*[contains(text(),'Region')]"))
    )
    assert region is not None, "Region filter not present in the report"


def test_bars_in_chart_exist(open_income_statements_report_webpage):
    page = open_income_statements_report_webpage
    page.switch_to_dashboard_iframe()
    chart = WDW(page.driver, page.delay).until(
        EC.presence_of_element_located((By.XPATH, "//*[contains(text(),'Total Category Volume Over Time')]"))
    )
    assert chart is not None, "Revenue chart not found"


def test_vanarsdel_performance_section_exists(open_income_statements_report_webpage):
    page = open_income_statements_report_webpage
    page.switch_to_dashboard_iframe()
    section = WDW(page.driver, page.delay).until(
        EC.presence_of_element_located((By.XPATH, "//*[contains(text(),'VanArsdel Performance')]"))
    )
    assert section is not None, "VanArsdel Performance section not found"

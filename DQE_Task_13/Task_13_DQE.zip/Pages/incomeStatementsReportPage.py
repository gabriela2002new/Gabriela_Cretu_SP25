from selenium.webdriver.support.ui import WebDriverWait as WDW
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.action_chains import ActionChains

class IncomeStatementsReportPage:
    def __init__(self, driver, delay=30):
        self.driver = driver
        self.delay = delay

        # Locators
        self.market_share_tab = "//div[contains(@class, 'tab')]//span[text()='Market Share'] | //span[text()='Market Share']"
        self.market_share_report_header = "//div[contains(@title, 'Market Share')][1]"

    def switch_to_dashboard_iframe(self):
        """Switch to the Power BI report iframe inside #embedContainer."""
        try:
            # Wait for any iframe inside the embed container to appear
            iframe = WDW(self.driver, self.delay).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "#embedContainer iframe"))
            )
            self.driver.switch_to.frame(iframe)

            # DEBUG: confirm we switched
            print("Switched to dashboard iframe successfully.")
            # Optional: check some basic element inside iframe
            if self.driver.find_elements(By.CSS_SELECTOR, "body"):
                print("Iframe contains body element — switch confirmed.")
            else:
                print("Iframe found but seems empty.")

        except TimeoutException:
            raise Exception("Dashboard iframe inside #embedContainer not found.")

    def open_market_share_tab(self):
        """Click on the Market Share tab."""
        self.switch_to_dashboard_iframe()  # Ensure we are inside the iframe

        try:
            tab = WDW(self.driver, self.delay).until(
                EC.presence_of_element_located((By.XPATH, self.market_share_tab))
            )
            # Scroll element into view
            self.driver.execute_script("arguments[0].scrollIntoView(true);", tab)
            # Ensure clickable
            WDW(self.driver, self.delay).until(
                EC.element_to_be_clickable((By.XPATH, self.market_share_tab))
            )
            tab.click()
        except TimeoutException:
            raise Exception("Market Share tab not found or not clickable.")

    def get_market_share_report_title(self):
        """Return the title text of the Market Share report."""
        try:
            report_header = WDW(self.driver, self.delay).until(
                EC.visibility_of_element_located((By.XPATH, self.market_share_report_header))
            )
            return report_header.get_attribute("title")
        except TimeoutException:
            raise Exception("Market Share report header not found or not visible.")

    def switch_to_default_content(self):
        """Switch back to main page content from iframe."""
        self.driver.switch_to.default_content()

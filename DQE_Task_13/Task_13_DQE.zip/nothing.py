import os
import yaml
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from Pages.incomeStatementsReportPage import IncomeStatementsReportPage  # adjust import
from selenium.webdriver.common.by import By



from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from selenium.common.exceptions import StaleElementReferenceException
import time



if __name__ == "__main__":

    # --- Hardcoded config ---
    report_uri = "https://playground.powerbi.com/en-us/explore-features"
    delay = 30

    # --- Setup driver ---
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
    driver.maximize_window()
    driver.get(report_uri)

    # --- Page object ---
    page = IncomeStatementsReportPage(driver, delay)

    # --- Switch to iframe ---
    page.switch_to_dashboard_iframe()

    # --- Collect elements inside iframe ---
    elements = driver.find_elements(By.XPATH, "//*")

    output_file = "iframe_elements.txt"
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(f"Total elements in iframe: {len(elements)}\n\n")

        for i, el in enumerate(elements):  # dump first 200 max
            try:
                tag = el.tag_name
                cls = el.get_attribute("class")
                text = el.text.strip()
                f.write(f"{i + 1:03d}: <{tag} class='{cls}'> text='{text}'\n")
            except StaleElementReferenceException:
                f.write(f"{i + 1:03d}: ⚠️ stale element (skipped)\n")

    print(f"✅ Elements written to {output_file}")

    # --- Keep browser open for manual inspection ---
    input("Press Enter to quit...")
    driver.quit()
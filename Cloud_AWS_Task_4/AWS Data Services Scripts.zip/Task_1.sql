-- --------------------------------------------
-- Initial script for MySQL RDS (gabriela_cretu)
-- --------------------------------------------

-- Use your own schema
CREATE SCHEMA IF NOT EXISTS gabriela_schema;
USE gabriela_schema;

-- --------------------------------------------
-- Drop objects if exist (restartable)
-- --------------------------------------------
DROP TABLE IF EXISTS sales;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS sequence;
DROP VIEW IF EXISTS high_value_sales;
DROP PROCEDURE IF EXISTS give_discount;

-- --------------------------------------------
-- Create tables
-- --------------------------------------------

CREATE TABLE customers (
    customer_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(100),
    created_at DATETIME
);

CREATE TABLE products (
    product_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(100),
    category VARCHAR(50),
    price DECIMAL(10,2),
    stock_quantity INT
);

CREATE TABLE sales (
    sale_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    sale_date DATE,
    amount DECIMAL(10,2),
    created_at DATETIME,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

CREATE TABLE sequence (
    id INT NOT NULL PRIMARY KEY
);

-- --------------------------------------------
-- Insert sample data
-- --------------------------------------------

INSERT INTO customers (first_name, last_name, email, created_at)
VALUES
('Alice', 'Smith', 'alice@example.com', NOW()),
('Bob', 'Johnson', 'bob@example.com', NOW()),
('Charlie', 'Brown', 'charlie@example.com', NOW());

INSERT INTO products (product_name, category, price, stock_quantity)
VALUES
('Laptop', 'Electronics', 1200.00, 10),
('Headphones', 'Electronics', 150.00, 50),
('Coffee Mug', 'Kitchen', 12.50, 100);

INSERT INTO sales (customer_id, sale_date, amount, created_at)
VALUES
(1, '2025-08-27', 1200.00, NOW()),
(2, '2025-08-27', 150.00, NOW()),
(3, '2025-08-27', 12.50, NOW());

INSERT INTO sequence (id)
VALUES (1),(2),(3);

-- --------------------------------------------
-- Create a view
-- --------------------------------------------

CREATE OR REPLACE VIEW high_value_sales AS
SELECT s.sale_id, c.first_name, c.last_name, s.amount
FROM sales s
JOIN customers c ON s.customer_id = c.customer_id
WHERE s.amount > 500;

-- --------------------------------------------
-- Create a stored procedure
-- --------------------------------------------

CREATE PROCEDURE give_discount(IN cust INT, IN discount DECIMAL(10,2))
BEGIN
    UPDATE sales
    SET amount = amount - discount
    WHERE customer_id = cust;
END;
-- --------------------------------------------
-- End of initialization script
-- --------------------------------------------
